(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [15], {
        "13w0": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "courses-area ptb-100 bg-f5f7fa",
                    children: [Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go at your own pace"
                            }), Object(a.jsx)("h2", {
                                children: "The World\u2019s Largest Selection Of Courses"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small1.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)(t.a, {
                                                    href: "#",
                                                    children: Object(a.jsx)("a", {
                                                        className: "fav",
                                                        children: Object(a.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$39"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Agile Crash Course: Agile Project Management"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 15 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 145 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small2.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$99"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "single-courses-1.html",
                                                        children: "Vue JS 2 - The Complete Guide (incl. Vue Router & Vuex)"
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 14 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 100 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small3.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$49"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "single-courses-1.html",
                                                        children: "The Python Bible\u2122 | Everything You Need to Program in Python"
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 11 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 104 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small4.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$79"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "single-courses-1.html",
                                                        children: "Mathematical Foundation For Machine Learning and AI"
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 14 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 100 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small5.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$59"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "single-courses-1.html",
                                                        children: "The Ultimate Drawing Course - Beginner to Advanced"
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 09 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 150 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small6.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$89"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "single-courses-1.html",
                                                        children: "PyTorch: Deep Learning and Artificial Intelligence"
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 20 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 200 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-12 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "courses-info",
                                    children: [Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(a.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " View All Courses ", Object(a.jsx)("span", {})]
                                        })
                                    }), Object(a.jsxs)("p", {
                                        children: ["Get into details now?\u200b ", Object(a.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(a.jsx)("a", {
                                                children: "PM Master\u2019s Program"
                                            })
                                        })]
                                    })]
                                })
                            })]
                        })]
                    }), Object(a.jsx)("div", {
                        className: "shape16",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape15.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        "1NgU": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "blog-area ptb-100",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "News"
                            }), Object(a.jsx)("h2", {
                                children: "Check Out Our Latest Blog"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-8 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "single-blog-post-item",
                                    children: [Object(a.jsx)("div", {
                                        className: "post-image",
                                        children: Object(a.jsx)(t.a, {
                                            href: "/single-blog-3",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/blog/blog4.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "category",
                                                children: "Education"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "/single-blog-3",
                                                children: Object(a.jsx)("a", {
                                                    children: "University Admissions Could Face Emergency Controls"
                                                })
                                            })
                                        }), Object(a.jsxs)("ul", {
                                            className: "post-content-footer d-flex align-items-center",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(a.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(a.jsx)("span", {
                                                        children: "Alex Morgan"
                                                    })]
                                                })
                                            }), Object(a.jsxs)("li", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 30, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "blog-post-list",
                                    children: Object(a.jsxs)("div", {
                                        className: "row",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-12 col-sm-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-blog-post-item",
                                                children: [Object(a.jsx)("div", {
                                                    className: "post-image",
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-blog-3",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/blog/blog5.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    })
                                                }), Object(a.jsx)("div", {
                                                    className: "post-content",
                                                    children: Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(t.a, {
                                                            href: "/single-blog-3",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Online Learning Can Prepare Students For A Fast-Changing"
                                                            })
                                                        })
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-12 col-sm-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-blog-post-item",
                                                children: [Object(a.jsx)("div", {
                                                    className: "post-image",
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-blog-3",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/blog/blog6.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    })
                                                }), Object(a.jsx)("div", {
                                                    className: "post-content",
                                                    children: Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(t.a, {
                                                            href: "/single-blog-3",
                                                            children: Object(a.jsx)("a", {
                                                                children: "As Learning Moves Online, Trigger Warnings Must Too"
                                                            })
                                                        })
                                                    })
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-12 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "blog-post-info",
                                    children: Object(a.jsxs)("p", {
                                        children: ["Get into details now?\u200b ", Object(a.jsx)(t.a, {
                                            href: "/blog-3",
                                            children: Object(a.jsx)("a", {
                                                children: "View all posts"
                                            })
                                        })]
                                    })
                                })
                            })]
                        })]
                    })
                })
            }
        },
        "1YqJ": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "categories-area ptb-100",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Categories"
                            }), Object(a.jsx)("h2", {
                                children: "Top Categories"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie1.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Development"
                                        }), Object(a.jsx)("span", {
                                            children: "10 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie2.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Business"
                                        }), Object(a.jsx)("span", {
                                            children: "20 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie3.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "IT & Software"
                                        }), Object(a.jsx)("span", {
                                            children: "15 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie4.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Design"
                                        }), Object(a.jsx)("span", {
                                            children: "11 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie5.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Lifestyle"
                                        }), Object(a.jsx)("span", {
                                            children: "10 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie6.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Photo & Flim"
                                        }), Object(a.jsx)("span", {
                                            children: "12 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie7.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Animation"
                                        }), Object(a.jsx)("span", {
                                            children: "05 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie8.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Writing"
                                        }), Object(a.jsx)("span", {
                                            children: "20 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-12 col-sm-12 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "categories-btn-box",
                                    children: Object(a.jsx)(t.a, {
                                        href: "/categories",
                                        children: Object(a.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(a.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " View All Categories ", Object(a.jsx)("span", {})]
                                        })
                                    })
                                })
                            })]
                        })]
                    })
                })
            }
        },
        A3s4: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "features-area pt-100 pb-70",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Education for everyone"
                            }), Object(a.jsx)("h2", {
                                children: "Online Coaching Lessons For Remote Learning"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-features-box without-padding",
                                    children: [Object(a.jsx)("div", {
                                        className: "icon",
                                        children: Object(a.jsx)("i", {
                                            className: "flaticon-brain-process"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        children: "Learn the Latest Skills"
                                    }), Object(a.jsx)("p", {
                                        children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration."
                                    }), Object(a.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now!"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-features-box without-padding",
                                    children: [Object(a.jsx)("div", {
                                        className: "icon",
                                        children: Object(a.jsx)("i", {
                                            className: "flaticon-computer"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        children: "Go at Your Own Pace"
                                    }), Object(a.jsx)("p", {
                                        children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration."
                                    }), Object(a.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now!"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                children: Object(a.jsxs)("div", {
                                    className: "single-features-box without-padding",
                                    children: [Object(a.jsx)("div", {
                                        className: "icon",
                                        children: Object(a.jsx)("i", {
                                            className: "flaticon-shield-1"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        children: "Learn from Industry Experts"
                                    }), Object(a.jsx)("p", {
                                        children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration."
                                    }), Object(a.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now!"
                                        })
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        F1Ic: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "premium-access-area bg-f9f9f9 ptb-100",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "premium-access-content",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go at your own pace"
                            }), Object(a.jsx)("h2", {
                                children: "Give their limitless potential unlimited access"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(a.jsx)(t.a, {
                                href: "/membership-levels",
                                children: Object(a.jsxs)("a", {
                                    className: "default-btn",
                                    children: [Object(a.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Give Premium Access ", Object(a.jsx)("span", {})]
                                })
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape3",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape4",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape8",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape7.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        JcBV: function(e, s, c) {
            "use strict";
            var a = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "funfacts-area bg-fffaf3",
                    children: Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "1926"
                                    }), Object(a.jsx)("p", {
                                        children: "Finished Sessions"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "3279"
                                    }), Object(a.jsx)("p", {
                                        children: "Enrolled Learners"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "250"
                                    }), Object(a.jsx)("p", {
                                        children: "Online Instructors"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "100%"
                                    }), Object(a.jsx)("p", {
                                        children: "Satisfaction Rate"
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        Lrxs: function(e, s, c) {
            "use strict";
            var a = c("rePB"),
                i = c("nKUr"),
                t = c("ODXe"),
                l = c("YFqc"),
                r = c.n(l),
                n = c("q1tI"),
                j = c.n(n),
                d = c("Vvt1");

            function o(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function b(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? o(Object(c), !0).forEach((function(s) {
                        Object(a.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : o(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var m = c.n(d)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                h = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 2
                        },
                        768: {
                            items: 2
                        },
                        992: {
                            items: 3
                        }
                    }
                };
            s.a = function() {
                var e = j.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    a = s[1];
                return j.a.useEffect((function() {
                    a(!0)
                }), []), Object(i.jsx)("div", {
                    className: "advisor-area bg-f9f9f9 pt-100",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Course Advisor"
                            }), Object(i.jsx)("h2", {
                                children: "Meet Our World-class Instructors"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), c ? Object(i.jsxs)(m, b(b({
                            className: "advisor-slides-two owl-carousel owl-theme"
                        }, h), {}, {
                            children: [Object(i.jsxs)("div", {
                                className: "single-advisor-item",
                                children: [Object(i.jsxs)("div", {
                                    className: "advisor-image",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/advisor/advisor4.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("ul", {
                                        className: "social-link",
                                        children: [Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-facebook"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-twitter"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-instagram"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-linkedin"
                                                })
                                            })
                                        })]
                                    })]
                                }), Object(i.jsxs)("div", {
                                    className: "advisor-content",
                                    children: [Object(i.jsx)("h3", {
                                        children: Object(i.jsx)(r.a, {
                                            href: "/profile",
                                            children: Object(i.jsx)("a", {
                                                children: "James Andy"
                                            })
                                        })
                                    }), Object(i.jsx)("span", {
                                        children: "Project Management Expert"
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-advisor-item",
                                children: [Object(i.jsxs)("div", {
                                    className: "advisor-image",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/advisor/advisor5.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("ul", {
                                        className: "social-link",
                                        children: [Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-facebook"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-twitter"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-instagram"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-linkedin"
                                                })
                                            })
                                        })]
                                    })]
                                }), Object(i.jsxs)("div", {
                                    className: "advisor-content",
                                    children: [Object(i.jsx)("h3", {
                                        children: Object(i.jsx)(r.a, {
                                            href: "/profile",
                                            children: Object(i.jsx)("a", {
                                                children: "Jassica Hische"
                                            })
                                        })
                                    }), Object(i.jsx)("span", {
                                        children: "Illustrator Expert"
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-advisor-item",
                                children: [Object(i.jsxs)("div", {
                                    className: "advisor-image",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/advisor/advisor6.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("ul", {
                                        className: "social-link",
                                        children: [Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-facebook"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-twitter"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-instagram"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-linkedin"
                                                })
                                            })
                                        })]
                                    })]
                                }), Object(i.jsxs)("div", {
                                    className: "advisor-content",
                                    children: [Object(i.jsx)("h3", {
                                        children: Object(i.jsx)(r.a, {
                                            href: "/profile",
                                            children: Object(i.jsx)("a", {
                                                children: "Alister Cock"
                                            })
                                        })
                                    }), Object(i.jsx)("span", {
                                        children: "QA Project Expert"
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-advisor-item",
                                children: [Object(i.jsxs)("div", {
                                    className: "advisor-image",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/advisor/advisor7.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("ul", {
                                        className: "social-link",
                                        children: [Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-facebook"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-twitter"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-instagram"
                                                })
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(i.jsx)("i", {
                                                    className: "bx bxl-linkedin"
                                                })
                                            })
                                        })]
                                    })]
                                }), Object(i.jsxs)("div", {
                                    className: "advisor-content",
                                    children: [Object(i.jsx)("h3", {
                                        children: Object(i.jsx)(r.a, {
                                            href: "/profile",
                                            children: Object(i.jsx)("a", {
                                                children: "Lina Ninja"
                                            })
                                        })
                                    }), Object(i.jsx)("span", {
                                        children: "QA Project Expert"
                                    })]
                                })]
                            })]
                        })) : ""]
                    })
                })
            }
        },
        PepQ: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = c("ODXe"),
                t = c("q1tI"),
                l = c.n(t),
                r = c("YFqc"),
                n = c.n(r),
                j = c("Vvt1"),
                d = c.n(j)()((function() {
                    return Promise.all([c.e(0), c.e(6), c.e(8)]).then(c.t.bind(null, "60Bi", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["60Bi"]
                        },
                        modules: ["react-modal-video"]
                    }
                });
            s.a = function() {
                var e = l.a.useState(!1),
                    s = Object(i.a)(e, 2),
                    c = s[0],
                    t = s[1];
                l.a.useEffect((function() {
                    t(!0)
                }), []);
                var r = l.a.useState(!0),
                    j = Object(i.a)(r, 2),
                    o = j[0],
                    b = j[1];
                return Object(a.jsxs)(l.a.Fragment, {
                    children: [Object(a.jsxs)("div", {
                        className: "about-area-two pb-100",
                        children: [Object(a.jsx)("div", {
                            className: "container",
                            children: Object(a.jsxs)("div", {
                                className: "row align-items-center",
                                children: [Object(a.jsx)("div", {
                                    className: "col-lg-5 col-md-12",
                                    children: Object(a.jsxs)("div", {
                                        className: "about-content-box",
                                        children: [Object(a.jsx)("span", {
                                            className: "sub-title",
                                            children: "Distance Learning"
                                        }), Object(a.jsx)("h2", {
                                            children: "Build Your Project Management Skills Online, Anytime"
                                        }), Object(a.jsx)("p", {
                                            children: "Want to learn and earn PDUs or CEUs on your schedule \u2014 anytime, anywhere? Or, pick up a new skill quickly like, project team leadership or agile? Browse our most popular online courses."
                                        }), Object(a.jsx)("p", {
                                            children: Object(a.jsx)("strong", {
                                                children: "Grow your knowledge and your opportunities with thought leadership, training and tools."
                                            })
                                        }), Object(a.jsx)(n.a, {
                                            href: "/contact",
                                            children: Object(a.jsx)("a", {
                                                className: "link-btn",
                                                children: "Explore Learning"
                                            })
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-7 col-md-12",
                                    children: Object(a.jsxs)("div", {
                                        className: "about-video-box",
                                        children: [Object(a.jsx)("div", {
                                            className: "image",
                                            children: Object(a.jsx)("img", {
                                                src: "/images/about-img6.jpg",
                                                alt: "image"
                                            })
                                        }), Object(a.jsx)(n.a, {
                                            href: "#play-video",
                                            children: Object(a.jsx)("a", {
                                                onClick: function(e) {
                                                    e.preventDefault(), b(!o)
                                                },
                                                className: "video-btn popup-youtube",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-play"
                                                })
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "shape10",
                                            children: Object(a.jsx)("img", {
                                                src: "/images/shape9.png",
                                                alt: "image"
                                            })
                                        })]
                                    })
                                })]
                            })
                        }), Object(a.jsx)("div", {
                            className: "shape3",
                            children: Object(a.jsx)("img", {
                                src: "/images/shape3.png",
                                alt: "image"
                            })
                        }), Object(a.jsx)("div", {
                            className: "shape4",
                            children: Object(a.jsx)("img", {
                                src: "/images/shape4.png",
                                alt: "image"
                            })
                        }), Object(a.jsx)("div", {
                            className: "shape2",
                            children: Object(a.jsx)("img", {
                                src: "/images/shape2.png",
                                alt: "image"
                            })
                        })]
                    }), c ? Object(a.jsx)(d, {
                        channel: "youtube",
                        isOpen: !o,
                        videoId: "bk7McNUjWgw",
                        onClose: function() {
                            return b(!o)
                        }
                    }) : ""]
                })
            }
        },
        "d/qs": function(e, s, c) {
            "use strict";
            var a = c("rePB"),
                i = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                r = c.n(l),
                n = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(a.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(n)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                b = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 1
                        },
                        768: {
                            items: 2
                        },
                        1200: {
                            items: 2
                        }
                    }
                };
            s.a = function() {
                var e = r.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    a = s[1];
                return r.a.useEffect((function() {
                    a(!0)
                }), []), Object(i.jsxs)("div", {
                    className: "feedback-area bg-fffaf3 ptb-100",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: c ? Object(i.jsxs)(o, d(d({
                            className: "feedback-slides-two owl-carousel owl-theme"
                        }, b), {}, {
                            children: [Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "John Smith"
                                        }), Object(i.jsx)("span", {
                                            children: "Python Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user2.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Sarah Taylor"
                                        }), Object(i.jsx)("span", {
                                            children: "PHP Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "David Warner"
                                        }), Object(i.jsx)("span", {
                                            children: "QA Developer"
                                        })]
                                    })]
                                })]
                            })]
                        })) : ""
                    }), Object(i.jsx)("div", {
                        className: "divider2"
                    }), Object(i.jsx)("div", {
                        className: "divider3"
                    }), Object(i.jsx)("div", {
                        className: "shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape2.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape3",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape4",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape9",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        iaE3: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "banner-wrapper-area",
                    children: [Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "banner-wrapper-content",
                                    children: [Object(a.jsx)("h1", {
                                        children: "Build Skills With Experts Any Time, Anywhere"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(a.jsxs)("form", {
                                        children: [Object(a.jsx)("label", {
                                            children: Object(a.jsx)("i", {
                                                className: "flaticon-search"
                                            })
                                        }), Object(a.jsx)("input", {
                                            type: "text",
                                            className: "input-search",
                                            placeholder: "What do you want to learn?"
                                        }), Object(a.jsx)("button", {
                                            type: "submit",
                                            children: "Search Now"
                                        })]
                                    }), Object(a.jsxs)("ul", {
                                        className: "popular-search-list",
                                        children: [Object(a.jsx)("li", {
                                            children: Object(a.jsx)("span", {
                                                children: "Popular:"
                                            })
                                        }), Object(a.jsx)("li", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "Development"
                                                })
                                            })
                                        }), Object(a.jsx)("li", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "Marketing"
                                                })
                                            })
                                        }), Object(a.jsx)("li", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "Illustration"
                                                })
                                            })
                                        }), Object(a.jsx)("li", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "UX/UI"
                                                })
                                            })
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "banner-wrapper-image",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/banner-img2.png",
                                        alt: "image"
                                    }), Object(a.jsx)("div", {
                                        className: "banner-shape8",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/banner-shape8.png",
                                            alt: "image"
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "banner-shape9",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/banner-shape9.png",
                                            alt: "image"
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "banner-shape10",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/banner-shape10.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            })]
                        }), Object(a.jsx)("div", {
                            className: "banner-inner-area",
                            children: Object(a.jsxs)("div", {
                                className: "row",
                                children: [Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6 col-sm-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-banner-box",
                                        children: [Object(a.jsx)("div", {
                                            className: "icon",
                                            children: Object(a.jsx)("i", {
                                                className: "flaticon-brain-process"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: "10,000 Online Courses"
                                        }), Object(a.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet consectets."
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6 col-sm-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-banner-box",
                                        children: [Object(a.jsx)("div", {
                                            className: "icon",
                                            children: Object(a.jsx)("i", {
                                                className: "flaticon-people"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: "Experts Teachers"
                                        }), Object(a.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet consectets."
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-banner-box",
                                        children: [Object(a.jsx)("div", {
                                            className: "icon",
                                            children: Object(a.jsx)("i", {
                                                className: "flaticon-world"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: "Lifetime Access"
                                        }), Object(a.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet consectets."
                                        })]
                                    })
                                })]
                            })
                        })]
                    }), Object(a.jsx)("div", {
                        className: "divider"
                    })]
                })
            }
        },
        rePB: function(e, s, c) {
            "use strict";

            function a(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return a
            }))
        },
        sex0: function(e, s, c) {
            "use strict";
            var a = c("rePB"),
                i = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                r = c.n(l),
                n = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(a.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(n)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                b = {
                    loop: !0,
                    nav: !0,
                    margin: 60,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 3,
                            margin: 20
                        },
                        600: {
                            items: 3
                        },
                        768: {
                            items: 4,
                            margin: 30
                        },
                        1e3: {
                            items: 6
                        }
                    }
                };
            s.a = function() {
                var e = r.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    a = s[1];
                return r.a.useEffect((function() {
                    a(!0)
                }), []), Object(i.jsx)("div", {
                    className: "partner-area ptb-70",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: c ? Object(i.jsxs)(o, d(d({
                            className: "partner-slides owl-carousel owl-theme"
                        }, b), {}, {
                            children: [Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner1.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner2.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner3.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner4.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner5.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner6.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner4.png",
                                    alt: "image"
                                })
                            })]
                        })) : ""
                    })
                })
            }
        },
        ur7V: function(e, s, c) {
            "use strict";
            var a = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "subscribe-area bg-f9f9f9 ptb-100",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "subscribe-content",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go At Your Own Pace"
                            }), Object(a.jsx)("h2", {
                                children: "Subscribe To Our Newsletter"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(a.jsxs)("form", {
                                className: "newsletter-form",
                                children: [Object(a.jsx)("input", {
                                    type: "text",
                                    className: "input-newsletter",
                                    placeholder: "Enter your email address",
                                    name: "EMAIL",
                                    required: !0
                                }), Object(a.jsxs)("button", {
                                    type: "submit",
                                    className: "default-btn",
                                    children: [Object(a.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Subscribe Now ", Object(a.jsx)("span", {})]
                                })]
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape4",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape13",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape12.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape14",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape13.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape15",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape14.png",
                            alt: "image"
                        })
                    })]
                })
            }
        }
    }
]);