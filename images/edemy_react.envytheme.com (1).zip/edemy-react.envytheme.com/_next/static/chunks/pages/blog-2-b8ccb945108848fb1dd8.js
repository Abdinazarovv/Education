_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [43], {
        "8bsX": function(e, c, s) {
            "use strict";
            s.r(c);
            var l = s("nKUr"),
                t = s("q1tI"),
                a = s.n(t),
                n = s("Ix5F"),
                i = s("YFqc"),
                r = s.n(i);
            c.default = function() {
                return Object(l.jsxs)(a.a.Fragment, {
                    children: [Object(l.jsx)(n.a, {
                        pageTitle: "Blog Grid (3 in Row)",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Blog Grid (3 in Row)"
                    }), Object(l.jsx)("div", {
                        className: "blog-area ptb-100",
                        children: Object(l.jsx)("div", {
                            className: "container",
                            children: Object(l.jsxs)("div", {
                                className: "row",
                                children: [Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog1.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Education"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "It\u2019s Time To Think Differently About Homeschooling"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user1.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "Alex Morgan"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 30, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog2.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Online"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "What Is The MLB Summer Slugger Program?"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user2.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "Sarah Taylor"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 29, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog3.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Learning"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "28 Student-Centered Instructional Strategies"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user3.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "David Warner"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog7.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Education"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "4 Steps To Quality Training In Times Of Urgency"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user1.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "Alex Morgan"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog8.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Online"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "100 Blended Learning Resources For Teachers"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user2.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "Sarah Taylor"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog9.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Learning"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "20 Examples Of Project-Based Learning"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user3.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "David Warner"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog10.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Education"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "Instructional Design And Adult Learners"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user1.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "Alex Morgan"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog11.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Online"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "Join ATD 2020 International Conference & EXPO"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user2.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "Sarah Taylor"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(l.jsxs)("div", {
                                        className: "single-blog-post-box",
                                        children: [Object(l.jsx)("div", {
                                            className: "post-image",
                                            children: Object(l.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(l.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(l.jsx)("img", {
                                                        src: "/images/blog/blog12.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(l.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(l.jsx)(r.a, {
                                                href: "#",
                                                children: Object(l.jsx)("a", {
                                                    className: "category",
                                                    children: "Learning"
                                                })
                                            }), Object(l.jsx)("h3", {
                                                children: Object(l.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(l.jsx)("a", {
                                                        children: "2020 L&D On A Shoestring Online Conference"
                                                    })
                                                })
                                            }), Object(l.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(l.jsx)("li", {
                                                    children: Object(l.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(l.jsx)("img", {
                                                            src: "/images/user3.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(l.jsx)("span", {
                                                            children: "David Warner"
                                                        })]
                                                    })
                                                }), Object(l.jsxs)("li", {
                                                    children: [Object(l.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-12 col-md-12",
                                    children: Object(l.jsxs)("div", {
                                        className: "pagination-area text-center",
                                        children: [Object(l.jsx)("a", {
                                            href: "#",
                                            className: "prev page-numbers",
                                            children: Object(l.jsx)("i", {
                                                className: "bx bx-chevrons-left"
                                            })
                                        }), Object(l.jsx)("span", {
                                            className: "page-numbers current",
                                            "aria-current": "page",
                                            children: "1"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "2"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "3"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "4"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "next page-numbers",
                                            children: Object(l.jsx)("i", {
                                                className: "bx bx-chevrons-right"
                                            })
                                        })]
                                    })
                                })]
                            })
                        })
                    })]
                })
            }
        },
        Ix5F: function(e, c, s) {
            "use strict";
            var l = s("nKUr"),
                t = (s("q1tI"), s("YFqc")),
                a = s.n(t);
            c.a = function(e) {
                var c = e.pageTitle,
                    s = e.homePageUrl,
                    t = e.homePageText,
                    n = e.activePageText;
                return Object(l.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(l.jsx)("div", {
                        className: "container",
                        children: Object(l.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(l.jsxs)("ul", {
                                children: [Object(l.jsx)("li", {
                                    children: Object(l.jsx)(a.a, {
                                        href: s,
                                        children: Object(l.jsx)("a", {
                                            children: t
                                        })
                                    })
                                }), Object(l.jsx)("li", {
                                    className: "active",
                                    children: n
                                })]
                            }), Object(l.jsx)("h2", {
                                children: c
                            })]
                        })
                    }), Object(l.jsx)("div", {
                        className: "shape9",
                        children: Object(l.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        K8cT: function(e, c, s) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/blog-2", function() {
                return s("8bsX")
            }])
        },
        YFqc: function(e, c, s) {
            e.exports = s("cTJO")
        },
        cTJO: function(e, c, s) {
            "use strict";
            var l = s("zoAU"),
                t = s("7KCV");
            c.__esModule = !0, c.default = void 0;
            var a = t(s("q1tI")),
                n = s("elyg"),
                i = s("nOHt"),
                r = s("vNVm"),
                j = {};

            function o(e, c, s, l) {
                if (e && (0, n.isLocalURL)(c)) {
                    e.prefetch(c, s, l).catch((function(e) {
                        0
                    }));
                    var t = l && "undefined" !== typeof l.locale ? l.locale : e && e.locale;
                    j[c + "%" + s + (t ? "%" + t : "")] = !0
                }
            }
            var d = function(e) {
                var c = !1 !== e.prefetch,
                    s = (0, i.useRouter)(),
                    t = s && s.pathname || "/",
                    d = a.default.useMemo((function() {
                        var c = (0, n.resolveHref)(t, e.href, !0),
                            s = l(c, 2),
                            a = s[0],
                            i = s[1];
                        return {
                            href: a,
                            as: e.as ? (0, n.resolveHref)(t, e.as) : i || a
                        }
                    }), [t, e.href, e.as]),
                    b = d.href,
                    h = d.as,
                    g = e.children,
                    x = e.replace,
                    m = e.shallow,
                    O = e.scroll,
                    f = e.locale;
                "string" === typeof g && (g = a.default.createElement("a", null, g));
                var u = a.Children.only(g),
                    p = u && "object" === typeof u && u.ref,
                    N = (0, r.useIntersection)({
                        rootMargin: "200px"
                    }),
                    v = l(N, 2),
                    y = v[0],
                    w = v[1],
                    T = a.default.useCallback((function(e) {
                        y(e), p && ("function" === typeof p ? p(e) : "object" === typeof p && (p.current = e))
                    }), [p, y]);
                (0, a.useEffect)((function() {
                    var e = w && c && (0, n.isLocalURL)(b),
                        l = "undefined" !== typeof f ? f : s && s.locale,
                        t = j[b + "%" + h + (l ? "%" + l : "")];
                    e && !t && o(s, b, h, {
                        locale: l
                    })
                }), [h, b, w, f, c, s]);
                var A = {
                    ref: T,
                    onClick: function(e) {
                        u.props && "function" === typeof u.props.onClick && u.props.onClick(e), e.defaultPrevented || function(e, c, s, l, t, a, i, r) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var c = e.currentTarget.target;
                                return c && "_self" !== c || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, n.isLocalURL)(s)) && (e.preventDefault(), null == i && (i = l.indexOf("#") < 0), c[t ? "replace" : "push"](s, l, {
                                shallow: a,
                                locale: r,
                                scroll: i
                            }).then((function(e) {
                                e && i && document.body.focus()
                            })))
                        }(e, s, b, h, x, m, O, f)
                    },
                    onMouseEnter: function(e) {
                        (0, n.isLocalURL)(b) && (u.props && "function" === typeof u.props.onMouseEnter && u.props.onMouseEnter(e), o(s, b, h, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === u.type && !("href" in u.props)) {
                    var E = "undefined" !== typeof f ? f : s && s.locale,
                        L = (0, n.getDomainLocale)(h, E, s && s.locales, s && s.domainLocales);
                    A.href = L || (0, n.addBasePath)((0, n.addLocale)(h, E, s && s.defaultLocale))
                }
                return a.default.cloneElement(u, A)
            };
            c.default = d
        },
        vNVm: function(e, c, s) {
            "use strict";
            var l = s("zoAU"),
                t = s("AroE");
            c.__esModule = !0, c.useIntersection = function(e) {
                var c = e.rootMargin,
                    s = e.disabled || !i,
                    t = (0, a.useRef)(),
                    j = (0, a.useState)(!1),
                    o = l(j, 2),
                    d = o[0],
                    b = o[1],
                    h = (0, a.useCallback)((function(e) {
                        t.current && (t.current(), t.current = void 0), s || d || e && e.tagName && (t.current = function(e, c, s) {
                            var l = function(e) {
                                    var c = e.rootMargin || "",
                                        s = r.get(c);
                                    if (s) return s;
                                    var l = new Map,
                                        t = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var c = l.get(e.target),
                                                    s = e.isIntersecting || e.intersectionRatio > 0;
                                                c && s && c(s)
                                            }))
                                        }), e);
                                    return r.set(c, s = {
                                        id: c,
                                        observer: t,
                                        elements: l
                                    }), s
                                }(s),
                                t = l.id,
                                a = l.observer,
                                n = l.elements;
                            return n.set(e, c), a.observe(e),
                                function() {
                                    n.delete(e), a.unobserve(e), 0 === n.size && (a.disconnect(), r.delete(t))
                                }
                        }(e, (function(e) {
                            return e && b(e)
                        }), {
                            rootMargin: c
                        }))
                    }), [s, c, d]);
                return (0, a.useEffect)((function() {
                    i || d || (0, n.default)((function() {
                        return b(!0)
                    }))
                }), [d]), [h, d]
            };
            var a = s("q1tI"),
                n = t(s("0G5g")),
                i = "undefined" !== typeof IntersectionObserver;
            var r = new Map
        }
    },
    [
        ["K8cT", 1, 0, 2]
    ]
]);