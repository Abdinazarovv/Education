_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [36], {
        "7pJ3": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "premium-access-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "premium-access-content",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go at your own pace"
                            }), Object(a.jsx)("h2", {
                                children: "Give their limitless potential unlimited access"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(a.jsx)(t.a, {
                                href: "/membership-levels",
                                children: Object(a.jsxs)("a", {
                                    className: "default-btn",
                                    children: [Object(a.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Give Premium Access ", Object(a.jsx)("span", {})]
                                })
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape3",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape4",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape8",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape7.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        Ix5F: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    i = e.homePageText,
                    l = e.activePageText;
                return Object(a.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(a.jsxs)("ul", {
                                children: [Object(a.jsx)("li", {
                                    children: Object(a.jsx)(t.a, {
                                        href: c,
                                        children: Object(a.jsx)("a", {
                                            children: i
                                        })
                                    })
                                }), Object(a.jsx)("li", {
                                    className: "active",
                                    children: l
                                })]
                            }), Object(a.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        JcBV: function(e, s, c) {
            "use strict";
            var a = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "funfacts-area bg-fffaf3",
                    children: Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "1926"
                                    }), Object(a.jsx)("p", {
                                        children: "Finished Sessions"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "3279"
                                    }), Object(a.jsx)("p", {
                                        children: "Enrolled Learners"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "250"
                                    }), Object(a.jsx)("p", {
                                        children: "Online Instructors"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "100%"
                                    }), Object(a.jsx)("p", {
                                        children: "Satisfaction Rate"
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        cKI9: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/about-3", function() {
                return c("iYO3")
            }])
        },
        "d/qs": function(e, s, c) {
            "use strict";
            var a = c("rePB"),
                i = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                r = c.n(l),
                n = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(a.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(n)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                b = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 1
                        },
                        768: {
                            items: 2
                        },
                        1200: {
                            items: 2
                        }
                    }
                };
            s.a = function() {
                var e = r.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    a = s[1];
                return r.a.useEffect((function() {
                    a(!0)
                }), []), Object(i.jsxs)("div", {
                    className: "feedback-area bg-fffaf3 ptb-100",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: c ? Object(i.jsxs)(o, d(d({
                            className: "feedback-slides-two owl-carousel owl-theme"
                        }, b), {}, {
                            children: [Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "John Smith"
                                        }), Object(i.jsx)("span", {
                                            children: "Python Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user2.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Sarah Taylor"
                                        }), Object(i.jsx)("span", {
                                            children: "PHP Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "David Warner"
                                        }), Object(i.jsx)("span", {
                                            children: "QA Developer"
                                        })]
                                    })]
                                })]
                            })]
                        })) : ""
                    }), Object(i.jsx)("div", {
                        className: "divider2"
                    }), Object(i.jsx)("div", {
                        className: "divider3"
                    }), Object(i.jsx)("div", {
                        className: "shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape2.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape3",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape4",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape9",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        iYO3: function(e, s, c) {
            "use strict";
            c.r(s);
            var a = c("nKUr"),
                i = c("q1tI"),
                t = c.n(i),
                l = c("Ix5F"),
                r = c("YFqc"),
                n = c.n(r),
                j = function() {
                    return Object(a.jsx)("div", {
                        className: "features-area pt-100 pb-70",
                        children: Object(a.jsxs)("div", {
                            className: "container",
                            children: [Object(a.jsxs)("div", {
                                className: "section-title",
                                children: [Object(a.jsx)("span", {
                                    className: "sub-title",
                                    children: "Education for everyone"
                                }), Object(a.jsx)("h2", {
                                    children: "Online Coaching Lessons For Remote Learning"
                                }), Object(a.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "row",
                                children: [Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-features-box without-padding",
                                        children: [Object(a.jsx)("div", {
                                            className: "icon",
                                            children: Object(a.jsx)("i", {
                                                className: "flaticon-brain-process"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: "Learn the Latest Skills"
                                        }), Object(a.jsx)("p", {
                                            children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration."
                                        }), Object(a.jsx)(n.a, {
                                            href: "/profile-authentication",
                                            children: Object(a.jsx)("a", {
                                                className: "link-btn",
                                                children: "Start Now!"
                                            })
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-features-box without-padding",
                                        children: [Object(a.jsx)("div", {
                                            className: "icon",
                                            children: Object(a.jsx)("i", {
                                                className: "flaticon-computer"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: "Go at Your Own Pace"
                                        }), Object(a.jsx)("p", {
                                            children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration."
                                        }), Object(a.jsx)(n.a, {
                                            href: "/profile-authentication",
                                            children: Object(a.jsx)("a", {
                                                className: "link-btn",
                                                children: "Start Now!"
                                            })
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-features-box without-padding",
                                        children: [Object(a.jsx)("div", {
                                            className: "icon",
                                            children: Object(a.jsx)("i", {
                                                className: "flaticon-shield-1"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: "Learn from Industry Experts"
                                        }), Object(a.jsx)("p", {
                                            children: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration."
                                        }), Object(a.jsx)(n.a, {
                                            href: "/profile-authentication",
                                            children: Object(a.jsx)("a", {
                                                className: "link-btn",
                                                children: "Start Now!"
                                            })
                                        })]
                                    })
                                })]
                            })]
                        })
                    })
                },
                d = c("ODXe"),
                o = c("Vvt1"),
                b = c.n(o),
                m = b()((function() {
                    return Promise.all([c.e(0), c.e(6), c.e(8)]).then(c.t.bind(null, "60Bi", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["60Bi"]
                        },
                        modules: ["react-modal-video"]
                    }
                }),
                h = function() {
                    var e = t.a.useState(!1),
                        s = Object(d.a)(e, 2),
                        c = s[0],
                        i = s[1];
                    t.a.useEffect((function() {
                        i(!0)
                    }), []);
                    var l = t.a.useState(!0),
                        r = Object(d.a)(l, 2),
                        j = r[0],
                        o = r[1];
                    return Object(a.jsxs)(t.a.Fragment, {
                        children: [Object(a.jsxs)("div", {
                            className: "about-area-two pb-100",
                            children: [Object(a.jsx)("div", {
                                className: "container",
                                children: Object(a.jsxs)("div", {
                                    className: "row align-items-center",
                                    children: [Object(a.jsx)("div", {
                                        className: "col-lg-5 col-md-12",
                                        children: Object(a.jsxs)("div", {
                                            className: "about-content-box",
                                            children: [Object(a.jsx)("span", {
                                                className: "sub-title",
                                                children: "Distance Learning"
                                            }), Object(a.jsx)("h2", {
                                                children: "Build Your Project Management Skills Online, Anytime"
                                            }), Object(a.jsx)("p", {
                                                children: "Want to learn and earn PDUs or CEUs on your schedule \u2014 anytime, anywhere? Or, pick up a new skill quickly like, project team leadership or agile? Browse our most popular online courses."
                                            }), Object(a.jsx)("p", {
                                                children: Object(a.jsx)("strong", {
                                                    children: "Grow your knowledge and your opportunities with thought leadership, training and tools."
                                                })
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-7 col-md-12",
                                        children: Object(a.jsxs)("div", {
                                            className: "about-video-box",
                                            children: [Object(a.jsx)("div", {
                                                className: "image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/about-img6.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)(n.a, {
                                                href: "#play-video",
                                                children: Object(a.jsx)("a", {
                                                    onClick: function(e) {
                                                        e.preventDefault(), o(!j)
                                                    },
                                                    className: "video-btn popup-youtube",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-play"
                                                    })
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "shape10",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/shape9.png",
                                                    alt: "image"
                                                })
                                            })]
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "shape3",
                                children: Object(a.jsx)("img", {
                                    src: "/images/shape3.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "shape4",
                                children: Object(a.jsx)("img", {
                                    src: "/images/shape4.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "shape2",
                                children: Object(a.jsx)("img", {
                                    src: "/images/shape2.png",
                                    alt: "image"
                                })
                            })]
                        }), c ? Object(a.jsx)(m, {
                            channel: "youtube",
                            isOpen: !j,
                            videoId: "bk7McNUjWgw",
                            onClose: function() {
                                return o(!j)
                            }
                        }) : ""]
                    })
                },
                x = c("d/qs"),
                O = c("rePB");

            function u(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function p(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? u(Object(c), !0).forEach((function(s) {
                        Object(O.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : u(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var g = b()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                v = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 2
                        },
                        768: {
                            items: 2
                        },
                        992: {
                            items: 3
                        }
                    }
                },
                f = function() {
                    var e = t.a.useState(!1),
                        s = Object(d.a)(e, 2),
                        c = s[0],
                        i = s[1];
                    return t.a.useEffect((function() {
                        i(!0)
                    }), []), Object(a.jsx)("div", {
                        className: "advisor-area bg-f9f9f9 ptb-100",
                        children: Object(a.jsxs)("div", {
                            className: "container",
                            children: [Object(a.jsxs)("div", {
                                className: "section-title",
                                children: [Object(a.jsx)("span", {
                                    className: "sub-title",
                                    children: "Course Advisor"
                                }), Object(a.jsx)("h2", {
                                    children: "Meet Our World-class Instructors"
                                }), Object(a.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                })]
                            }), c ? Object(a.jsxs)(g, p(p({
                                className: "advisor-slides-two owl-carousel owl-theme"
                            }, v), {}, {
                                children: [Object(a.jsxs)("div", {
                                    className: "single-advisor-item",
                                    children: [Object(a.jsxs)("div", {
                                        className: "advisor-image",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/advisor/advisor4.jpg",
                                            alt: "image"
                                        }), Object(a.jsxs)("ul", {
                                            className: "social-link",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-facebook"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-twitter"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-instagram"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-linkedin"
                                                    })
                                                })
                                            })]
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "advisor-content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(n.a, {
                                                href: "/profile",
                                                children: Object(a.jsx)("a", {
                                                    children: "James Andy"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            children: "Project Management Expert"
                                        })]
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "single-advisor-item",
                                    children: [Object(a.jsxs)("div", {
                                        className: "advisor-image",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/advisor/advisor5.jpg",
                                            alt: "image"
                                        }), Object(a.jsxs)("ul", {
                                            className: "social-link",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-facebook"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-twitter"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-instagram"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-linkedin"
                                                    })
                                                })
                                            })]
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "advisor-content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(n.a, {
                                                href: "/profile",
                                                children: Object(a.jsx)("a", {
                                                    children: "Jassica Hische"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            children: "Illustrator Expert"
                                        })]
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "single-advisor-item",
                                    children: [Object(a.jsxs)("div", {
                                        className: "advisor-image",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/advisor/advisor6.jpg",
                                            alt: "image"
                                        }), Object(a.jsxs)("ul", {
                                            className: "social-link",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-facebook"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-twitter"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-instagram"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-linkedin"
                                                    })
                                                })
                                            })]
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "advisor-content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(n.a, {
                                                href: "/profile",
                                                children: Object(a.jsx)("a", {
                                                    children: "Alister Cock"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            children: "QA Project Expert"
                                        })]
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "single-advisor-item",
                                    children: [Object(a.jsxs)("div", {
                                        className: "advisor-image",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/advisor/advisor7.jpg",
                                            alt: "image"
                                        }), Object(a.jsxs)("ul", {
                                            className: "social-link",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-facebook"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-twitter"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-instagram"
                                                    })
                                                })
                                            }), Object(a.jsx)("li", {
                                                children: Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "d-block",
                                                    target: "_blank",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bxl-linkedin"
                                                    })
                                                })
                                            })]
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "advisor-content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(n.a, {
                                                href: "/profile",
                                                children: Object(a.jsx)("a", {
                                                    children: "Lina Ninja"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            children: "QA Project Expert"
                                        })]
                                    })]
                                })]
                            })) : ""]
                        })
                    })
                },
                N = c("JcBV"),
                k = c("7pJ3");
            s.default = function() {
                return Object(a.jsxs)(t.a.Fragment, {
                    children: [Object(a.jsx)(l.a, {
                        pageTitle: "About Us",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "About Us"
                    }), Object(a.jsx)(j, {}), Object(a.jsx)(h, {}), Object(a.jsx)(x.a, {}), Object(a.jsx)(f, {}), Object(a.jsx)(N.a, {}), Object(a.jsx)("div", {
                        className: "ptb-100",
                        children: Object(a.jsx)(k.a, {})
                    })]
                })
            }
        },
        rePB: function(e, s, c) {
            "use strict";

            function a(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return a
            }))
        }
    },
    [
        ["cKI9", 1, 0, 2, 4]
    ]
]);