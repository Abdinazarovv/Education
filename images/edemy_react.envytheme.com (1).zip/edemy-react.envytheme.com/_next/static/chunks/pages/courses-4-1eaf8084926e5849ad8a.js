_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [55], {
        I8AR: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/courses-4", function() {
                return c("a+Ml")
            }])
        },
        Ix5F: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                t = (c("q1tI"), c("YFqc")),
                i = c.n(t);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    t = e.homePageText,
                    r = e.activePageText;
                return Object(a.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(a.jsxs)("ul", {
                                children: [Object(a.jsx)("li", {
                                    children: Object(a.jsx)(i.a, {
                                        href: c,
                                        children: Object(a.jsx)("a", {
                                            children: t
                                        })
                                    })
                                }), Object(a.jsx)("li", {
                                    className: "active",
                                    children: r
                                })]
                            }), Object(a.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        "a+Ml": function(e, s, c) {
            "use strict";
            c.r(s);
            var a = c("nKUr"),
                t = c("q1tI"),
                i = c.n(t),
                r = c("Ix5F"),
                l = c("YFqc"),
                j = c.n(l);
            s.default = function() {
                return Object(a.jsxs)(i.a.Fragment, {
                    children: [Object(a.jsx)(r.a, {
                        pageTitle: "Courses Grid 04",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Courses Grid 04"
                    }), Object(a.jsx)("div", {
                        className: "courses-area courses-section pt-100 pb-70",
                        children: Object(a.jsxs)("div", {
                            className: "container",
                            children: [Object(a.jsxs)("div", {
                                className: "edemy-grid-sorting row align-items-center",
                                children: [Object(a.jsx)("div", {
                                    className: "col-lg-8 col-md-6 result-count",
                                    children: Object(a.jsxs)("p", {
                                        children: ["We found ", Object(a.jsx)("span", {
                                            className: "count",
                                            children: "12"
                                        }), " courses available for you"]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6 ordering",
                                    children: Object(a.jsx)("div", {
                                        className: "select-box",
                                        children: Object(a.jsxs)("select", {
                                            className: "form-control",
                                            children: [Object(a.jsx)("option", {
                                                children: "Sort By"
                                            }), Object(a.jsx)("option", {
                                                children: "Popularity"
                                            }), Object(a.jsx)("option", {
                                                children: "Latest"
                                            }), Object(a.jsx)("option", {
                                                children: "Price: low to high"
                                            }), Object(a.jsx)("option", {
                                                children: "Price: high to low"
                                            })]
                                        })
                                    })
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "row",
                                children: [Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses12.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$39"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Agile Crash Course: Agile Project Management"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (1 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses13.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$59"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Vue JS 2 - The Complete Guide (incl. Vue Router & Vuex)"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (2 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses14.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$69"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "The Python Bible\u2122 | Everything You Need to Program in Python"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (3 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses15.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$79"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Mathematical Foundation For Machine Learning and AI"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (4 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses16.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$89"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "The Ultimate Drawing Course - Beginner to Advanced"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (5 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses17.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$99"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "PyTorch: Deep Learning and Artificial Intelligence"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (6 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses1.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$39"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Azure Machine Learning Certification- AZ AI100"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (1 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses2.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$59"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Statistics for Data Science and Business Analysis"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (2 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses3.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$69"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Data Science & Deep Learning for Business\u2122 20 Case Studies"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (3 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses4.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$79"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Introduction to Machine Learning for Data Science"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (4 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses5.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$89"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Microsoft Excel - Excel from Beginner to Advanced"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (5 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-courses-item-box",
                                        children: [Object(a.jsxs)("div", {
                                            className: "courses-image",
                                            children: [Object(a.jsx)("a", {
                                                href: "/single-courses-1",
                                                className: "d-block image",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/courses/courses6.jpg",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("a", {
                                                href: "#",
                                                className: "fav",
                                                children: Object(a.jsx)("i", {
                                                    className: "flaticon-heart"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "price shadow",
                                                children: "$99"
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "courses-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Python Django Web Development: To-Do App"
                                                    })
                                                })
                                            }), Object(a.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("i", {
                                                    className: "bx bxs-star"
                                                }), Object(a.jsx)("div", {
                                                    className: "rating-total",
                                                    children: "5.0 (6 rating)"
                                                })]
                                            })]
                                        })]
                                    })
                                })]
                            })]
                        })
                    })]
                })
            }
        },
        cTJO: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                t = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var i = t(c("q1tI")),
                r = c("elyg"),
                l = c("nOHt"),
                j = c("vNVm"),
                n = {};

            function b(e, s, c, a) {
                if (e && (0, r.isLocalURL)(s)) {
                    e.prefetch(s, c, a).catch((function(e) {
                        0
                    }));
                    var t = a && "undefined" !== typeof a.locale ? a.locale : e && e.locale;
                    n[s + "%" + c + (t ? "%" + t : "")] = !0
                }
            }
            var x = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, l.useRouter)(),
                    t = c && c.pathname || "/",
                    x = i.default.useMemo((function() {
                        var s = (0, r.resolveHref)(t, e.href, !0),
                            c = a(s, 2),
                            i = c[0],
                            l = c[1];
                        return {
                            href: i,
                            as: e.as ? (0, r.resolveHref)(t, e.as) : l || i
                        }
                    }), [t, e.href, e.as]),
                    o = x.href,
                    d = x.as,
                    m = e.children,
                    h = e.replace,
                    O = e.shallow,
                    g = e.scroll,
                    u = e.locale;
                "string" === typeof m && (m = i.default.createElement("a", null, m));
                var N = i.Children.only(m),
                    v = N && "object" === typeof N && N.ref,
                    f = (0, j.useIntersection)({
                        rootMargin: "200px"
                    }),
                    p = a(f, 2),
                    w = p[0],
                    y = p[1],
                    M = i.default.useCallback((function(e) {
                        w(e), v && ("function" === typeof v ? v(e) : "object" === typeof v && (v.current = e))
                    }), [v, w]);
                (0, i.useEffect)((function() {
                    var e = y && s && (0, r.isLocalURL)(o),
                        a = "undefined" !== typeof u ? u : c && c.locale,
                        t = n[o + "%" + d + (a ? "%" + a : "")];
                    e && !t && b(c, o, d, {
                        locale: a
                    })
                }), [d, o, y, u, s, c]);
                var k = {
                    ref: M,
                    onClick: function(e) {
                        N.props && "function" === typeof N.props.onClick && N.props.onClick(e), e.defaultPrevented || function(e, s, c, a, t, i, l, j) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, r.isLocalURL)(c)) && (e.preventDefault(), null == l && (l = a.indexOf("#") < 0), s[t ? "replace" : "push"](c, a, {
                                shallow: i,
                                locale: j,
                                scroll: l
                            }).then((function(e) {
                                e && l && document.body.focus()
                            })))
                        }(e, c, o, d, h, O, g, u)
                    },
                    onMouseEnter: function(e) {
                        (0, r.isLocalURL)(o) && (N.props && "function" === typeof N.props.onMouseEnter && N.props.onMouseEnter(e), b(c, o, d, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === N.type && !("href" in N.props)) {
                    var E = "undefined" !== typeof u ? u : c && c.locale,
                        P = (0, r.getDomainLocale)(d, E, c && c.locales, c && c.domainLocales);
                    k.href = P || (0, r.addBasePath)((0, r.addLocale)(d, E, c && c.defaultLocale))
                }
                return i.default.cloneElement(N, k)
            };
            s.default = x
        },
        vNVm: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                t = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !l,
                    t = (0, i.useRef)(),
                    n = (0, i.useState)(!1),
                    b = a(n, 2),
                    x = b[0],
                    o = b[1],
                    d = (0, i.useCallback)((function(e) {
                        t.current && (t.current(), t.current = void 0), c || x || e && e.tagName && (t.current = function(e, s, c) {
                            var a = function(e) {
                                    var s = e.rootMargin || "",
                                        c = j.get(s);
                                    if (c) return c;
                                    var a = new Map,
                                        t = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = a.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return j.set(s, c = {
                                        id: s,
                                        observer: t,
                                        elements: a
                                    }), c
                                }(c),
                                t = a.id,
                                i = a.observer,
                                r = a.elements;
                            return r.set(e, s), i.observe(e),
                                function() {
                                    r.delete(e), i.unobserve(e), 0 === r.size && (i.disconnect(), j.delete(t))
                                }
                        }(e, (function(e) {
                            return e && o(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, x]);
                return (0, i.useEffect)((function() {
                    l || x || (0, r.default)((function() {
                        return o(!0)
                    }))
                }), [x]), [d, x]
            };
            var i = c("q1tI"),
                r = t(c("0G5g")),
                l = "undefined" !== typeof IntersectionObserver;
            var j = new Map
        }
    },
    [
        ["I8AR", 1, 0, 2]
    ]
]);