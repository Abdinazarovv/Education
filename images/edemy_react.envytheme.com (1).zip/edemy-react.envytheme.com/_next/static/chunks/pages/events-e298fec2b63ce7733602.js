_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [62], {
        Ix5F: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                n = (c("q1tI"), c("YFqc")),
                t = c.n(n);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    n = e.homePageText,
                    i = e.activePageText;
                return Object(a.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(a.jsxs)("ul", {
                                children: [Object(a.jsx)("li", {
                                    children: Object(a.jsx)(t.a, {
                                        href: c,
                                        children: Object(a.jsx)("a", {
                                            children: n
                                        })
                                    })
                                }), Object(a.jsx)("li", {
                                    className: "active",
                                    children: i
                                })]
                            }), Object(a.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        UGbB: function(e, s, c) {
            "use strict";
            c.r(s);
            var a = c("nKUr"),
                n = c("q1tI"),
                t = c.n(n),
                i = c("Ix5F"),
                l = c("YFqc"),
                r = c.n(l),
                j = c("ur7V");
            s.default = function() {
                return Object(a.jsxs)(t.a.Fragment, {
                    children: [Object(a.jsx)(i.a, {
                        pageTitle: "Events",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Events"
                    }), Object(a.jsx)("div", {
                        className: "events-area pt-100 pb-70",
                        children: Object(a.jsx)("div", {
                            className: "container",
                            children: Object(a.jsx)("div", {
                                className: "shorting",
                                children: Object(a.jsxs)("div", {
                                    className: "row",
                                    children: [Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events1.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Wed, 20 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Global Conference on Business Management"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Vancover, Canada"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events2.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Tue, 19 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "International Conference on Teacher Education"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Sydney, Australia"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events3.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Mon, 18 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "International Conference on Special Needs Education"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Istanbul, Turkey"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events4.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Sun, 17 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "International Conference on Literacy Teaching"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Athens, Greece"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events5.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Sat, 16 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "International Conference on Educational Administration"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Rome, Italy"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events6.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Fri, 15 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "International Conference on Education and Pedagogy"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Athens, Greece"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events7.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Thu, 14 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Research Conference Aims and Objectives"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Tokyo, Japan"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events8.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Wed, 13 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Conference on Gender Discrimination in Education"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Oslo, Norway"]
                                                })]
                                            })]
                                        })
                                    }), Object(a.jsx)("div", {
                                        className: "col-lg-4 col-sm-6 col-md-6",
                                        children: Object(a.jsxs)("div", {
                                            className: "single-events-box",
                                            children: [Object(a.jsxs)("div", {
                                                className: "image",
                                                children: [Object(a.jsx)(r.a, {
                                                    href: "/single-events",
                                                    children: Object(a.jsx)("a", {
                                                        className: "d-block",
                                                        children: Object(a.jsx)("img", {
                                                            src: "/images/events/events9.jpg",
                                                            alt: "image"
                                                        })
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "date",
                                                    children: "Tue, 12 May, 2020"
                                                })]
                                            }), Object(a.jsxs)("div", {
                                                className: "content",
                                                children: [Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(r.a, {
                                                        href: "/single-events",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Quality and Improvement in Education Conference"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(a.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Tokyo, Japan"]
                                                })]
                                            })]
                                        })
                                    })]
                                })
                            })
                        })
                    }), Object(a.jsx)(j.a, {})]
                })
            }
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        cTJO: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                n = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var t = n(c("q1tI")),
                i = c("elyg"),
                l = c("nOHt"),
                r = c("vNVm"),
                j = {};

            function d(e, s, c, a) {
                if (e && (0, i.isLocalURL)(s)) {
                    e.prefetch(s, c, a).catch((function(e) {
                        0
                    }));
                    var n = a && "undefined" !== typeof a.locale ? a.locale : e && e.locale;
                    j[s + "%" + c + (n ? "%" + n : "")] = !0
                }
            }
            var o = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, l.useRouter)(),
                    n = c && c.pathname || "/",
                    o = t.default.useMemo((function() {
                        var s = (0, i.resolveHref)(n, e.href, !0),
                            c = a(s, 2),
                            t = c[0],
                            l = c[1];
                        return {
                            href: t,
                            as: e.as ? (0, i.resolveHref)(n, e.as) : l || t
                        }
                    }), [n, e.href, e.as]),
                    b = o.href,
                    m = o.as,
                    h = e.children,
                    x = e.replace,
                    O = e.shallow,
                    v = e.scroll,
                    u = e.locale;
                "string" === typeof h && (h = t.default.createElement("a", null, h));
                var g = t.Children.only(h),
                    f = g && "object" === typeof g && g.ref,
                    p = (0, r.useIntersection)({
                        rootMargin: "200px"
                    }),
                    N = a(p, 2),
                    y = N[0],
                    E = N[1],
                    M = t.default.useCallback((function(e) {
                        y(e), f && ("function" === typeof f ? f(e) : "object" === typeof f && (f.current = e))
                    }), [f, y]);
                (0, t.useEffect)((function() {
                    var e = E && s && (0, i.isLocalURL)(b),
                        a = "undefined" !== typeof u ? u : c && c.locale,
                        n = j[b + "%" + m + (a ? "%" + a : "")];
                    e && !n && d(c, b, m, {
                        locale: a
                    })
                }), [m, b, E, u, s, c]);
                var w = {
                    ref: M,
                    onClick: function(e) {
                        g.props && "function" === typeof g.props.onClick && g.props.onClick(e), e.defaultPrevented || function(e, s, c, a, n, t, l, r) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, i.isLocalURL)(c)) && (e.preventDefault(), null == l && (l = a.indexOf("#") < 0), s[n ? "replace" : "push"](c, a, {
                                shallow: t,
                                locale: r,
                                scroll: l
                            }).then((function(e) {
                                e && l && document.body.focus()
                            })))
                        }(e, c, b, m, x, O, v, u)
                    },
                    onMouseEnter: function(e) {
                        (0, i.isLocalURL)(b) && (g.props && "function" === typeof g.props.onMouseEnter && g.props.onMouseEnter(e), d(c, b, m, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === g.type && !("href" in g.props)) {
                    var I = "undefined" !== typeof u ? u : c && c.locale,
                        T = (0, i.getDomainLocale)(m, I, c && c.locales, c && c.domainLocales);
                    w.href = T || (0, i.addBasePath)((0, i.addLocale)(m, I, c && c.defaultLocale))
                }
                return t.default.cloneElement(g, w)
            };
            s.default = o
        },
        f8ys: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/events", function() {
                return c("UGbB")
            }])
        },
        ur7V: function(e, s, c) {
            "use strict";
            var a = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "subscribe-area bg-f9f9f9 ptb-100",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "subscribe-content",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go At Your Own Pace"
                            }), Object(a.jsx)("h2", {
                                children: "Subscribe To Our Newsletter"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(a.jsxs)("form", {
                                className: "newsletter-form",
                                children: [Object(a.jsx)("input", {
                                    type: "text",
                                    className: "input-newsletter",
                                    placeholder: "Enter your email address",
                                    name: "EMAIL",
                                    required: !0
                                }), Object(a.jsxs)("button", {
                                    type: "submit",
                                    className: "default-btn",
                                    children: [Object(a.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Subscribe Now ", Object(a.jsx)("span", {})]
                                })]
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape4",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape13",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape12.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape14",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape13.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape15",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape14.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        vNVm: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                n = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !l,
                    n = (0, t.useRef)(),
                    j = (0, t.useState)(!1),
                    d = a(j, 2),
                    o = d[0],
                    b = d[1],
                    m = (0, t.useCallback)((function(e) {
                        n.current && (n.current(), n.current = void 0), c || o || e && e.tagName && (n.current = function(e, s, c) {
                            var a = function(e) {
                                    var s = e.rootMargin || "",
                                        c = r.get(s);
                                    if (c) return c;
                                    var a = new Map,
                                        n = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = a.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return r.set(s, c = {
                                        id: s,
                                        observer: n,
                                        elements: a
                                    }), c
                                }(c),
                                n = a.id,
                                t = a.observer,
                                i = a.elements;
                            return i.set(e, s), t.observe(e),
                                function() {
                                    i.delete(e), t.unobserve(e), 0 === i.size && (t.disconnect(), r.delete(n))
                                }
                        }(e, (function(e) {
                            return e && b(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, o]);
                return (0, t.useEffect)((function() {
                    l || o || (0, i.default)((function() {
                        return b(!0)
                    }))
                }), [o]), [m, o]
            };
            var t = c("q1tI"),
                i = n(c("0G5g")),
                l = "undefined" !== typeof IntersectionObserver;
            var r = new Map
        }
    },
    [
        ["f8ys", 1, 0, 2]
    ]
]);