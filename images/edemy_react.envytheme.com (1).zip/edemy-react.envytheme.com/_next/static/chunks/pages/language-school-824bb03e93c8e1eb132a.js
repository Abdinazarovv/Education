_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [76], {
        dNvt: function(j, t, c) {
            "use strict";
            c.r(t);
            var e = c("nKUr"),
                n = c("q1tI"),
                s = c.n(n),
                a = c("ngeS"),
                b = c("RWYh"),
                u = c("Oebb"),
                O = c("S+AA"),
                o = c("Dqg+"),
                r = c("JcBV"),
                x = c("hj2d"),
                _ = c("rDzp"),
                i = c("bQbf"),
                w = c("L4uS"),
                d = c("ur7V");
            t.default = function() {
                return Object(e.jsxs)(s.a.Fragment, {
                    children: [Object(e.jsx)(a.a, {}), Object(e.jsx)(b.a, {}), Object(e.jsx)(u.a, {}), Object(e.jsx)(O.a, {}), Object(e.jsx)(o.a, {}), Object(e.jsx)(r.a, {}), Object(e.jsx)(x.a, {}), Object(e.jsx)(_.a, {}), Object(e.jsx)(i.a, {}), Object(e.jsx)(d.a, {}), Object(e.jsx)(w.a, {})]
                })
            }
        },
        "yc+Y": function(j, t, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/language-school", function() {
                return c("dNvt")
            }])
        }
    },
    [
        ["yc+Y", 1, 0, 2, 4, 22]
    ]
]);