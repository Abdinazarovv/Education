_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [84], {
        CeGh: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/products-list-2", function() {
                return c("SxHr")
            }])
        },
        Ix5F: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                t = (c("q1tI"), c("YFqc")),
                l = c.n(t);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    t = e.homePageText,
                    i = e.activePageText;
                return Object(a.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(a.jsxs)("ul", {
                                children: [Object(a.jsx)("li", {
                                    children: Object(a.jsx)(l.a, {
                                        href: c,
                                        children: Object(a.jsx)("a", {
                                            children: t
                                        })
                                    })
                                }), Object(a.jsx)("li", {
                                    className: "active",
                                    children: i
                                })]
                            }), Object(a.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        SxHr: function(e, s, c) {
            "use strict";
            c.r(s);
            var a = c("nKUr"),
                t = c("q1tI"),
                l = c.n(t),
                i = c("Ix5F"),
                r = c("YFqc"),
                j = c.n(r),
                n = function() {
                    return Object(a.jsxs)("div", {
                        className: "widget-area",
                        children: [Object(a.jsxs)("div", {
                            className: "widget widget_search",
                            children: [Object(a.jsx)("h3", {
                                className: "widget-title",
                                children: "Search"
                            }), Object(a.jsxs)("form", {
                                className: "search-form",
                                children: [Object(a.jsx)("label", {
                                    children: Object(a.jsx)("input", {
                                        type: "search",
                                        className: "search-field",
                                        placeholder: "Search..."
                                    })
                                }), Object(a.jsx)("button", {
                                    type: "submit",
                                    children: Object(a.jsx)("i", {
                                        className: "bx bx-search-alt"
                                    })
                                })]
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "widget widget_popular_products",
                            children: [Object(a.jsx)("h3", {
                                className: "widget-title",
                                children: "Popular Products"
                            }), Object(a.jsxs)("div", {
                                className: "item",
                                children: [Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsx)("a", {
                                        className: "thumb",
                                        children: Object(a.jsx)("span", {
                                            className: "fullimage cover bg1",
                                            role: "img"
                                        })
                                    })
                                }), Object(a.jsxs)("div", {
                                    className: "info",
                                    children: [Object(a.jsx)("span", {
                                        children: "$49.00"
                                    }), Object(a.jsx)("h4", {
                                        className: "title usmall",
                                        children: Object(a.jsx)(j.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                children: "Random Romance Novel Title Generator"
                                            })
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "rating",
                                        children: [Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        })]
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "clear"
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "item",
                                children: [Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsx)("a", {
                                        className: "thumb",
                                        children: Object(a.jsx)("span", {
                                            className: "fullimage cover bg2",
                                            role: "img"
                                        })
                                    })
                                }), Object(a.jsxs)("div", {
                                    className: "info",
                                    children: [Object(a.jsx)("span", {
                                        children: "$59.00"
                                    }), Object(a.jsx)("h4", {
                                        className: "title usmall",
                                        children: Object(a.jsx)(j.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                children: "Writing Exercises Story Title Ideas"
                                            })
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "rating",
                                        children: [Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        })]
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "clear"
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "item",
                                children: [Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsx)("a", {
                                        className: "thumb",
                                        children: Object(a.jsx)("span", {
                                            className: "fullimage cover bg3",
                                            role: "img"
                                        })
                                    })
                                }), Object(a.jsxs)("div", {
                                    className: "info",
                                    children: [Object(a.jsx)("span", {
                                        children: "$69.00"
                                    }), Object(a.jsx)("h4", {
                                        className: "title usmall",
                                        children: Object(a.jsx)(j.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                children: "Amaze Story Kitt Net's Book Ideas"
                                            })
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "rating",
                                        children: [Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        }), Object(a.jsx)("i", {
                                            className: "bx bxs-star"
                                        })]
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "clear"
                                })]
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "widget widget_tag_cloud",
                            children: [Object(a.jsx)("h3", {
                                className: "widget-title",
                                children: "Popular Tags"
                            }), Object(a.jsxs)("div", {
                                className: "tagcloud",
                                children: [Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Business ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(3)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Design ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(3)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Digital ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["SEO ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Braike ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Fashion ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Software ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Travel ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(1)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Smart ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(1)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Marketing ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(1)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Tips ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(j.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Website ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                })]
                            })]
                        })]
                    })
                };
            s.default = function() {
                return Object(a.jsxs)(l.a.Fragment, {
                    children: [Object(a.jsx)(i.a, {
                        pageTitle: "Shop",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Shop"
                    }), Object(a.jsx)("div", {
                        className: "products-area ptb-100",
                        children: Object(a.jsx)("div", {
                            className: "container",
                            children: Object(a.jsxs)("div", {
                                className: "row",
                                children: [Object(a.jsxs)("div", {
                                    className: "col-lg-8 col-md-12",
                                    children: [Object(a.jsxs)("div", {
                                        className: "edemy-grid-sorting row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-6 result-count",
                                            children: Object(a.jsxs)("p", {
                                                children: ["We found ", Object(a.jsx)("span", {
                                                    className: "count",
                                                    children: "9"
                                                }), " products available for you"]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-6 ordering",
                                            children: Object(a.jsx)("div", {
                                                className: "select-box",
                                                children: Object(a.jsxs)("select", {
                                                    className: "form-control",
                                                    children: [Object(a.jsx)("option", {
                                                        children: "Sort By:"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Popularity"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Latest"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Price: low to high"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Price: high to low"
                                                    })]
                                                })
                                            })
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "row",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-products-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "products-image",
                                                    children: [Object(a.jsx)(j.a, {
                                                        href: "/single-products",
                                                        children: Object(a.jsx)("a", {
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/products/product1.jpg",
                                                                className: "main-image",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "products-button",
                                                        children: Object(a.jsx)("ul", {
                                                            children: Object(a.jsx)("li", {
                                                                children: Object(a.jsx)("div", {
                                                                    className: "wishlist-btn",
                                                                    children: Object(a.jsxs)("a", {
                                                                        href: "#",
                                                                        children: [Object(a.jsx)("i", {
                                                                            className: "bx bx-heart"
                                                                        }), Object(a.jsx)("span", {
                                                                            className: "tooltip-label",
                                                                            children: "Add to Wishlist"
                                                                        })]
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "products-content",
                                                    children: [Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(j.a, {
                                                            href: "/single-products",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Note Book Mockup"
                                                            })
                                                        })
                                                    }), Object(a.jsxs)("div", {
                                                        className: "price",
                                                        children: [Object(a.jsx)("span", {
                                                            className: "old-price",
                                                            children: "$321"
                                                        }), Object(a.jsx)("span", {
                                                            className: "new-price",
                                                            children: "$250"
                                                        })]
                                                    }), Object(a.jsxs)("div", {
                                                        className: "star-rating",
                                                        children: [Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "add-to-cart",
                                                        children: "Add to Cart"
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-products-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "products-image",
                                                    children: [Object(a.jsx)(j.a, {
                                                        href: "/single-products",
                                                        children: Object(a.jsx)("a", {
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/products/product2.jpg",
                                                                className: "main-image",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "products-button",
                                                        children: Object(a.jsx)("ul", {
                                                            children: Object(a.jsx)("li", {
                                                                children: Object(a.jsx)("div", {
                                                                    className: "wishlist-btn",
                                                                    children: Object(a.jsxs)("a", {
                                                                        href: "#",
                                                                        children: [Object(a.jsx)("i", {
                                                                            className: "bx bx-heart"
                                                                        }), Object(a.jsx)("span", {
                                                                            className: "tooltip-label",
                                                                            children: "Add to Wishlist"
                                                                        })]
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "sale-tag",
                                                        children: "Sale!"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "products-content",
                                                    children: [Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(j.a, {
                                                            href: "/single-products",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Motivational Book Cover"
                                                            })
                                                        })
                                                    }), Object(a.jsxs)("div", {
                                                        className: "price",
                                                        children: [Object(a.jsx)("span", {
                                                            className: "old-price",
                                                            children: "$210"
                                                        }), Object(a.jsx)("span", {
                                                            className: "new-price",
                                                            children: "$200"
                                                        })]
                                                    }), Object(a.jsxs)("div", {
                                                        className: "star-rating",
                                                        children: [Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "add-to-cart",
                                                        children: "Add to Cart"
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-products-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "products-image",
                                                    children: [Object(a.jsx)(j.a, {
                                                        href: "/single-products",
                                                        children: Object(a.jsx)("a", {
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/products/product3.jpg",
                                                                className: "main-image",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "products-button",
                                                        children: Object(a.jsx)("ul", {
                                                            children: Object(a.jsx)("li", {
                                                                children: Object(a.jsx)("div", {
                                                                    className: "wishlist-btn",
                                                                    children: Object(a.jsxs)("a", {
                                                                        href: "#",
                                                                        children: [Object(a.jsx)("i", {
                                                                            className: "bx bx-heart"
                                                                        }), Object(a.jsx)("span", {
                                                                            className: "tooltip-label",
                                                                            children: "Add to Wishlist"
                                                                        })]
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "products-content",
                                                    children: [Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(j.a, {
                                                            href: "/single-products",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Book Cover Softcover"
                                                            })
                                                        })
                                                    }), Object(a.jsxs)("div", {
                                                        className: "price",
                                                        children: [Object(a.jsx)("span", {
                                                            className: "old-price",
                                                            children: "$210"
                                                        }), Object(a.jsx)("span", {
                                                            className: "new-price",
                                                            children: "$200"
                                                        })]
                                                    }), Object(a.jsxs)("div", {
                                                        className: "star-rating",
                                                        children: [Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "add-to-cart",
                                                        children: "Add to Cart"
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-products-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "products-image",
                                                    children: [Object(a.jsx)(j.a, {
                                                        href: "/single-products",
                                                        children: Object(a.jsx)("a", {
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/products/product4.jpg",
                                                                className: "main-image",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "products-button",
                                                        children: Object(a.jsx)("ul", {
                                                            children: Object(a.jsx)("li", {
                                                                children: Object(a.jsx)("div", {
                                                                    className: "wishlist-btn",
                                                                    children: Object(a.jsxs)("a", {
                                                                        href: "#",
                                                                        children: [Object(a.jsx)("i", {
                                                                            className: "bx bx-heart"
                                                                        }), Object(a.jsx)("span", {
                                                                            className: "tooltip-label",
                                                                            children: "Add to Wishlist"
                                                                        })]
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "products-content",
                                                    children: [Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(j.a, {
                                                            href: "/single-products",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Stop and Take a Second"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price",
                                                        children: Object(a.jsx)("span", {
                                                            className: "new-price",
                                                            children: "$150"
                                                        })
                                                    }), Object(a.jsxs)("div", {
                                                        className: "star-rating",
                                                        children: [Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "add-to-cart",
                                                        children: "Add to Cart"
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-products-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "products-image",
                                                    children: [Object(a.jsx)(j.a, {
                                                        href: "/single-products",
                                                        children: Object(a.jsx)("a", {
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/products/product5.jpg",
                                                                className: "main-image",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "products-button",
                                                        children: Object(a.jsx)("ul", {
                                                            children: Object(a.jsx)("li", {
                                                                children: Object(a.jsx)("div", {
                                                                    className: "wishlist-btn",
                                                                    children: Object(a.jsxs)("a", {
                                                                        href: "#",
                                                                        children: [Object(a.jsx)("i", {
                                                                            className: "bx bx-heart"
                                                                        }), Object(a.jsx)("span", {
                                                                            className: "tooltip-label",
                                                                            children: "Add to Wishlist"
                                                                        })]
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "products-content",
                                                    children: [Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(j.a, {
                                                            href: "/single-products",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Real Life Fairytale"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price",
                                                        children: Object(a.jsx)("span", {
                                                            className: "new-price",
                                                            children: "$240"
                                                        })
                                                    }), Object(a.jsxs)("div", {
                                                        className: "star-rating",
                                                        children: [Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "add-to-cart",
                                                        children: "Add to Cart"
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-products-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "products-image",
                                                    children: [Object(a.jsx)(j.a, {
                                                        href: "/single-products",
                                                        children: Object(a.jsx)("a", {
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/products/product6.jpg",
                                                                className: "main-image",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "products-button",
                                                        children: Object(a.jsx)("ul", {
                                                            children: Object(a.jsx)("li", {
                                                                children: Object(a.jsx)("div", {
                                                                    className: "wishlist-btn",
                                                                    children: Object(a.jsxs)("a", {
                                                                        href: "#",
                                                                        children: [Object(a.jsx)("i", {
                                                                            className: "bx bx-heart"
                                                                        }), Object(a.jsx)("span", {
                                                                            className: "tooltip-label",
                                                                            children: "Add to Wishlist"
                                                                        })]
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "new-tag",
                                                        children: "New!"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "products-content",
                                                    children: [Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(j.a, {
                                                            href: "/single-products",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Running From Me"
                                                            })
                                                        })
                                                    }), Object(a.jsxs)("div", {
                                                        className: "price",
                                                        children: [Object(a.jsx)("span", {
                                                            className: "old-price",
                                                            children: "$150"
                                                        }), Object(a.jsx)("span", {
                                                            className: "new-price",
                                                            children: "$100"
                                                        })]
                                                    }), Object(a.jsxs)("div", {
                                                        className: "star-rating",
                                                        children: [Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(a.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "add-to-cart",
                                                        children: "Add to Cart"
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-12 col-md-12 col-sm-12",
                                            children: Object(a.jsxs)("div", {
                                                className: "pagination-area text-center",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "prev page-numbers",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bx-chevrons-left"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "page-numbers current",
                                                    "aria-current": "page",
                                                    children: "1"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "2"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "3"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "4"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "next page-numbers",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bx-chevrons-right"
                                                    })
                                                })]
                                            })
                                        })]
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-12",
                                    children: Object(a.jsx)(n, {})
                                })]
                            })
                        })
                    })]
                })
            }
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        cTJO: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                t = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var l = t(c("q1tI")),
                i = c("elyg"),
                r = c("nOHt"),
                j = c("vNVm"),
                n = {};

            function d(e, s, c, a) {
                if (e && (0, i.isLocalURL)(s)) {
                    e.prefetch(s, c, a).catch((function(e) {
                        0
                    }));
                    var t = a && "undefined" !== typeof a.locale ? a.locale : e && e.locale;
                    n[s + "%" + c + (t ? "%" + t : "")] = !0
                }
            }
            var b = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, r.useRouter)(),
                    t = c && c.pathname || "/",
                    b = l.default.useMemo((function() {
                        var s = (0, i.resolveHref)(t, e.href, !0),
                            c = a(s, 2),
                            l = c[0],
                            r = c[1];
                        return {
                            href: l,
                            as: e.as ? (0, i.resolveHref)(t, e.as) : r || l
                        }
                    }), [t, e.href, e.as]),
                    x = b.href,
                    o = b.as,
                    h = e.children,
                    m = e.replace,
                    O = e.shallow,
                    N = e.scroll,
                    u = e.locale;
                "string" === typeof h && (h = l.default.createElement("a", null, h));
                var p = l.Children.only(h),
                    g = p && "object" === typeof p && p.ref,
                    f = (0, j.useIntersection)({
                        rootMargin: "200px"
                    }),
                    v = a(f, 2),
                    w = v[0],
                    y = v[1],
                    k = l.default.useCallback((function(e) {
                        w(e), g && ("function" === typeof g ? g(e) : "object" === typeof g && (g.current = e))
                    }), [g, w]);
                (0, l.useEffect)((function() {
                    var e = y && s && (0, i.isLocalURL)(x),
                        a = "undefined" !== typeof u ? u : c && c.locale,
                        t = n[x + "%" + o + (a ? "%" + a : "")];
                    e && !t && d(c, x, o, {
                        locale: a
                    })
                }), [o, x, y, u, s, c]);
                var _ = {
                    ref: k,
                    onClick: function(e) {
                        p.props && "function" === typeof p.props.onClick && p.props.onClick(e), e.defaultPrevented || function(e, s, c, a, t, l, r, j) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, i.isLocalURL)(c)) && (e.preventDefault(), null == r && (r = a.indexOf("#") < 0), s[t ? "replace" : "push"](c, a, {
                                shallow: l,
                                locale: j,
                                scroll: r
                            }).then((function(e) {
                                e && r && document.body.focus()
                            })))
                        }(e, c, x, o, m, O, N, u)
                    },
                    onMouseEnter: function(e) {
                        (0, i.isLocalURL)(x) && (p.props && "function" === typeof p.props.onMouseEnter && p.props.onMouseEnter(e), d(c, x, o, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === p.type && !("href" in p.props)) {
                    var E = "undefined" !== typeof u ? u : c && c.locale,
                        T = (0, i.getDomainLocale)(o, E, c && c.locales, c && c.domainLocales);
                    _.href = T || (0, i.addBasePath)((0, i.addLocale)(o, E, c && c.defaultLocale))
                }
                return l.default.cloneElement(p, _)
            };
            s.default = b
        },
        vNVm: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                t = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !r,
                    t = (0, l.useRef)(),
                    n = (0, l.useState)(!1),
                    d = a(n, 2),
                    b = d[0],
                    x = d[1],
                    o = (0, l.useCallback)((function(e) {
                        t.current && (t.current(), t.current = void 0), c || b || e && e.tagName && (t.current = function(e, s, c) {
                            var a = function(e) {
                                    var s = e.rootMargin || "",
                                        c = j.get(s);
                                    if (c) return c;
                                    var a = new Map,
                                        t = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = a.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return j.set(s, c = {
                                        id: s,
                                        observer: t,
                                        elements: a
                                    }), c
                                }(c),
                                t = a.id,
                                l = a.observer,
                                i = a.elements;
                            return i.set(e, s), l.observe(e),
                                function() {
                                    i.delete(e), l.unobserve(e), 0 === i.size && (l.disconnect(), j.delete(t))
                                }
                        }(e, (function(e) {
                            return e && x(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, b]);
                return (0, l.useEffect)((function() {
                    r || b || (0, i.default)((function() {
                        return x(!0)
                    }))
                }), [b]), [o, b]
            };
            var l = c("q1tI"),
                i = t(c("0G5g")),
                r = "undefined" !== typeof IntersectionObserver;
            var j = new Map
        }
    },
    [
        ["CeGh", 1, 0, 2]
    ]
]);