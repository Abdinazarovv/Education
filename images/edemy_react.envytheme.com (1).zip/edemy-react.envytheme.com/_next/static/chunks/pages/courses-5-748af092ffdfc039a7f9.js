_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [56], {
        "+HEp": function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/courses-5", function() {
                return c("Tzxy")
            }])
        },
        Ix5F: function(e, s, c) {
            "use strict";
            var l = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    a = e.homePageText,
                    i = e.activePageText;
                return Object(l.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(l.jsx)("div", {
                        className: "container",
                        children: Object(l.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(l.jsxs)("ul", {
                                children: [Object(l.jsx)("li", {
                                    children: Object(l.jsx)(t.a, {
                                        href: c,
                                        children: Object(l.jsx)("a", {
                                            children: a
                                        })
                                    })
                                }), Object(l.jsx)("li", {
                                    className: "active",
                                    children: i
                                })]
                            }), Object(l.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(l.jsx)("div", {
                        className: "shape9",
                        children: Object(l.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        Tzxy: function(e, s, c) {
            "use strict";
            c.r(s);
            var l = c("nKUr"),
                a = c("q1tI"),
                t = c.n(a),
                i = c("Ix5F"),
                n = c("YFqc"),
                r = c.n(n);
            s.default = function() {
                return Object(l.jsxs)(t.a.Fragment, {
                    children: [Object(l.jsx)(i.a, {
                        pageTitle: "Courses List 01",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Courses List 01"
                    }), Object(l.jsx)("div", {
                        className: "courses-area ptb-100 bg-f5f7fa",
                        children: Object(l.jsxs)("div", {
                            className: "container",
                            children: [Object(l.jsxs)("div", {
                                className: "edemy-grid-sorting row align-items-center",
                                children: [Object(l.jsx)("div", {
                                    className: "col-lg-8 col-md-6 result-count",
                                    children: Object(l.jsxs)("p", {
                                        children: ["We found ", Object(l.jsx)("span", {
                                            className: "count",
                                            children: "12"
                                        }), " courses available for you"]
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-4 col-md-6 ordering",
                                    children: Object(l.jsx)("div", {
                                        className: "select-box",
                                        children: Object(l.jsxs)("select", {
                                            className: "form-control",
                                            children: [Object(l.jsx)("option", {
                                                children: "Sort By"
                                            }), Object(l.jsx)("option", {
                                                children: "Popularity"
                                            }), Object(l.jsx)("option", {
                                                children: "Latest"
                                            }), Object(l.jsx)("option", {
                                                children: "Price: low to high"
                                            }), Object(l.jsx)("option", {
                                                children: "Price: high to low"
                                            })]
                                        })
                                    })
                                })]
                            }), Object(l.jsxs)("div", {
                                className: "row",
                                children: [Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small1.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$39"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)(r.a, {
                                                            href: "#",
                                                            children: Object(l.jsx)("a", {
                                                                children: "Agile Crash Course: Agile Project Management"
                                                            })
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 15 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 145 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small2.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$99"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)(r.a, {
                                                            href: "#",
                                                            children: Object(l.jsx)("a", {
                                                                children: "Vue JS 2 - The Complete Guide (incl. Vue Router & Vuex)"
                                                            })
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 14 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 100 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small3.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$49"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)(r.a, {
                                                            href: "#",
                                                            children: Object(l.jsx)("a", {
                                                                children: "The Python Bible\u2122 | Everything You Need to Program in Python"
                                                            })
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 11 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 104 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small4.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$79"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)(r.a, {
                                                            href: "#",
                                                            children: Object(l.jsx)("a", {
                                                                children: "Mathematical Foundation For Machine Learning and AI"
                                                            })
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 14 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 100 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small5.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$59"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "The Ultimate Drawing Course - Beginner to Advanced"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 09 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 150 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small6.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$89"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "PyTorch: Deep Learning and Artificial Intelligence"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 20 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 200 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small7.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$39"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "Data Visualization with Python and Matplotlib"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 15 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 145 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small8.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$99"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "Static and Interactive Data Visualizations in R"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 14 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 100 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small9.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$49"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "R for Data Science: Learn R Programming in 2 Hours"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 11 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 104 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small10.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$79"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "Complete Python Developer in 2020: Zero to Mastery"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 14 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 100 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small1.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$59"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "Python for Beginners with Examples"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 09 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 150 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(l.jsx)("div", {
                                        className: "single-courses-item",
                                        children: Object(l.jsxs)("div", {
                                            className: "row align-items-center",
                                            children: [Object(l.jsx)("div", {
                                                className: "col-lg-4 col-md-4",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(l.jsx)("img", {
                                                        src: "/images/courses-small/courses-small12.jpg",
                                                        alt: "image"
                                                    }), Object(l.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(l.jsx)("a", {
                                                            className: "link-btn"
                                                        })
                                                    })]
                                                })
                                            }), Object(l.jsx)("div", {
                                                className: "col-lg-8 col-md-8",
                                                children: Object(l.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(l.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(l.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(l.jsx)("span", {
                                                        className: "price",
                                                        children: "$89"
                                                    }), Object(l.jsx)("h3", {
                                                        children: Object(l.jsx)("a", {
                                                            href: "#",
                                                            children: "Python Django Web Development: To-Do App"
                                                        })
                                                    }), Object(l.jsxs)("ul", {
                                                        className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 20 Lessons"]
                                                        }), Object(l.jsxs)("li", {
                                                            children: [Object(l.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 200 Students"]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                }), Object(l.jsx)("div", {
                                    className: "col-lg-12 col-md-12",
                                    children: Object(l.jsxs)("div", {
                                        className: "pagination-area text-center",
                                        children: [Object(l.jsx)("a", {
                                            href: "#",
                                            className: "prev page-numbers",
                                            children: Object(l.jsx)("i", {
                                                className: "bx bx-chevrons-left"
                                            })
                                        }), Object(l.jsx)("span", {
                                            className: "page-numbers current",
                                            "aria-current": "page",
                                            children: "1"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "2"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "3"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "4"
                                        }), Object(l.jsx)("a", {
                                            href: "#",
                                            className: "next page-numbers",
                                            children: Object(l.jsx)("i", {
                                                className: "bx bx-chevrons-right"
                                            })
                                        })]
                                    })
                                })]
                            })]
                        })
                    })]
                })
            }
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        cTJO: function(e, s, c) {
            "use strict";
            var l = c("zoAU"),
                a = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var t = a(c("q1tI")),
                i = c("elyg"),
                n = c("nOHt"),
                r = c("vNVm"),
                j = {};

            function o(e, s, c, l) {
                if (e && (0, i.isLocalURL)(s)) {
                    e.prefetch(s, c, l).catch((function(e) {
                        0
                    }));
                    var a = l && "undefined" !== typeof l.locale ? l.locale : e && e.locale;
                    j[s + "%" + c + (a ? "%" + a : "")] = !0
                }
            }
            var d = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, n.useRouter)(),
                    a = c && c.pathname || "/",
                    d = t.default.useMemo((function() {
                        var s = (0, i.resolveHref)(a, e.href, !0),
                            c = l(s, 2),
                            t = c[0],
                            n = c[1];
                        return {
                            href: t,
                            as: e.as ? (0, i.resolveHref)(a, e.as) : n || t
                        }
                    }), [a, e.href, e.as]),
                    m = d.href,
                    b = d.as,
                    h = e.children,
                    x = e.replace,
                    O = e.shallow,
                    u = e.scroll,
                    f = e.locale;
                "string" === typeof h && (h = t.default.createElement("a", null, h));
                var g = t.Children.only(h),
                    N = g && "object" === typeof g && g.ref,
                    v = (0, r.useIntersection)({
                        rootMargin: "200px"
                    }),
                    p = l(v, 2),
                    w = p[0],
                    y = p[1],
                    L = t.default.useCallback((function(e) {
                        w(e), N && ("function" === typeof N ? N(e) : "object" === typeof N && (N.current = e))
                    }), [N, w]);
                (0, t.useEffect)((function() {
                    var e = y && s && (0, i.isLocalURL)(m),
                        l = "undefined" !== typeof f ? f : c && c.locale,
                        a = j[m + "%" + b + (l ? "%" + l : "")];
                    e && !a && o(c, m, b, {
                        locale: l
                    })
                }), [b, m, y, f, s, c]);
                var P = {
                    ref: L,
                    onClick: function(e) {
                        g.props && "function" === typeof g.props.onClick && g.props.onClick(e), e.defaultPrevented || function(e, s, c, l, a, t, n, r) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, i.isLocalURL)(c)) && (e.preventDefault(), null == n && (n = l.indexOf("#") < 0), s[a ? "replace" : "push"](c, l, {
                                shallow: t,
                                locale: r,
                                scroll: n
                            }).then((function(e) {
                                e && n && document.body.focus()
                            })))
                        }(e, c, m, b, x, O, u, f)
                    },
                    onMouseEnter: function(e) {
                        (0, i.isLocalURL)(m) && (g.props && "function" === typeof g.props.onMouseEnter && g.props.onMouseEnter(e), o(c, m, b, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === g.type && !("href" in g.props)) {
                    var E = "undefined" !== typeof f ? f : c && c.locale,
                        k = (0, i.getDomainLocale)(b, E, c && c.locales, c && c.domainLocales);
                    P.href = k || (0, i.addBasePath)((0, i.addLocale)(b, E, c && c.defaultLocale))
                }
                return t.default.cloneElement(g, P)
            };
            s.default = d
        },
        vNVm: function(e, s, c) {
            "use strict";
            var l = c("zoAU"),
                a = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !n,
                    a = (0, t.useRef)(),
                    j = (0, t.useState)(!1),
                    o = l(j, 2),
                    d = o[0],
                    m = o[1],
                    b = (0, t.useCallback)((function(e) {
                        a.current && (a.current(), a.current = void 0), c || d || e && e.tagName && (a.current = function(e, s, c) {
                            var l = function(e) {
                                    var s = e.rootMargin || "",
                                        c = r.get(s);
                                    if (c) return c;
                                    var l = new Map,
                                        a = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = l.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return r.set(s, c = {
                                        id: s,
                                        observer: a,
                                        elements: l
                                    }), c
                                }(c),
                                a = l.id,
                                t = l.observer,
                                i = l.elements;
                            return i.set(e, s), t.observe(e),
                                function() {
                                    i.delete(e), t.unobserve(e), 0 === i.size && (t.disconnect(), r.delete(a))
                                }
                        }(e, (function(e) {
                            return e && m(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, d]);
                return (0, t.useEffect)((function() {
                    n || d || (0, i.default)((function() {
                        return m(!0)
                    }))
                }), [d]), [b, d]
            };
            var t = c("q1tI"),
                i = a(c("0G5g")),
                n = "undefined" !== typeof IntersectionObserver;
            var r = new Map
        }
    },
    [
        ["+HEp", 1, 0, 2]
    ]
]);