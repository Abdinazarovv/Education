_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [45], {
        HRFe: function(e, c, s) {
            "use strict";
            s.r(c);
            var t = s("nKUr"),
                a = s("q1tI"),
                l = s.n(a),
                n = s("Ix5F"),
                i = s("YFqc"),
                r = s.n(i),
                j = s("y1kX");
            c.default = function() {
                return Object(t.jsxs)(l.a.Fragment, {
                    children: [Object(t.jsx)(n.a, {
                        pageTitle: "Blog Right Sidebar",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Blog Right Sidebar"
                    }), Object(t.jsx)("div", {
                        className: "blog-area ptb-100",
                        children: Object(t.jsx)("div", {
                            className: "container",
                            children: Object(t.jsxs)("div", {
                                className: "row",
                                children: [Object(t.jsx)("div", {
                                    className: "col-lg-8 col-md-12",
                                    children: Object(t.jsxs)("div", {
                                        className: "row",
                                        children: [Object(t.jsx)("div", {
                                            className: "col-lg-12 col-md-6",
                                            children: Object(t.jsxs)("div", {
                                                className: "single-blog-post",
                                                children: [Object(t.jsx)("div", {
                                                    className: "post-image",
                                                    children: Object(t.jsx)(r.a, {
                                                        href: "/single-blog-1",
                                                        children: Object(t.jsx)("a", {
                                                            className: "d-block",
                                                            children: Object(t.jsx)("img", {
                                                                src: "/images/blog/blog1.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    })
                                                }), Object(t.jsxs)("div", {
                                                    className: "post-content",
                                                    children: [Object(t.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(t.jsx)("a", {
                                                            className: "category",
                                                            children: "Education"
                                                        })
                                                    }), Object(t.jsx)("h3", {
                                                        children: Object(t.jsx)(r.a, {
                                                            href: "/single-blog-1",
                                                            children: Object(t.jsx)("a", {
                                                                children: "The Beat Goes On: High School Choirs Improvise In The Age Of Coronavirus"
                                                            })
                                                        })
                                                    }), Object(t.jsxs)("ul", {
                                                        className: "post-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("li", {
                                                            children: Object(t.jsxs)("div", {
                                                                className: "post-author d-flex align-items-center",
                                                                children: [Object(t.jsx)("img", {
                                                                    src: "/images/user1.jpg",
                                                                    className: "rounded-circle",
                                                                    alt: "image"
                                                                }), Object(t.jsx)("span", {
                                                                    children: "Alex Morgan"
                                                                })]
                                                            })
                                                        }), Object(t.jsxs)("li", {
                                                            children: [Object(t.jsx)("i", {
                                                                className: "flaticon-calendar"
                                                            }), " April 30, 2020"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "col-lg-12 col-md-6",
                                            children: Object(t.jsxs)("div", {
                                                className: "single-blog-post",
                                                children: [Object(t.jsx)("div", {
                                                    className: "post-image",
                                                    children: Object(t.jsx)(r.a, {
                                                        href: "/single-blog-1",
                                                        children: Object(t.jsx)("a", {
                                                            className: "d-block",
                                                            children: Object(t.jsx)("img", {
                                                                src: "/images/blog/blog2.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    })
                                                }), Object(t.jsxs)("div", {
                                                    className: "post-content",
                                                    children: [Object(t.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(t.jsx)("a", {
                                                            className: "category",
                                                            children: "Online"
                                                        })
                                                    }), Object(t.jsx)("h3", {
                                                        children: Object(t.jsx)(r.a, {
                                                            href: "/single-blog-1",
                                                            children: Object(t.jsx)("a", {
                                                                children: "How Online Book Read-Alouds Can Help Students' Literacy and Connection During Social Distancing"
                                                            })
                                                        })
                                                    }), Object(t.jsxs)("ul", {
                                                        className: "post-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("li", {
                                                            children: Object(t.jsxs)("div", {
                                                                className: "post-author d-flex align-items-center",
                                                                children: [Object(t.jsx)("img", {
                                                                    src: "/images/user2.jpg",
                                                                    className: "rounded-circle",
                                                                    alt: "image"
                                                                }), Object(t.jsx)("span", {
                                                                    children: "Sarah Taylor"
                                                                })]
                                                            })
                                                        }), Object(t.jsxs)("li", {
                                                            children: [Object(t.jsx)("i", {
                                                                className: "flaticon-calendar"
                                                            }), " April 29, 2020"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "col-lg-12 col-md-6",
                                            children: Object(t.jsxs)("div", {
                                                className: "single-blog-post",
                                                children: [Object(t.jsx)("div", {
                                                    className: "post-image",
                                                    children: Object(t.jsx)(r.a, {
                                                        href: "/single-blog-1",
                                                        children: Object(t.jsx)("a", {
                                                            className: "d-block",
                                                            children: Object(t.jsx)("img", {
                                                                src: "/images/blog/blog3.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    })
                                                }), Object(t.jsxs)("div", {
                                                    className: "post-content",
                                                    children: [Object(t.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(t.jsx)("a", {
                                                            className: "category",
                                                            children: "Learning"
                                                        })
                                                    }), Object(t.jsx)("h3", {
                                                        children: Object(t.jsx)(r.a, {
                                                            href: "/single-blog-1",
                                                            children: Object(t.jsx)("a", {
                                                                children: "How To Secure Remote Workers During The COVID-19 Outbreak"
                                                            })
                                                        })
                                                    }), Object(t.jsxs)("ul", {
                                                        className: "post-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("li", {
                                                            children: Object(t.jsxs)("div", {
                                                                className: "post-author d-flex align-items-center",
                                                                children: [Object(t.jsx)("img", {
                                                                    src: "/images/user3.jpg",
                                                                    className: "rounded-circle",
                                                                    alt: "image"
                                                                }), Object(t.jsx)("span", {
                                                                    children: "David Warner"
                                                                })]
                                                            })
                                                        }), Object(t.jsxs)("li", {
                                                            children: [Object(t.jsx)("i", {
                                                                className: "flaticon-calendar"
                                                            }), " April 28, 2020"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "col-lg-12 col-md-6",
                                            children: Object(t.jsxs)("div", {
                                                className: "single-blog-post",
                                                children: [Object(t.jsx)("div", {
                                                    className: "post-image",
                                                    children: Object(t.jsx)(r.a, {
                                                        href: "/single-blog-1",
                                                        children: Object(t.jsx)("a", {
                                                            className: "d-block",
                                                            children: Object(t.jsx)("img", {
                                                                src: "/images/blog/blog7.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    })
                                                }), Object(t.jsxs)("div", {
                                                    className: "post-content",
                                                    children: [Object(t.jsx)(r.a, {
                                                        href: "#",
                                                        children: Object(t.jsx)("a", {
                                                            className: "category",
                                                            children: "Learning"
                                                        })
                                                    }), Object(t.jsx)("h3", {
                                                        children: Object(t.jsx)(r.a, {
                                                            href: "/single-blog-1",
                                                            children: Object(t.jsx)("a", {
                                                                children: "What A Company Needs To Provide Employees For Effective Remote Work"
                                                            })
                                                        })
                                                    }), Object(t.jsxs)("ul", {
                                                        className: "post-content-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("li", {
                                                            children: Object(t.jsxs)("div", {
                                                                className: "post-author d-flex align-items-center",
                                                                children: [Object(t.jsx)("img", {
                                                                    src: "/images/user1.jpg",
                                                                    className: "rounded-circle",
                                                                    alt: "image"
                                                                }), Object(t.jsx)("span", {
                                                                    children: "Alex Morgan"
                                                                })]
                                                            })
                                                        }), Object(t.jsxs)("li", {
                                                            children: [Object(t.jsx)("i", {
                                                                className: "flaticon-calendar"
                                                            }), " April 30, 2020"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "col-lg-12 col-md-12",
                                            children: Object(t.jsxs)("div", {
                                                className: "pagination-area text-center",
                                                children: [Object(t.jsx)("a", {
                                                    href: "#",
                                                    className: "prev page-numbers",
                                                    children: Object(t.jsx)("i", {
                                                        className: "bx bx-chevrons-left"
                                                    })
                                                }), Object(t.jsx)("span", {
                                                    className: "page-numbers current",
                                                    "aria-current": "page",
                                                    children: "1"
                                                }), Object(t.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "2"
                                                }), Object(t.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "3"
                                                }), Object(t.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "4"
                                                }), Object(t.jsx)("a", {
                                                    href: "#",
                                                    className: "next page-numbers",
                                                    children: Object(t.jsx)("i", {
                                                        className: "bx bx-chevrons-right"
                                                    })
                                                })]
                                            })
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-4 col-md-12",
                                    children: Object(t.jsx)(j.a, {})
                                })]
                            })
                        })
                    })]
                })
            }
        },
        Ix5F: function(e, c, s) {
            "use strict";
            var t = s("nKUr"),
                a = (s("q1tI"), s("YFqc")),
                l = s.n(a);
            c.a = function(e) {
                var c = e.pageTitle,
                    s = e.homePageUrl,
                    a = e.homePageText,
                    n = e.activePageText;
                return Object(t.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(t.jsxs)("ul", {
                                children: [Object(t.jsx)("li", {
                                    children: Object(t.jsx)(l.a, {
                                        href: s,
                                        children: Object(t.jsx)("a", {
                                            children: a
                                        })
                                    })
                                }), Object(t.jsx)("li", {
                                    className: "active",
                                    children: n
                                })]
                            }), Object(t.jsx)("h2", {
                                children: c
                            })]
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape9",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        YFqc: function(e, c, s) {
            e.exports = s("cTJO")
        },
        "b/wm": function(e, c, s) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/blog-4", function() {
                return s("HRFe")
            }])
        },
        cTJO: function(e, c, s) {
            "use strict";
            var t = s("zoAU"),
                a = s("7KCV");
            c.__esModule = !0, c.default = void 0;
            var l = a(s("q1tI")),
                n = s("elyg"),
                i = s("nOHt"),
                r = s("vNVm"),
                j = {};

            function d(e, c, s, t) {
                if (e && (0, n.isLocalURL)(c)) {
                    e.prefetch(c, s, t).catch((function(e) {
                        0
                    }));
                    var a = t && "undefined" !== typeof t.locale ? t.locale : e && e.locale;
                    j[c + "%" + s + (a ? "%" + a : "")] = !0
                }
            }
            var o = function(e) {
                var c = !1 !== e.prefetch,
                    s = (0, i.useRouter)(),
                    a = s && s.pathname || "/",
                    o = l.default.useMemo((function() {
                        var c = (0, n.resolveHref)(a, e.href, !0),
                            s = t(c, 2),
                            l = s[0],
                            i = s[1];
                        return {
                            href: l,
                            as: e.as ? (0, n.resolveHref)(a, e.as) : i || l
                        }
                    }), [a, e.href, e.as]),
                    h = o.href,
                    b = o.as,
                    x = e.children,
                    O = e.replace,
                    m = e.shallow,
                    g = e.scroll,
                    u = e.locale;
                "string" === typeof x && (x = l.default.createElement("a", null, x));
                var f = l.Children.only(x),
                    p = f && "object" === typeof f && f.ref,
                    N = (0, r.useIntersection)({
                        rootMargin: "200px"
                    }),
                    v = t(N, 2),
                    w = v[0],
                    y = v[1],
                    k = l.default.useCallback((function(e) {
                        w(e), p && ("function" === typeof p ? p(e) : "object" === typeof p && (p.current = e))
                    }), [p, w]);
                (0, l.useEffect)((function() {
                    var e = y && c && (0, n.isLocalURL)(h),
                        t = "undefined" !== typeof u ? u : s && s.locale,
                        a = j[h + "%" + b + (t ? "%" + t : "")];
                    e && !a && d(s, h, b, {
                        locale: t
                    })
                }), [b, h, y, u, c, s]);
                var _ = {
                    ref: k,
                    onClick: function(e) {
                        f.props && "function" === typeof f.props.onClick && f.props.onClick(e), e.defaultPrevented || function(e, c, s, t, a, l, i, r) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var c = e.currentTarget.target;
                                return c && "_self" !== c || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, n.isLocalURL)(s)) && (e.preventDefault(), null == i && (i = t.indexOf("#") < 0), c[a ? "replace" : "push"](s, t, {
                                shallow: l,
                                locale: r,
                                scroll: i
                            }).then((function(e) {
                                e && i && document.body.focus()
                            })))
                        }(e, s, h, b, O, m, g, u)
                    },
                    onMouseEnter: function(e) {
                        (0, n.isLocalURL)(h) && (f.props && "function" === typeof f.props.onMouseEnter && f.props.onMouseEnter(e), d(s, h, b, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === f.type && !("href" in f.props)) {
                    var T = "undefined" !== typeof u ? u : s && s.locale,
                        E = (0, n.getDomainLocale)(b, T, s && s.locales, s && s.domainLocales);
                    _.href = E || (0, n.addBasePath)((0, n.addLocale)(b, T, s && s.defaultLocale))
                }
                return l.default.cloneElement(f, _)
            };
            c.default = o
        },
        vNVm: function(e, c, s) {
            "use strict";
            var t = s("zoAU"),
                a = s("AroE");
            c.__esModule = !0, c.useIntersection = function(e) {
                var c = e.rootMargin,
                    s = e.disabled || !i,
                    a = (0, l.useRef)(),
                    j = (0, l.useState)(!1),
                    d = t(j, 2),
                    o = d[0],
                    h = d[1],
                    b = (0, l.useCallback)((function(e) {
                        a.current && (a.current(), a.current = void 0), s || o || e && e.tagName && (a.current = function(e, c, s) {
                            var t = function(e) {
                                    var c = e.rootMargin || "",
                                        s = r.get(c);
                                    if (s) return s;
                                    var t = new Map,
                                        a = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var c = t.get(e.target),
                                                    s = e.isIntersecting || e.intersectionRatio > 0;
                                                c && s && c(s)
                                            }))
                                        }), e);
                                    return r.set(c, s = {
                                        id: c,
                                        observer: a,
                                        elements: t
                                    }), s
                                }(s),
                                a = t.id,
                                l = t.observer,
                                n = t.elements;
                            return n.set(e, c), l.observe(e),
                                function() {
                                    n.delete(e), l.unobserve(e), 0 === n.size && (l.disconnect(), r.delete(a))
                                }
                        }(e, (function(e) {
                            return e && h(e)
                        }), {
                            rootMargin: c
                        }))
                    }), [s, c, o]);
                return (0, l.useEffect)((function() {
                    i || o || (0, n.default)((function() {
                        return h(!0)
                    }))
                }), [o]), [b, o]
            };
            var l = s("q1tI"),
                n = a(s("0G5g")),
                i = "undefined" !== typeof IntersectionObserver;
            var r = new Map
        },
        y1kX: function(e, c, s) {
            "use strict";
            var t = s("nKUr"),
                a = (s("q1tI"), s("YFqc")),
                l = s.n(a);
            c.a = function() {
                return Object(t.jsxs)("div", {
                    className: "widget-area",
                    children: [Object(t.jsxs)("div", {
                        className: "widget widget_search",
                        children: [Object(t.jsx)("h3", {
                            className: "widget-title",
                            children: "Search"
                        }), Object(t.jsxs)("form", {
                            className: "search-form",
                            children: [Object(t.jsx)("label", {
                                children: Object(t.jsx)("input", {
                                    type: "search",
                                    className: "search-field",
                                    placeholder: "Search..."
                                })
                            }), Object(t.jsx)("button", {
                                type: "submit",
                                children: Object(t.jsx)("i", {
                                    className: "bx bx-search-alt"
                                })
                            })]
                        })]
                    }), Object(t.jsxs)("div", {
                        className: "widget widget_edemy_posts_thumb",
                        children: [Object(t.jsx)("h3", {
                            className: "widget-title",
                            children: "Popular Posts"
                        }), Object(t.jsxs)("div", {
                            className: "item",
                            children: [Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsx)("a", {
                                    className: "thumb",
                                    children: Object(t.jsx)("span", {
                                        className: "fullimage cover bg1",
                                        role: "img"
                                    })
                                })
                            }), Object(t.jsxs)("div", {
                                className: "info",
                                children: [Object(t.jsx)("span", {
                                    children: "June 10, 2020"
                                }), Object(t.jsx)("h4", {
                                    className: "title usmall",
                                    children: Object(t.jsx)(l.a, {
                                        href: "#",
                                        children: Object(t.jsx)("a", {
                                            children: "Ultimate Bali Guide + Where to stay in Bali 2020"
                                        })
                                    })
                                })]
                            }), Object(t.jsx)("div", {
                                className: "clear"
                            })]
                        }), Object(t.jsxs)("div", {
                            className: "item",
                            children: [Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsx)("a", {
                                    className: "thumb",
                                    children: Object(t.jsx)("span", {
                                        className: "fullimage cover bg2",
                                        role: "img"
                                    })
                                })
                            }), Object(t.jsxs)("div", {
                                className: "info",
                                children: [Object(t.jsx)("span", {
                                    children: "June 21, 2020"
                                }), Object(t.jsx)("h4", {
                                    className: "title usmall",
                                    children: Object(t.jsx)(l.a, {
                                        href: "#",
                                        children: Object(t.jsx)("a", {
                                            children: "Live the Island life: 20 unique Islands to visit in 2020"
                                        })
                                    })
                                })]
                            }), Object(t.jsx)("div", {
                                className: "clear"
                            })]
                        }), Object(t.jsxs)("div", {
                            className: "item",
                            children: [Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsx)("a", {
                                    className: "thumb",
                                    children: Object(t.jsx)("span", {
                                        className: "fullimage cover bg3",
                                        role: "img"
                                    })
                                })
                            }), Object(t.jsxs)("div", {
                                className: "info",
                                children: [Object(t.jsx)("span", {
                                    children: "June 30, 2020"
                                }), Object(t.jsx)("h4", {
                                    className: "title usmall",
                                    children: Object(t.jsx)(l.a, {
                                        href: "#",
                                        children: Object(t.jsx)("a", {
                                            children: "Best Places to Visit in Europe this Autumn & Winter"
                                        })
                                    })
                                })]
                            }), Object(t.jsx)("div", {
                                className: "clear"
                            })]
                        })]
                    }), Object(t.jsxs)("div", {
                        className: "widget widget_categories",
                        children: [Object(t.jsx)("h3", {
                            className: "widget-title",
                            children: "Categories"
                        }), Object(t.jsxs)("ul", {
                            children: [Object(t.jsx)("li", {
                                children: Object(t.jsx)(l.a, {
                                    href: "#",
                                    children: Object(t.jsxs)("a", {
                                        children: ["Design ", Object(t.jsx)("span", {
                                            className: "post-count",
                                            children: "(03)"
                                        })]
                                    })
                                })
                            }), Object(t.jsx)("li", {
                                children: Object(t.jsx)(l.a, {
                                    href: "#",
                                    children: Object(t.jsxs)("a", {
                                        children: ["Lifestyle ", Object(t.jsx)("span", {
                                            className: "post-count",
                                            children: "(05)"
                                        })]
                                    })
                                })
                            }), Object(t.jsx)("li", {
                                children: Object(t.jsx)(l.a, {
                                    href: "#",
                                    children: Object(t.jsxs)("a", {
                                        children: ["Script ", Object(t.jsx)("span", {
                                            className: "post-count",
                                            children: "(10)"
                                        })]
                                    })
                                })
                            }), Object(t.jsx)("li", {
                                children: Object(t.jsx)(l.a, {
                                    href: "#",
                                    children: Object(t.jsxs)("a", {
                                        children: ["Device ", Object(t.jsx)("span", {
                                            className: "post-count",
                                            children: "(08)"
                                        })]
                                    })
                                })
                            }), Object(t.jsx)("li", {
                                children: Object(t.jsx)(l.a, {
                                    href: "#",
                                    children: Object(t.jsxs)("a", {
                                        children: ["Tips ", Object(t.jsx)("span", {
                                            className: "post-count",
                                            children: "(01)"
                                        })]
                                    })
                                })
                            })]
                        })]
                    }), Object(t.jsxs)("div", {
                        className: "widget widget_tag_cloud",
                        children: [Object(t.jsx)("h3", {
                            className: "widget-title",
                            children: "Popular Tags"
                        }), Object(t.jsxs)("div", {
                            className: "tagcloud",
                            children: [Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Business ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (3)"
                                    })]
                                })
                            }), Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Design ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (3)"
                                    })]
                                })
                            }), Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Braike ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (2)"
                                    })]
                                })
                            }), Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Fashion ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (2)"
                                    })]
                                })
                            }), Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Travel ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (1)"
                                    })]
                                })
                            }), Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Smart ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (1)"
                                    })]
                                })
                            }), Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Marketing ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (1)"
                                    })]
                                })
                            }), Object(t.jsx)(l.a, {
                                href: "#",
                                children: Object(t.jsxs)("a", {
                                    children: ["Tips ", Object(t.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (2)"
                                    })]
                                })
                            })]
                        })]
                    })]
                })
            }
        }
    },
    [
        ["b/wm", 1, 0, 2]
    ]
]);