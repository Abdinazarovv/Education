_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [42], {
        Ix5F: function(e, c, s) {
            "use strict";
            var t = s("nKUr"),
                a = (s("q1tI"), s("YFqc")),
                l = s.n(a);
            c.a = function(e) {
                var c = e.pageTitle,
                    s = e.homePageUrl,
                    a = e.homePageText,
                    n = e.activePageText;
                return Object(t.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(t.jsxs)("ul", {
                                children: [Object(t.jsx)("li", {
                                    children: Object(t.jsx)(l.a, {
                                        href: s,
                                        children: Object(t.jsx)("a", {
                                            children: a
                                        })
                                    })
                                }), Object(t.jsx)("li", {
                                    className: "active",
                                    children: n
                                })]
                            }), Object(t.jsx)("h2", {
                                children: c
                            })]
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape9",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        K7ov: function(e, c, s) {
            "use strict";
            s.r(c);
            var t = s("nKUr"),
                a = s("q1tI"),
                l = s.n(a),
                n = s("Ix5F"),
                i = s("YFqc"),
                r = s.n(i);
            c.default = function() {
                return Object(t.jsxs)(l.a.Fragment, {
                    children: [Object(t.jsx)(n.a, {
                        pageTitle: "Blog Grid (2 in Row)",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Blog Grid (2 in Row)"
                    }), Object(t.jsx)("div", {
                        className: "blog-area ptb-100",
                        children: Object(t.jsx)("div", {
                            className: "container",
                            children: Object(t.jsxs)("div", {
                                className: "row",
                                children: [Object(t.jsx)("div", {
                                    className: "col-lg-6 col-md-6",
                                    children: Object(t.jsxs)("div", {
                                        className: "single-blog-post",
                                        children: [Object(t.jsx)("div", {
                                            className: "post-image",
                                            children: Object(t.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(t.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(t.jsx)("img", {
                                                        src: "/images/blog/blog1.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(t.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(t.jsx)(r.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    className: "category",
                                                    children: "Education"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: Object(t.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(t.jsx)("a", {
                                                        children: "It\u2019s Time To Think Differently About Homeschooling"
                                                    })
                                                })
                                            }), Object(t.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(t.jsx)("img", {
                                                            src: "/images/user1.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(t.jsx)("span", {
                                                            children: "Alex Morgan"
                                                        })]
                                                    })
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 30, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-6 col-md-6",
                                    children: Object(t.jsxs)("div", {
                                        className: "single-blog-post",
                                        children: [Object(t.jsx)("div", {
                                            className: "post-image",
                                            children: Object(t.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(t.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(t.jsx)("img", {
                                                        src: "/images/blog/blog2.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(t.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(t.jsx)(r.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    className: "category",
                                                    children: "Online"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: Object(t.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(t.jsx)("a", {
                                                        children: "Online Learning Can Prepare Students For A Fast-Changing"
                                                    })
                                                })
                                            }), Object(t.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(t.jsx)("img", {
                                                            src: "/images/user2.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(t.jsx)("span", {
                                                            children: "Sarah Taylor"
                                                        })]
                                                    })
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 29, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-6 col-md-6",
                                    children: Object(t.jsxs)("div", {
                                        className: "single-blog-post",
                                        children: [Object(t.jsx)("div", {
                                            className: "post-image",
                                            children: Object(t.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(t.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(t.jsx)("img", {
                                                        src: "/images/blog/blog3.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(t.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(t.jsx)(r.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    className: "category",
                                                    children: "Learning"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: Object(t.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(t.jsx)("a", {
                                                        children: "28 Student-Centered Instructional Strategies"
                                                    })
                                                })
                                            }), Object(t.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(t.jsx)("img", {
                                                            src: "/images/user3.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(t.jsx)("span", {
                                                            children: "David Warner"
                                                        })]
                                                    })
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-6 col-md-6",
                                    children: Object(t.jsxs)("div", {
                                        className: "single-blog-post",
                                        children: [Object(t.jsx)("div", {
                                            className: "post-image",
                                            children: Object(t.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(t.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(t.jsx)("img", {
                                                        src: "/images/blog/blog7.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(t.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(t.jsx)(r.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    className: "category",
                                                    children: "Learning"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: Object(t.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(t.jsx)("a", {
                                                        children: "4 Steps To Quality Training In Times Of Urgency"
                                                    })
                                                })
                                            }), Object(t.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(t.jsx)("img", {
                                                            src: "/images/user1.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(t.jsx)("span", {
                                                            children: "Alex Morgan"
                                                        })]
                                                    })
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 30, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-6 col-md-6",
                                    children: Object(t.jsxs)("div", {
                                        className: "single-blog-post",
                                        children: [Object(t.jsx)("div", {
                                            className: "post-image",
                                            children: Object(t.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(t.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(t.jsx)("img", {
                                                        src: "/images/blog/blog8.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(t.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(t.jsx)(r.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    className: "category",
                                                    children: "Online"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: Object(t.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(t.jsx)("a", {
                                                        children: "100 Blended Learning Resources For Teachers"
                                                    })
                                                })
                                            }), Object(t.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(t.jsx)("img", {
                                                            src: "/images/user2.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(t.jsx)("span", {
                                                            children: "Sarah Taylor"
                                                        })]
                                                    })
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 29, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-6 col-md-6",
                                    children: Object(t.jsxs)("div", {
                                        className: "single-blog-post",
                                        children: [Object(t.jsx)("div", {
                                            className: "post-image",
                                            children: Object(t.jsx)(r.a, {
                                                href: "/single-blog-1",
                                                children: Object(t.jsx)("a", {
                                                    className: "d-block",
                                                    children: Object(t.jsx)("img", {
                                                        src: "/images/blog/blog9.jpg",
                                                        alt: "image"
                                                    })
                                                })
                                            })
                                        }), Object(t.jsxs)("div", {
                                            className: "post-content",
                                            children: [Object(t.jsx)(r.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    className: "category",
                                                    children: "Learning"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: Object(t.jsx)(r.a, {
                                                    href: "/single-blog-1",
                                                    children: Object(t.jsx)("a", {
                                                        children: "20 Examples Of Project-Based Learning"
                                                    })
                                                })
                                            }), Object(t.jsxs)("ul", {
                                                className: "post-content-footer d-flex justify-content-between align-items-center",
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("div", {
                                                        className: "post-author d-flex align-items-center",
                                                        children: [Object(t.jsx)("img", {
                                                            src: "/images/user3.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(t.jsx)("span", {
                                                            children: "David Warner"
                                                        })]
                                                    })
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "flaticon-calendar"
                                                    }), " April 28, 2020"]
                                                })]
                                            })]
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-12 col-md-12",
                                    children: Object(t.jsxs)("div", {
                                        className: "pagination-area text-center",
                                        children: [Object(t.jsx)("a", {
                                            href: "#",
                                            className: "prev page-numbers",
                                            children: Object(t.jsx)("i", {
                                                className: "bx bx-chevrons-left"
                                            })
                                        }), Object(t.jsx)("span", {
                                            className: "page-numbers current",
                                            "aria-current": "page",
                                            children: "1"
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "2"
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "3"
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "page-numbers",
                                            children: "4"
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "next page-numbers",
                                            children: Object(t.jsx)("i", {
                                                className: "bx bx-chevrons-right"
                                            })
                                        })]
                                    })
                                })]
                            })
                        })
                    })]
                })
            }
        },
        PEjp: function(e, c, s) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/blog-1", function() {
                return s("K7ov")
            }])
        },
        YFqc: function(e, c, s) {
            e.exports = s("cTJO")
        },
        cTJO: function(e, c, s) {
            "use strict";
            var t = s("zoAU"),
                a = s("7KCV");
            c.__esModule = !0, c.default = void 0;
            var l = a(s("q1tI")),
                n = s("elyg"),
                i = s("nOHt"),
                r = s("vNVm"),
                j = {};

            function o(e, c, s, t) {
                if (e && (0, n.isLocalURL)(c)) {
                    e.prefetch(c, s, t).catch((function(e) {
                        0
                    }));
                    var a = t && "undefined" !== typeof t.locale ? t.locale : e && e.locale;
                    j[c + "%" + s + (a ? "%" + a : "")] = !0
                }
            }
            var d = function(e) {
                var c = !1 !== e.prefetch,
                    s = (0, i.useRouter)(),
                    a = s && s.pathname || "/",
                    d = l.default.useMemo((function() {
                        var c = (0, n.resolveHref)(a, e.href, !0),
                            s = t(c, 2),
                            l = s[0],
                            i = s[1];
                        return {
                            href: l,
                            as: e.as ? (0, n.resolveHref)(a, e.as) : i || l
                        }
                    }), [a, e.href, e.as]),
                    b = d.href,
                    h = d.as,
                    g = e.children,
                    m = e.replace,
                    x = e.shallow,
                    O = e.scroll,
                    f = e.locale;
                "string" === typeof g && (g = l.default.createElement("a", null, g));
                var u = l.Children.only(g),
                    p = u && "object" === typeof u && u.ref,
                    v = (0, r.useIntersection)({
                        rootMargin: "200px"
                    }),
                    N = t(v, 2),
                    y = N[0],
                    w = N[1],
                    T = l.default.useCallback((function(e) {
                        y(e), p && ("function" === typeof p ? p(e) : "object" === typeof p && (p.current = e))
                    }), [p, y]);
                (0, l.useEffect)((function() {
                    var e = w && c && (0, n.isLocalURL)(b),
                        t = "undefined" !== typeof f ? f : s && s.locale,
                        a = j[b + "%" + h + (t ? "%" + t : "")];
                    e && !a && o(s, b, h, {
                        locale: t
                    })
                }), [h, b, w, f, c, s]);
                var E = {
                    ref: T,
                    onClick: function(e) {
                        u.props && "function" === typeof u.props.onClick && u.props.onClick(e), e.defaultPrevented || function(e, c, s, t, a, l, i, r) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var c = e.currentTarget.target;
                                return c && "_self" !== c || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, n.isLocalURL)(s)) && (e.preventDefault(), null == i && (i = t.indexOf("#") < 0), c[a ? "replace" : "push"](s, t, {
                                shallow: l,
                                locale: r,
                                scroll: i
                            }).then((function(e) {
                                e && i && document.body.focus()
                            })))
                        }(e, s, b, h, m, x, O, f)
                    },
                    onMouseEnter: function(e) {
                        (0, n.isLocalURL)(b) && (u.props && "function" === typeof u.props.onMouseEnter && u.props.onMouseEnter(e), o(s, b, h, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === u.type && !("href" in u.props)) {
                    var L = "undefined" !== typeof f ? f : s && s.locale,
                        _ = (0, n.getDomainLocale)(h, L, s && s.locales, s && s.domainLocales);
                    E.href = _ || (0, n.addBasePath)((0, n.addLocale)(h, L, s && s.defaultLocale))
                }
                return l.default.cloneElement(u, E)
            };
            c.default = d
        },
        vNVm: function(e, c, s) {
            "use strict";
            var t = s("zoAU"),
                a = s("AroE");
            c.__esModule = !0, c.useIntersection = function(e) {
                var c = e.rootMargin,
                    s = e.disabled || !i,
                    a = (0, l.useRef)(),
                    j = (0, l.useState)(!1),
                    o = t(j, 2),
                    d = o[0],
                    b = o[1],
                    h = (0, l.useCallback)((function(e) {
                        a.current && (a.current(), a.current = void 0), s || d || e && e.tagName && (a.current = function(e, c, s) {
                            var t = function(e) {
                                    var c = e.rootMargin || "",
                                        s = r.get(c);
                                    if (s) return s;
                                    var t = new Map,
                                        a = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var c = t.get(e.target),
                                                    s = e.isIntersecting || e.intersectionRatio > 0;
                                                c && s && c(s)
                                            }))
                                        }), e);
                                    return r.set(c, s = {
                                        id: c,
                                        observer: a,
                                        elements: t
                                    }), s
                                }(s),
                                a = t.id,
                                l = t.observer,
                                n = t.elements;
                            return n.set(e, c), l.observe(e),
                                function() {
                                    n.delete(e), l.unobserve(e), 0 === n.size && (l.disconnect(), r.delete(a))
                                }
                        }(e, (function(e) {
                            return e && b(e)
                        }), {
                            rootMargin: c
                        }))
                    }), [s, c, d]);
                return (0, l.useEffect)((function() {
                    i || d || (0, n.default)((function() {
                        return b(!0)
                    }))
                }), [d]), [h, d]
            };
            var l = s("q1tI"),
                n = a(s("0G5g")),
                i = "undefined" !== typeof IntersectionObserver;
            var r = new Map
        }
    },
    [
        ["PEjp", 1, 0, 2]
    ]
]);