_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [41], {
        "+tXn": function(e, s, c) {
            "use strict";
            var t = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "funfacts-area-two",
                    children: Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "row",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts",
                                    children: [Object(t.jsx)("img", {
                                        src: "/images/funfacts-shape2.png",
                                        alt: "image"
                                    }), Object(t.jsx)("h3", {
                                        children: "1,926"
                                    }), Object(t.jsx)("p", {
                                        children: "Finished Sessions"
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts",
                                    children: [Object(t.jsx)("img", {
                                        src: "/images/funfacts-shape2.png",
                                        alt: "image"
                                    }), Object(t.jsx)("h3", {
                                        children: "3,279"
                                    }), Object(t.jsx)("p", {
                                        children: "Enrolled Learners"
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts",
                                    children: [Object(t.jsx)("img", {
                                        src: "/images/funfacts-shape2.png",
                                        alt: "image"
                                    }), Object(t.jsx)("h3", {
                                        children: "250"
                                    }), Object(t.jsx)("p", {
                                        children: "Online Instructors"
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts",
                                    children: [Object(t.jsx)("img", {
                                        src: "/images/funfacts-shape2.png",
                                        alt: "image"
                                    }), Object(t.jsx)("h3", {
                                        children: "100%"
                                    }), Object(t.jsx)("p", {
                                        children: "Satisfaction Rate"
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        "7pJ3": function(e, s, c) {
            "use strict";
            var t = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                i = c.n(a);
            s.a = function() {
                return Object(t.jsxs)("div", {
                    className: "premium-access-area",
                    children: [Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "premium-access-content",
                            children: [Object(t.jsx)("span", {
                                className: "sub-title",
                                children: "Go at your own pace"
                            }), Object(t.jsx)("h2", {
                                children: "Give their limitless potential unlimited access"
                            }), Object(t.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(t.jsx)(i.a, {
                                href: "/membership-levels",
                                children: Object(t.jsxs)("a", {
                                    className: "default-btn",
                                    children: [Object(t.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Give Premium Access ", Object(t.jsx)("span", {})]
                                })
                            })]
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape3",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape4",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape8",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape7.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        bTjV: function(e, s, c) {
            "use strict";
            var t = c("ELrk"),
                a = c("sDqW"),
                i = c("q1tI"),
                r = c.n(i),
                n = c("17x9"),
                l = c.n(n),
                o = c("TSYQ"),
                d = c.n(o),
                u = c("33Jr"),
                m = {
                    tag: u.f,
                    type: l.a.string,
                    size: l.a.string,
                    color: l.a.string,
                    className: l.a.string,
                    cssModule: l.a.object,
                    children: l.a.string
                },
                j = function(e) {
                    var s = e.className,
                        c = e.cssModule,
                        i = e.type,
                        n = e.size,
                        l = e.color,
                        o = e.children,
                        m = e.tag,
                        j = Object(a.a)(e, ["className", "cssModule", "type", "size", "color", "children", "tag"]),
                        p = Object(u.c)(d()(s, !!n && "spinner-" + i + "-" + n, "spinner-" + i, !!l && "text-" + l), c);
                    return r.a.createElement(m, Object(t.a)({
                        role: "status"
                    }, j, {
                        className: p
                    }), o && r.a.createElement("span", {
                        className: Object(u.c)("sr-only", c)
                    }, o))
                };
            j.propTypes = m, j.defaultProps = {
                tag: "div",
                type: "border",
                children: "Loading..."
            }, s.a = j
        },
        c61n: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/become-a-teacher", function() {
                return c("dKP/")
            }])
        },
        "dKP/": function(e, s, c) {
            "use strict";
            c.r(s);
            var t = c("nKUr"),
                a = c("q1tI"),
                i = c.n(a),
                r = c("Ix5F"),
                n = c("7pJ3"),
                l = c("+tXn"),
                o = c("GTV5");
            Object(o.e)();
            var d = function() {
                    return Object(t.jsx)("div", {
                        className: "apply-instructor-area ptb-100",
                        children: Object(t.jsx)("div", {
                            className: "container",
                            children: Object(t.jsxs)("div", {
                                className: "row",
                                children: [Object(t.jsx)("div", {
                                    className: "col-lg-5 col-md-12",
                                    children: Object(t.jsxs)("div", {
                                        className: "apply-instructor-image",
                                        children: [Object(t.jsx)("h2", {
                                            children: "Apply As Instructor"
                                        }), Object(t.jsx)("img", {
                                            src: "/images/apply-instructor.jpg",
                                            alt: "image"
                                        })]
                                    })
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-7 col-md-12",
                                    children: Object(t.jsx)("div", {
                                        className: "apply-instructor-content",
                                        children: Object(t.jsxs)(o.d, {
                                            children: [Object(t.jsxs)(o.b, {
                                                children: [Object(t.jsx)(o.a, {
                                                    children: "Become an Instructor"
                                                }), Object(t.jsx)(o.a, {
                                                    children: "Instructor Rules"
                                                }), Object(t.jsx)(o.a, {
                                                    children: "Start with Courses"
                                                })]
                                            }), Object(t.jsxs)(o.c, {
                                                children: [Object(t.jsx)("h3", {
                                                    children: "Course Description"
                                                }), Object(t.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                                }), Object(t.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                                                }), Object(t.jsx)("h3", {
                                                    children: "Certification"
                                                }), Object(t.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                                })]
                                            }), Object(t.jsxs)(o.c, {
                                                children: [Object(t.jsx)("h3", {
                                                    children: "Course Description"
                                                }), Object(t.jsx)("p", {
                                                    children: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo."
                                                }), Object(t.jsx)("p", {
                                                    children: "But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness."
                                                }), Object(t.jsx)("h3", {
                                                    children: "Certification"
                                                }), Object(t.jsx)("p", {
                                                    children: "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non providrum facilis est et expedita."
                                                })]
                                            }), Object(t.jsxs)(o.c, {
                                                children: [Object(t.jsx)("h3", {
                                                    children: "Course Description"
                                                }), Object(t.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                                }), Object(t.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                                                }), Object(t.jsx)("h3", {
                                                    children: "Certification"
                                                }), Object(t.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                                })]
                                            })]
                                        })
                                    })
                                })]
                            })
                        })
                    })
                },
                u = c("o0o1"),
                m = c.n(u),
                j = c("HaE+"),
                p = c("rePB"),
                b = c("ODXe"),
                h = c("NKCw"),
                O = c("NyWP"),
                x = c("aLZG"),
                g = c("bTjV"),
                v = c("vDqi"),
                f = c.n(v),
                N = c("tbn6"),
                y = c("xUX2"),
                _ = c("rjN7");

            function w(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    s && (t = t.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, t)
                }
                return c
            }

            function q(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? w(Object(c), !0).forEach((function(s) {
                        Object(p.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : w(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var P = function(e) {
                var s, c = e.user,
                    a = Object(O.parseCookies)().token,
                    r = Object(N.useToasts)().addToast,
                    n = {
                        name: c.name,
                        email: c.email,
                        number: c.phone,
                        subject: "Becaome A Teacher!",
                        as_teacher_apply: !0,
                        as_teacher_req_desc: ""
                    },
                    l = i.a.useState(n),
                    o = Object(b.a)(l, 2),
                    d = o[0],
                    u = o[1],
                    v = i.a.useState(!1),
                    w = Object(b.a)(v, 2),
                    P = w[0],
                    S = w[1],
                    T = i.a.useState(!1),
                    C = Object(b.a)(T, 2),
                    E = C[0],
                    L = C[1],
                    k = i.a.useState(!0),
                    I = Object(b.a)(k, 2),
                    D = I[0],
                    R = I[1],
                    Y = i.a.useState(""),
                    A = Object(b.a)(Y, 2),
                    B = (A[0], A[1]),
                    Q = Object(h.a)(),
                    K = Q.register,
                    X = Q.handleSubmit,
                    F = Q.errors;
                i.a.useEffect((function() {
                    var e = Object.values(d).every((function(e) {
                        return Boolean(e)
                    }));
                    R(!e)
                }), [d]);
                var G = function(e) {
                        var s = e.target,
                            c = s.name,
                            t = s.value;
                        u((function(e) {
                            return q(q({}, e), {}, Object(p.a)({}, c, t))
                        }))
                    },
                    J = function() {
                        var e = Object(j.a)(m.a.mark((function e() {
                            var s, c, t;
                            return m.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, L(!0), B(""), s = "".concat(_.a, "/api/v1/user/apply"), c = q({}, d), e.next = 7, f.a.post(s, c, {
                                            headers: {
                                                Authorization: a
                                            }
                                        });
                                    case 7:
                                        t = e.sent, r(t.data, {
                                            appearance: "success"
                                        }), u(n), S(!0), e.next = 16;
                                        break;
                                    case 13:
                                        e.prev = 13, e.t0 = e.catch(0), Object(y.a)(e.t0, B);
                                    case 16:
                                        return e.prev = 16, L(!1), e.finish(16);
                                    case 19:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [0, 13, 16, 19]
                            ])
                        })));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }(),
                    U = c && !0 === c.as_teacher_apply && null === c.as_teacher_confirmed,
                    z = c && !0 === c.as_teacher_apply && !0 === c.as_teacher_confirmed,
                    M = c && !0 === c.as_teacher_apply && !1 === c.as_teacher_confirmed;
                return Object(t.jsx)("div", {
                    className: "teacher-register-area ptb-100",
                    children: Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "teacher-register-box",
                            children: [Object(t.jsx)("h2", {
                                children: "Register to Become an Intructor"
                            }), Object(t.jsx)("p", {
                                children: "Your email address will not be published. Required fields are marked *"
                            }), U && Object(t.jsx)(x.a, {
                                color: "info mt-15",
                                children: "Your application is pending now, you will get notice soon."
                            }), z && Object(t.jsx)(x.a, {
                                color: "success mt-15",
                                children: "You already a teacher & create much exciting content."
                            }), M && Object(t.jsx)(x.a, {
                                color: "success mt-15",
                                children: "You already applied & you got cancellation."
                            }), Object(t.jsx)("form", {
                                id: "contactForm",
                                onSubmit: X(J),
                                children: Object(t.jsxs)("div", {
                                    className: "row",
                                    children: [Object(t.jsx)("div", {
                                        className: "col-lg-6 col-md-6",
                                        children: Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "text",
                                                name: "name",
                                                placeholder: "Your Name",
                                                value: d.name,
                                                onChange: G
                                            })
                                        })
                                    }), Object(t.jsx)("div", {
                                        className: "col-lg-6 col-md-6",
                                        children: Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "text",
                                                name: "email",
                                                placeholder: "Your email address",
                                                value: d.email,
                                                onChange: G
                                            })
                                        })
                                    }), Object(t.jsx)("div", {
                                        className: "col-lg-12 col-md-6",
                                        children: Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "text",
                                                name: "number",
                                                placeholder: "Your phone number",
                                                value: d.number,
                                                onChange: G
                                            })
                                        })
                                    }), Object(t.jsx)("div", {
                                        className: "col-lg-12 col-md-12",
                                        children: Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "text",
                                                name: "subject",
                                                placeholder: "Your Subject",
                                                value: d.subject,
                                                onChange: G
                                            })
                                        })
                                    }), Object(t.jsx)("div", {
                                        className: "col-lg-12 col-md-12",
                                        children: Object(t.jsxs)("div", {
                                            className: "form-group",
                                            children: [Object(t.jsx)("textarea", (s = {
                                                name: "text",
                                                cols: "30",
                                                rows: "5",
                                                placeholder: "Please tell us about your teaching profession",
                                                className: "form-control"
                                            }, Object(p.a)(s, "name", "as_teacher_req_desc"), Object(p.a)(s, "value", d.as_teacher_req_desc), Object(p.a)(s, "onChange", G), Object(p.a)(s, "ref", K({
                                                required: !0
                                            })), s)), Object(t.jsx)("div", {
                                                className: "invalid-feedback",
                                                style: {
                                                    display: "block"
                                                },
                                                children: F.text && "Details is required."
                                            })]
                                        })
                                    }), Object(t.jsx)("div", {
                                        className: "col-lg-12 col-sm-12",
                                        children: !(P || U || z || M) && Object(t.jsx)("div", {
                                            className: "text-right",
                                            children: Object(t.jsxs)("button", {
                                                disabled: D || E,
                                                type: "submit",
                                                className: "default-btn",
                                                children: ["Apply Now", E ? Object(t.jsx)(g.a, {
                                                    color: "success"
                                                }) : ""]
                                            })
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                })
            };
            s.default = function(e) {
                var s = e.user;
                return Object(t.jsxs)(i.a.Fragment, {
                    children: [Object(t.jsx)(r.a, {
                        pageTitle: "Become A Teacher",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Become A Teacher"
                    }), Object(t.jsx)("div", {
                        className: "ptb-100",
                        children: Object(t.jsx)(n.a, {})
                    }), Object(t.jsx)(l.a, {}), Object(t.jsx)(d, {}), Object(t.jsx)(P, {
                        user: s
                    })]
                })
            }
        }
    },
    [
        ["c61n", 1, 0, 2, 5, 7, 6, 10, 13, 11, 18]
    ]
]);