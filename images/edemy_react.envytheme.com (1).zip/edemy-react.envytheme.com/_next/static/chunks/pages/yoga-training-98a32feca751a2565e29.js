_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [106], {
        "c3/c": function(c, j, t) {
            "use strict";
            t.r(j);
            var e = t("nKUr"),
                a = t("q1tI"),
                n = t.n(a),
                s = t("PEey"),
                b = t("drEa"),
                x = t("xghe"),
                O = t("Eec0"),
                i = t("WYza"),
                r = t("3XVu"),
                _ = t("SIq9"),
                o = t("j8NB"),
                u = t("AAaN"),
                d = t("AFc6"),
                w = t("VU5F"),
                E = t("Md9E");
            j.default = function() {
                return Object(e.jsxs)(n.a.Fragment, {
                    children: [Object(e.jsx)(s.a, {}), Object(e.jsx)(b.a, {}), Object(e.jsx)(x.a, {}), Object(e.jsx)(O.a, {}), Object(e.jsx)(i.a, {}), Object(e.jsx)(r.a, {}), Object(e.jsx)(_.a, {}), Object(e.jsx)(o.a, {}), Object(e.jsx)(u.a, {}), Object(e.jsx)(d.a, {}), Object(e.jsx)(w.a, {}), Object(e.jsx)(E.a, {})]
                })
            }
        },
        sWdV: function(c, j, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/yoga-training", function() {
                return t("c3/c")
            }])
        }
    },
    [
        ["sWdV", 1, 0, 2, 4, 17]
    ]
]);