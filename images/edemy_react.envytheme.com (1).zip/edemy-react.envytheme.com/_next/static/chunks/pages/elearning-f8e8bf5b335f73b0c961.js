_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [61], {
        "6tuT": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "blog-area ptb-100",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "News and Blogs"
                            }), Object(a.jsx)("h2", {
                                children: "Our Latest Publications"
                            }), Object(a.jsx)("p", {
                                children: "We always give extra care to our student's skills improvements and feel excited to share our latest research and learnings!"
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-blog-post",
                                    children: [Object(a.jsx)("div", {
                                        className: "post-image",
                                        children: Object(a.jsx)(t.a, {
                                            href: "/single-blog-1",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/blog/blog1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "category",
                                                children: "Education"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "/single-blog-1",
                                                children: Object(a.jsx)("a", {
                                                    children: "University Admissions Could Face Emergency Controls"
                                                })
                                            })
                                        }), Object(a.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(a.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(a.jsx)("span", {
                                                        children: "Alex Morgan"
                                                    })]
                                                })
                                            }), Object(a.jsxs)("li", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 30, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-blog-post",
                                    children: [Object(a.jsx)("div", {
                                        className: "post-image",
                                        children: Object(a.jsx)(t.a, {
                                            href: "/single-blog-1",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/blog/blog2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "category",
                                                children: "Online"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "/single-blog-1",
                                                children: Object(a.jsx)("a", {
                                                    children: "Online Learning Can Prepare Students For A Fast-Changing"
                                                })
                                            })
                                        }), Object(a.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(a.jsx)("img", {
                                                        src: "/images/user2.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(a.jsx)("span", {
                                                        children: "Sarah Taylor"
                                                    })]
                                                })
                                            }), Object(a.jsxs)("li", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 29, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(a.jsxs)("div", {
                                    className: "single-blog-post",
                                    children: [Object(a.jsx)("div", {
                                        className: "post-image",
                                        children: Object(a.jsx)(t.a, {
                                            href: "/single-blog-1",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/blog/blog3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "category",
                                                children: "Learning"
                                            })
                                        }), Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "/single-blog-1",
                                                children: Object(a.jsx)("a", {
                                                    children: "As Learning Moves Online, Trigger Warnings Must Too"
                                                })
                                            })
                                        }), Object(a.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(a.jsx)("li", {
                                                children: Object(a.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(a.jsx)("img", {
                                                        src: "/images/user3.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(a.jsx)("span", {
                                                        children: "David Warner"
                                                    })]
                                                })
                                            }), Object(a.jsxs)("li", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 28, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-12 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "blog-post-info",
                                    children: Object(a.jsxs)("p", {
                                        children: ["Get into details now?\u200b ", Object(a.jsx)(t.a, {
                                            href: "/blog-1",
                                            children: Object(a.jsx)("a", {
                                                children: "View all posts"
                                            })
                                        })]
                                    })
                                })
                            })]
                        })]
                    })
                })
            }
        },
        ZZEy: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/elearning", function() {
                return c("nZju")
            }])
        },
        nZju: function(e, s, c) {
            "use strict";
            c.r(s);
            var a = c("o0o1"),
                i = c.n(a),
                t = c("HaE+"),
                n = c("nKUr"),
                l = c("q1tI"),
                r = c.n(l),
                j = c("YFqc"),
                o = c.n(j),
                d = function(e) {
                    var s = e.courses;
                    return Object(n.jsx)("div", {
                        className: "main-banner",
                        children: Object(n.jsx)("div", {
                            className: "container-fluid",
                            children: Object(n.jsxs)("div", {
                                className: "row align-items-center",
                                children: [Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsxs)("div", {
                                        className: "main-banner-content",
                                        children: [Object(n.jsx)("h1", {
                                            children: "The World\u2019s Leading Distance Learning Provider"
                                        }), Object(n.jsx)("p", {
                                            children: "Flexible easy to access learning opportunities can bring a significant change in how individuals prefer to learn! The eDemy can offer you to enjoy the beauty of eLearning!"
                                        }), Object(n.jsx)(o.a, {
                                            href: "/profile-authentication",
                                            children: Object(n.jsxs)("a", {
                                                className: "default-btn",
                                                children: [Object(n.jsx)("i", {
                                                    className: "flaticon-user"
                                                }), " Join For Free ", Object(n.jsx)("span", {})]
                                            })
                                        })]
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsxs)("div", {
                                        className: "main-banner-courses-list",
                                        children: [Object(n.jsx)("div", {
                                            className: "row",
                                            children: s.map((function(e) {
                                                return Object(n.jsx)("div", {
                                                    className: "col-lg-6 col-md-6",
                                                    children: Object(n.jsxs)("div", {
                                                        className: "single-courses-box",
                                                        children: [Object(n.jsxs)("div", {
                                                            className: "courses-image",
                                                            children: [Object(n.jsx)(o.a, {
                                                                href: "/courses/[id]",
                                                                as: "/courses/".concat(e.id),
                                                                children: Object(n.jsx)("a", {
                                                                    className: "d-block image",
                                                                    children: Object(n.jsx)("img", {
                                                                        src: e.profilePhoto,
                                                                        alt: e.title
                                                                    })
                                                                })
                                                            }), Object(n.jsx)(o.a, {
                                                                href: "#",
                                                                children: Object(n.jsx)("a", {
                                                                    className: "fav",
                                                                    children: Object(n.jsx)("i", {
                                                                        className: "flaticon-heart"
                                                                    })
                                                                })
                                                            }), Object(n.jsxs)("div", {
                                                                className: "price shadow",
                                                                children: ["$", e.price]
                                                            })]
                                                        }), Object(n.jsxs)("div", {
                                                            className: "courses-content",
                                                            children: [Object(n.jsxs)("div", {
                                                                className: "course-author d-flex align-items-center",
                                                                children: [Object(n.jsx)("img", {
                                                                    src: "".concat(e.user.profilePhoto ? e.user.profilePhoto : "/images/user1.jpg"),
                                                                    className: "rounded-circle",
                                                                    alt: e.user.name
                                                                }), Object(n.jsx)("span", {
                                                                    children: e.user.name
                                                                })]
                                                            }), Object(n.jsx)("h3", {
                                                                children: Object(n.jsx)(o.a, {
                                                                    href: "/courses/[id]",
                                                                    as: "/courses/".concat(e.id),
                                                                    children: Object(n.jsx)("a", {
                                                                        children: e.title
                                                                    })
                                                                })
                                                            }), Object(n.jsx)("p", {
                                                                children: e.overview.slice(0, 100)
                                                            }), Object(n.jsxs)("ul", {
                                                                className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                                children: [Object(n.jsxs)("li", {
                                                                    children: [Object(n.jsx)("i", {
                                                                        className: "flaticon-agenda"
                                                                    }), " ", parseInt(e.lessons), " Lessons"]
                                                                }), Object(n.jsxs)("li", {
                                                                    children: [Object(n.jsx)("i", {
                                                                        className: "flaticon-people"
                                                                    }), " ", e.enroled_courses.length, " Students"]
                                                                })]
                                                            })]
                                                        })]
                                                    })
                                                }, e.id)
                                            }))
                                        }), Object(n.jsx)("div", {
                                            className: "banner-shape1",
                                            children: Object(n.jsx)("img", {
                                                src: "/images/banner-shape1.png",
                                                alt: "image"
                                            })
                                        }), Object(n.jsx)("div", {
                                            className: "banner-shape2",
                                            children: Object(n.jsx)("img", {
                                                src: "/images/banner-shape2.png",
                                                alt: "image"
                                            })
                                        }), Object(n.jsx)("div", {
                                            className: "banner-shape3",
                                            children: Object(n.jsx)("img", {
                                                src: "/images/banner-shape3.png",
                                                alt: "image"
                                            })
                                        })]
                                    })
                                })]
                            })
                        })
                    })
                },
                b = c("rePB"),
                m = c("ODXe"),
                h = c("Vvt1"),
                O = c.n(h);

            function x(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function g(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? x(Object(c), !0).forEach((function(s) {
                        Object(b.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : x(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var u = O()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                p = {
                    loop: !0,
                    nav: !0,
                    margin: 60,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 3,
                            margin: 20
                        },
                        600: {
                            items: 3
                        },
                        768: {
                            items: 4,
                            margin: 30
                        },
                        1e3: {
                            items: 6
                        }
                    }
                },
                f = function() {
                    var e = r.a.useState(!1),
                        s = Object(m.a)(e, 2),
                        c = s[0],
                        a = s[1];
                    return r.a.useEffect((function() {
                        a(!0)
                    }), []), Object(n.jsx)("div", {
                        className: "partner-area pt-100 pb-70 border-bottom",
                        children: Object(n.jsx)("div", {
                            className: "container",
                            children: c ? Object(n.jsxs)(u, g(g({
                                className: "partner-slides owl-carousel owl-theme"
                            }, p), {}, {
                                children: [Object(n.jsx)("div", {
                                    className: "single-partner-item",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/partner/partner1.png",
                                        alt: "image"
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "single-partner-item",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/partner/partner2.png",
                                        alt: "image"
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "single-partner-item",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/partner/partner3.png",
                                        alt: "image"
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "single-partner-item",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/partner/partner4.png",
                                        alt: "image"
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "single-partner-item",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/partner/partner5.png",
                                        alt: "image"
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "single-partner-item",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/partner/partner6.png",
                                        alt: "image"
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "single-partner-item",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/partner/partner4.png",
                                        alt: "image"
                                    })
                                })]
                            })) : ""
                        })
                    })
                },
                v = function() {
                    return Object(n.jsx)("div", {
                        className: "features-area pt-100 pb-70",
                        children: Object(n.jsxs)("div", {
                            className: "container",
                            children: [Object(n.jsxs)("div", {
                                className: "section-title",
                                children: [Object(n.jsx)("span", {
                                    className: "sub-title",
                                    children: "Education for everyone"
                                }), Object(n.jsx)("h2", {
                                    children: "Affordable Online Courses and Learning Opportunities\u200b"
                                }), Object(n.jsx)("p", {
                                    children: "Finding your own space and utilize better learning options can result in faster than the traditional ways. Enjoy the beauty of eLearning!"
                                })]
                            }), Object(n.jsxs)("div", {
                                className: "row",
                                children: [Object(n.jsx)("div", {
                                    className: "col-lg-3 col-sm-6 col-md-6",
                                    children: Object(n.jsxs)("div", {
                                        className: "single-features-box",
                                        children: [Object(n.jsx)("div", {
                                            className: "icon",
                                            children: Object(n.jsx)("i", {
                                                className: "flaticon-brain-process"
                                            })
                                        }), Object(n.jsx)("h3", {
                                            children: "Learn the Latest Top Skills"
                                        }), Object(n.jsx)("p", {
                                            children: "Learning top skills can bring an extra-ordinary outcome in a career."
                                        }), Object(n.jsx)(o.a, {
                                            href: "/profile-authentication",
                                            children: Object(n.jsx)("a", {
                                                className: "link-btn",
                                                children: "Start Now!"
                                            })
                                        })]
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-3 col-sm-6 col-md-6",
                                    children: Object(n.jsxs)("div", {
                                        className: "single-features-box",
                                        children: [Object(n.jsx)("div", {
                                            className: "icon",
                                            children: Object(n.jsx)("i", {
                                                className: "flaticon-computer"
                                            })
                                        }), Object(n.jsx)("h3", {
                                            children: "Learn in Your Own Pace"
                                        }), Object(n.jsx)("p", {
                                            children: "Everyone prefers to enjoy learning at their own pace & that gives a great result."
                                        }), Object(n.jsx)(o.a, {
                                            href: "/profile-authentication",
                                            children: Object(n.jsx)("a", {
                                                className: "link-btn",
                                                children: "Start Now!"
                                            })
                                        })]
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-3 col-sm-6 col-md-6",
                                    children: Object(n.jsxs)("div", {
                                        className: "single-features-box",
                                        children: [Object(n.jsx)("div", {
                                            className: "icon",
                                            children: Object(n.jsx)("i", {
                                                className: "flaticon-shield-1"
                                            })
                                        }), Object(n.jsx)("h3", {
                                            children: "Learn From Industry Experts"
                                        }), Object(n.jsx)("p", {
                                            children: "Experienced teachers can assist in learning faster with their best approaches!"
                                        }), Object(n.jsx)(o.a, {
                                            href: "/profile-authentication",
                                            children: Object(n.jsx)("a", {
                                                className: "link-btn",
                                                children: "Start Now!"
                                            })
                                        })]
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-3 col-sm-6 col-md-6",
                                    children: Object(n.jsxs)("div", {
                                        className: "single-features-box",
                                        children: [Object(n.jsx)("div", {
                                            className: "icon",
                                            children: Object(n.jsx)("i", {
                                                className: "flaticon-world"
                                            })
                                        }), Object(n.jsx)("h3", {
                                            children: "Enjoy Learning From Anywhere"
                                        }), Object(n.jsx)("p", {
                                            children: "We are delighted to give you options to enjoy learning from anywhere in the world."
                                        }), Object(n.jsx)(o.a, {
                                            href: "/profile-authentication",
                                            children: Object(n.jsx)("a", {
                                                className: "link-btn",
                                                children: "Start Now!"
                                            })
                                        })]
                                    })
                                })]
                            })]
                        })
                    })
                },
                N = function() {
                    return Object(n.jsxs)("div", {
                        className: "about-area bg-fef8ef ptb-100",
                        children: [Object(n.jsx)("div", {
                            className: "container",
                            children: Object(n.jsxs)("div", {
                                className: "row align-items-center",
                                children: [Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsx)("div", {
                                        className: "about-image",
                                        children: Object(n.jsxs)("div", {
                                            className: "row",
                                            children: [Object(n.jsx)("div", {
                                                className: "col-lg-6 col-sm-6 col-md-6 col-6",
                                                children: Object(n.jsx)("div", {
                                                    className: "image",
                                                    children: Object(n.jsx)("img", {
                                                        src: "/images/about-img1.png",
                                                        alt: "image"
                                                    })
                                                })
                                            }), Object(n.jsx)("div", {
                                                className: "col-lg-6 col-sm-6 col-md-6 col-6",
                                                children: Object(n.jsx)("div", {
                                                    className: "image",
                                                    children: Object(n.jsx)("img", {
                                                        src: "/images/about-img2.png",
                                                        alt: "image"
                                                    })
                                                })
                                            }), Object(n.jsx)("div", {
                                                className: "col-lg-6 col-sm-6 col-md-6 col-6",
                                                children: Object(n.jsx)("div", {
                                                    className: "image",
                                                    children: Object(n.jsx)("img", {
                                                        src: "/images/about-img3.png",
                                                        alt: "image"
                                                    })
                                                })
                                            }), Object(n.jsx)("div", {
                                                className: "col-lg-6 col-sm-6 col-md-6 col-6",
                                                children: Object(n.jsx)("div", {
                                                    className: "image",
                                                    children: Object(n.jsx)("img", {
                                                        src: "/images/about-img4.png",
                                                        alt: "image"
                                                    })
                                                })
                                            })]
                                        })
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsxs)("div", {
                                        className: "about-content",
                                        children: [Object(n.jsx)("span", {
                                            className: "sub-title",
                                            children: "Online learning"
                                        }), Object(n.jsx)("h2", {
                                            children: "Develop Your Skills, Learn Something New, and Grow Your Skills From Anywhere in the World!"
                                        }), Object(n.jsx)("p", {
                                            children: "We understand better that online-based learning can make a significant change to reach students from all over the world! Giving options to learn better always can offer the best outcomes!"
                                        }), Object(n.jsxs)("ul", {
                                            className: "features-list",
                                            children: [Object(n.jsx)("li", {
                                                children: Object(n.jsxs)("span", {
                                                    children: [Object(n.jsx)("i", {
                                                        className: "flaticon-experience"
                                                    }), " Expert Trainers"]
                                                })
                                            }), Object(n.jsx)("li", {
                                                children: Object(n.jsxs)("span", {
                                                    children: [Object(n.jsx)("i", {
                                                        className: "flaticon-time-left"
                                                    }), " Lifetime Acces"]
                                                })
                                            }), Object(n.jsx)("li", {
                                                children: Object(n.jsxs)("span", {
                                                    children: [Object(n.jsx)("i", {
                                                        className: "flaticon-tutorials"
                                                    }), " Remote Learning"]
                                                })
                                            }), Object(n.jsx)("li", {
                                                children: Object(n.jsxs)("span", {
                                                    children: [Object(n.jsx)("i", {
                                                        className: "flaticon-self-growth"
                                                    }), " Self Development"]
                                                })
                                            })]
                                        }), Object(n.jsx)(o.a, {
                                            href: "/courses-1",
                                            children: Object(n.jsxs)("a", {
                                                className: "default-btn",
                                                children: [Object(n.jsx)("i", {
                                                    className: "flaticon-user"
                                                }), " View All Courses ", Object(n.jsx)("span", {})]
                                            })
                                        })]
                                    })
                                })]
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape1",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape1.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape2",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape2.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape3",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape3.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape4",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape4.png",
                                alt: "image"
                            })
                        })]
                    })
                },
                y = function(e) {
                    var s = e.courses;
                    return Object(n.jsx)("div", {
                        className: "courses-area ptb-100",
                        children: Object(n.jsxs)("div", {
                            className: "container",
                            children: [Object(n.jsxs)("div", {
                                className: "section-title",
                                children: [Object(n.jsx)("span", {
                                    className: "sub-title",
                                    children: "Learn At Your Own Pace"
                                }), Object(n.jsx)("h2", {
                                    children: "eDemy Popular Courses"
                                }), Object(n.jsx)("p", {
                                    children: "Explore all of our courses and pick your suitable ones to enroll and start learning with us! We ensure that you will never regret it!"
                                })]
                            }), Object(n.jsxs)("div", {
                                className: "row",
                                children: [s ? s.map((function(e) {
                                    return Object(n.jsx)("div", {
                                        className: "col-lg-4 col-md-6",
                                        children: Object(n.jsxs)("div", {
                                            className: "single-courses-box",
                                            children: [Object(n.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(n.jsx)(o.a, {
                                                    href: "/courses/[id]",
                                                    as: "/courses/".concat(e.id),
                                                    children: Object(n.jsx)("a", {
                                                        className: "d-block image",
                                                        children: Object(n.jsx)("img", {
                                                            src: e.profilePhoto,
                                                            alt: e.title
                                                        })
                                                    })
                                                }), Object(n.jsx)(o.a, {
                                                    href: "#",
                                                    children: Object(n.jsx)("a", {
                                                        className: "fav",
                                                        children: Object(n.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    })
                                                }), Object(n.jsxs)("div", {
                                                    className: "price shadow",
                                                    children: ["$", e.price]
                                                })]
                                            }), Object(n.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(n.jsxs)("div", {
                                                    className: "course-author d-flex align-items-center",
                                                    children: [Object(n.jsx)("img", {
                                                        src: "".concat(e.user.profilePhoto ? e.user.profilePhoto : "/images/user1.jpg"),
                                                        className: "rounded-circle",
                                                        alt: e.user.name
                                                    }), Object(n.jsx)("span", {
                                                        children: e.user.name
                                                    })]
                                                }), Object(n.jsx)("h3", {
                                                    children: Object(n.jsx)(o.a, {
                                                        href: "/courses/[id]",
                                                        as: "/courses/".concat(e.id),
                                                        children: Object(n.jsx)("a", {
                                                            children: e.title
                                                        })
                                                    })
                                                }), Object(n.jsx)("p", {
                                                    children: e.overview.slice(0, 100)
                                                }), Object(n.jsxs)("ul", {
                                                    className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(n.jsxs)("li", {
                                                        children: [Object(n.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " ", parseInt(e.lessons), " Lessons"]
                                                    }), Object(n.jsxs)("li", {
                                                        children: [Object(n.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " ", e.enroled_courses.length, " Students"]
                                                    })]
                                                })]
                                            })]
                                        })
                                    }, e.id)
                                })) : Object(n.jsx)("h2", {
                                    children: "Empty"
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-12 col-md-12",
                                    children: Object(n.jsx)("div", {
                                        className: "courses-info",
                                        children: Object(n.jsxs)("p", {
                                            children: ["Enjoy the top notch learning methods and achieve next level skills! You are the creator of your own career & we will guide you through that. ", Object(n.jsx)(o.a, {
                                                href: "/profile-authentication",
                                                children: Object(n.jsx)("a", {
                                                    children: "Register Free Now!"
                                                })
                                            }), "."]
                                        })
                                    })
                                })]
                            })]
                        })
                    })
                },
                w = function() {
                    return Object(n.jsx)("div", {
                        className: "funfacts-list",
                        children: Object(n.jsxs)("div", {
                            className: "row",
                            children: [Object(n.jsx)("div", {
                                className: "col-lg-6 col-md-6 col-sm-6",
                                children: Object(n.jsxs)("div", {
                                    className: "single-funfacts-box",
                                    children: [Object(n.jsx)("h3", {
                                        children: "1,926"
                                    }), Object(n.jsx)("p", {
                                        children: "Finished Sessions"
                                    })]
                                })
                            }), Object(n.jsx)("div", {
                                className: "col-lg-6 col-md-6 col-sm-6",
                                children: Object(n.jsxs)("div", {
                                    className: "single-funfacts-box",
                                    children: [Object(n.jsx)("h3", {
                                        children: "3,279"
                                    }), Object(n.jsx)("p", {
                                        children: "Enrolled Learners"
                                    })]
                                })
                            }), Object(n.jsx)("div", {
                                className: "col-lg-6 col-md-6 col-sm-6",
                                children: Object(n.jsxs)("div", {
                                    className: "single-funfacts-box",
                                    children: [Object(n.jsx)("h3", {
                                        children: "250"
                                    }), Object(n.jsx)("p", {
                                        children: "Online Instructors"
                                    })]
                                })
                            }), Object(n.jsx)("div", {
                                className: "col-lg-6 col-md-6 col-sm-6",
                                children: Object(n.jsxs)("div", {
                                    className: "single-funfacts-box",
                                    children: [Object(n.jsx)("h3", {
                                        children: "100%"
                                    }), Object(n.jsx)("p", {
                                        children: "Satisfaction Rate"
                                    })]
                                })
                            })]
                        })
                    })
                },
                P = O()((function() {
                    return Promise.all([c.e(0), c.e(6), c.e(8)]).then(c.t.bind(null, "60Bi", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["60Bi"]
                        },
                        modules: ["react-modal-video"]
                    }
                }),
                k = function() {
                    var e = r.a.useState(!1),
                        s = Object(m.a)(e, 2),
                        c = s[0],
                        a = s[1];
                    r.a.useEffect((function() {
                        a(!0)
                    }), []);
                    var i = r.a.useState(!0),
                        t = Object(m.a)(i, 2),
                        l = t[0],
                        j = t[1];
                    return Object(n.jsxs)(r.a.Fragment, {
                        children: [Object(n.jsxs)("div", {
                            className: "video-box",
                            children: [Object(n.jsx)("div", {
                                className: "image",
                                children: Object(n.jsx)("img", {
                                    src: "/images/video-img1.jpg",
                                    className: "shadow",
                                    alt: "image"
                                })
                            }), Object(n.jsx)(o.a, {
                                href: "#play-video",
                                children: Object(n.jsx)("a", {
                                    onClick: function(e) {
                                        e.preventDefault(), j(!l)
                                    },
                                    className: "video-btn popup-youtube",
                                    children: Object(n.jsx)("i", {
                                        className: "flaticon-play"
                                    })
                                })
                            }), Object(n.jsx)("div", {
                                className: "shape10",
                                children: Object(n.jsx)("img", {
                                    src: "/images/shape9.png",
                                    alt: "image"
                                })
                            })]
                        }), c ? Object(n.jsx)(P, {
                            channel: "youtube",
                            isOpen: !l,
                            videoId: "bk7McNUjWgw",
                            onClose: function() {
                                return j(!l)
                            }
                        }) : ""]
                    })
                };

            function S(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function E(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? S(Object(c), !0).forEach((function(s) {
                        Object(b.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : S(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var L = O()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                D = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    animateOut: "fadeOut",
                    items: 1,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"]
                },
                F = function() {
                    var e = r.a.useState(!1),
                        s = Object(m.a)(e, 2),
                        c = s[0],
                        a = s[1];
                    return r.a.useEffect((function() {
                        a(!0)
                    }), []), Object(n.jsxs)("div", {
                        className: "funfacts-and-feedback-area ptb-100",
                        children: [Object(n.jsx)("div", {
                            className: "container",
                            children: Object(n.jsxs)("div", {
                                className: "row align-items-center",
                                children: [Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsxs)("div", {
                                        className: "feedback-content",
                                        children: [Object(n.jsx)("span", {
                                            className: "sub-title",
                                            children: "Distance learning"
                                        }), Object(n.jsx)("h2", {
                                            children: "Flexible Study at Your Own Pace, According to Your Own Needs"
                                        }), Object(n.jsx)("p", {
                                            children: "With the eDemy, you can study whenever and wherever you choose. We have students in over 175 countries and a global reputation as a pioneer in the field of flexible learning. Our teaching also means, if you travel often or need to relocate, you can continue to study wherever you go."
                                        }), c ? Object(n.jsxs)(L, E(E({
                                            className: "feedback-slides owl-carousel owl-theme"
                                        }, D), {}, {
                                            children: [Object(n.jsxs)("div", {
                                                className: "single-feedback-item",
                                                children: [Object(n.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                }), Object(n.jsxs)("div", {
                                                    className: "client-info d-flex align-items-center",
                                                    children: [Object(n.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(n.jsxs)("div", {
                                                        className: "title",
                                                        children: [Object(n.jsx)("h3", {
                                                            children: "John Smith"
                                                        }), Object(n.jsx)("span", {
                                                            children: "Python Developer"
                                                        })]
                                                    })]
                                                })]
                                            }), Object(n.jsxs)("div", {
                                                className: "single-feedback-item",
                                                children: [Object(n.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                }), Object(n.jsxs)("div", {
                                                    className: "client-info d-flex align-items-center",
                                                    children: [Object(n.jsx)("img", {
                                                        src: "/images/user2.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(n.jsxs)("div", {
                                                        className: "title",
                                                        children: [Object(n.jsx)("h3", {
                                                            children: "Sarah Taylor"
                                                        }), Object(n.jsx)("span", {
                                                            children: "PHP Developer"
                                                        })]
                                                    })]
                                                })]
                                            }), Object(n.jsxs)("div", {
                                                className: "single-feedback-item",
                                                children: [Object(n.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                }), Object(n.jsxs)("div", {
                                                    className: "client-info d-flex align-items-center",
                                                    children: [Object(n.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(n.jsxs)("div", {
                                                        className: "title",
                                                        children: [Object(n.jsx)("h3", {
                                                            children: "David Warner"
                                                        }), Object(n.jsx)("span", {
                                                            children: "QA Developer"
                                                        })]
                                                    })]
                                                })]
                                            })]
                                        })) : "", Object(n.jsx)("div", {
                                            className: "feedback-info",
                                            children: Object(n.jsxs)("p", {
                                                children: ["Not a member yet?\u200b ", Object(n.jsx)(o.a, {
                                                    href: "/profile-authentication",
                                                    children: Object(n.jsx)("a", {
                                                        children: "Register Now"
                                                    })
                                                })]
                                            })
                                        })]
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsx)(w, {})
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-12 col-md-12",
                                    children: Object(n.jsx)(k, {})
                                })]
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape2",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape2.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape3",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape3.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape4",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape4.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape9",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape8.svg",
                                alt: "image"
                            })
                        })]
                    })
                },
                A = function() {
                    return Object(n.jsx)("div", {
                        className: "get-instant-courses-area",
                        children: Object(n.jsx)("div", {
                            className: "container",
                            children: Object(n.jsxs)("div", {
                                className: "get-instant-courses-inner-area",
                                children: [Object(n.jsxs)("div", {
                                    className: "row align-items-center",
                                    children: [Object(n.jsx)("div", {
                                        className: "col-lg-8 col-md-12",
                                        children: Object(n.jsxs)("div", {
                                            className: "get-instant-courses-content",
                                            children: [Object(n.jsx)("span", {
                                                className: "sub-title",
                                                children: "Get Instant Access to The Free"
                                            }), Object(n.jsx)("h2", {
                                                children: "Self Development Course"
                                            }), Object(n.jsx)("p", {
                                                children: "eDemy Self Development Course can assist you in bringing the significant changes in personal understanding and reshaping the confidence to achieve the best from your career! We trust that learning should be enjoyable, and only that can make substantial changes to someone!"
                                            }), Object(n.jsx)(o.a, {
                                                href: "/profile-authentication",
                                                children: Object(n.jsxs)("a", {
                                                    className: "default-btn",
                                                    children: [Object(n.jsx)("i", {
                                                        className: "flaticon-user"
                                                    }), " Start For Free ", Object(n.jsx)("span", {})]
                                                })
                                            })]
                                        })
                                    }), Object(n.jsx)("div", {
                                        className: "col-lg-4 col-md-12",
                                        children: Object(n.jsxs)("div", {
                                            className: "get-instant-courses-image",
                                            children: [Object(n.jsx)("img", {
                                                src: "/images/man.jpg",
                                                alt: "image"
                                            }), Object(n.jsx)("div", {
                                                className: "shape7",
                                                children: Object(n.jsx)("img", {
                                                    src: "/images/shape4.png",
                                                    alt: "image"
                                                })
                                            }), Object(n.jsx)("div", {
                                                className: "shape6",
                                                children: Object(n.jsx)("img", {
                                                    src: "/images/shape6.png",
                                                    alt: "image"
                                                })
                                            })]
                                        })
                                    })]
                                }), Object(n.jsx)("div", {
                                    className: "shape5",
                                    children: Object(n.jsx)("img", {
                                        src: "/images/shape5.png",
                                        alt: "image"
                                    })
                                })]
                            })
                        })
                    })
                },
                T = c("6tuT"),
                C = function() {
                    return Object(n.jsxs)("div", {
                        className: "view-all-courses-area bg-fef8ef",
                        children: [Object(n.jsx)("div", {
                            className: "container-fluid",
                            children: Object(n.jsxs)("div", {
                                className: "row align-items-center",
                                children: [Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsxs)("div", {
                                        className: "view-all-courses-content",
                                        children: [Object(n.jsx)("span", {
                                            className: "sub-title",
                                            children: "Distance learning"
                                        }), Object(n.jsx)("h2", {
                                            children: "Feel Like You Are Attending Your classNamees Physically!"
                                        }), Object(n.jsx)("p", {
                                            children: "eDemy training programs can bring you a super exciting experience of learning through online! You never face any negative experience while enjoying your classNamees virtually by sitting in your comfort zone. Our flexible learning initiatives will help you to learn better and quicker than the traditional ways of learning skills."
                                        }), Object(n.jsx)(o.a, {
                                            href: "/courses-1",
                                            children: Object(n.jsxs)("a", {
                                                className: "default-btn",
                                                children: [Object(n.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " View Courses ", Object(n.jsx)("span", {})]
                                            })
                                        })]
                                    })
                                }), Object(n.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(n.jsx)("div", {
                                        className: "view-all-courses-image",
                                        children: Object(n.jsx)("img", {
                                            src: "/images/man-with-laptop.png",
                                            alt: "image"
                                        })
                                    })
                                })]
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape1",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape1.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape9",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape8.svg",
                                alt: "image"
                            })
                        })]
                    })
                },
                _ = function() {
                    return Object(n.jsxs)("div", {
                        className: "premium-access-area ptb-100",
                        children: [Object(n.jsx)("div", {
                            className: "container",
                            children: Object(n.jsxs)("div", {
                                className: "premium-access-content",
                                children: [Object(n.jsx)("span", {
                                    className: "sub-title",
                                    children: "Affordable Certification"
                                }), Object(n.jsx)("h2", {
                                    children: "Get Your Quality Skills Certificate Through Online Exam"
                                }), Object(n.jsx)("p", {
                                    children: "Students friendly pricing for the certificate programs helps individuals to get their skill certificate easier than ever!"
                                }), Object(n.jsx)(o.a, {
                                    href: "/membership-levels",
                                    children: Object(n.jsxs)("a", {
                                        className: "default-btn",
                                        children: [Object(n.jsx)("i", {
                                            className: "flaticon-user"
                                        }), " Get Started Now ", Object(n.jsx)("span", {})]
                                    })
                                })]
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape3",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape3.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape4",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape4.png",
                                alt: "image"
                            })
                        }), Object(n.jsx)("div", {
                            className: "shape8",
                            children: Object(n.jsx)("img", {
                                src: "/images/shape7.png",
                                alt: "image"
                            })
                        })]
                    })
                },
                W = c("vDqi"),
                Y = c.n(W),
                R = c("rjN7"),
                q = function(e) {
                    var s = e.courses;
                    return Object(n.jsxs)(r.a.Fragment, {
                        children: [Object(n.jsx)(d, {
                            courses: s.slice(0, 2)
                        }), Object(n.jsx)(f, {}), Object(n.jsx)(v, {}), Object(n.jsx)(N, {}), Object(n.jsx)(y, {
                            courses: s
                        }), Object(n.jsx)(F, {}), Object(n.jsx)(A, {}), Object(n.jsx)(T.a, {}), Object(n.jsx)(C, {}), Object(n.jsx)(_, {})]
                    })
                };
            q.getInitialProps = Object(t.a)(i.a.mark((function e() {
                var s, c;
                return i.a.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return s = "".concat(R.a, "/api/v1/courses/homepage-courses"), e.next = 3, Y.a.get(s);
                        case 3:
                            return c = e.sent, e.abrupt("return", c.data);
                        case 5:
                        case "end":
                            return e.stop()
                    }
                }), e)
            })));
            s.default = q
        },
        rePB: function(e, s, c) {
            "use strict";

            function a(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return a
            }))
        }
    },
    [
        ["ZZEy", 1, 0, 2, 4, 5]
    ]
]);