_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [57], {
        Ix5F: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                t = (c("q1tI"), c("YFqc")),
                i = c.n(t);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    t = e.homePageText,
                    l = e.activePageText;
                return Object(a.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(a.jsxs)("ul", {
                                children: [Object(a.jsx)("li", {
                                    children: Object(a.jsx)(i.a, {
                                        href: c,
                                        children: Object(a.jsx)("a", {
                                            children: t
                                        })
                                    })
                                }), Object(a.jsx)("li", {
                                    className: "active",
                                    children: l
                                })]
                            }), Object(a.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        UL1i: function(e, s, c) {
            "use strict";
            c.r(s);
            var a = c("nKUr"),
                t = c("q1tI"),
                i = c.n(t),
                l = c("Ix5F"),
                r = c("YFqc"),
                n = c.n(r),
                j = function() {
                    return Object(a.jsxs)("div", {
                        className: "widget-area",
                        children: [Object(a.jsxs)("div", {
                            className: "widget widget_search",
                            children: [Object(a.jsx)("h3", {
                                className: "widget-title",
                                children: "Search"
                            }), Object(a.jsxs)("form", {
                                className: "search-form",
                                children: [Object(a.jsxs)("label", {
                                    children: [Object(a.jsx)("span", {
                                        className: "screen-reader-text",
                                        children: "Search for:"
                                    }), Object(a.jsx)("input", {
                                        type: "search",
                                        className: "search-field",
                                        placeholder: "Search..."
                                    })]
                                }), Object(a.jsx)("button", {
                                    type: "submit",
                                    children: Object(a.jsx)("i", {
                                        className: "bx bx-search-alt"
                                    })
                                })]
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "widget widget_recent_courses",
                            children: [Object(a.jsx)("h3", {
                                className: "widget-title",
                                children: "Recent Courses"
                            }), Object(a.jsxs)("div", {
                                className: "item",
                                children: [Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsx)("a", {
                                        className: "thumb",
                                        children: Object(a.jsx)("span", {
                                            className: "fullimage cover bg1",
                                            role: "img"
                                        })
                                    })
                                }), Object(a.jsxs)("div", {
                                    className: "info",
                                    children: [Object(a.jsx)("span", {
                                        children: "$49.00"
                                    }), Object(a.jsx)("h4", {
                                        className: "title usmall",
                                        children: Object(a.jsx)(n.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                children: "The Data Science Course 2020: Complete Data Science Bootcamp"
                                            })
                                        })
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "clear"
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "item",
                                children: [Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsx)("a", {
                                        className: "thumb",
                                        children: Object(a.jsx)("span", {
                                            className: "fullimage cover bg2",
                                            role: "img"
                                        })
                                    })
                                }), Object(a.jsxs)("div", {
                                    className: "info",
                                    children: [Object(a.jsx)("span", {
                                        children: "$59.00"
                                    }), Object(a.jsx)("h4", {
                                        className: "title usmall",
                                        children: Object(a.jsx)(n.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                children: "Java Programming MasterclassName for Software Developers"
                                            })
                                        })
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "clear"
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "item",
                                children: [Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsx)("a", {
                                        className: "thumb",
                                        children: Object(a.jsx)("span", {
                                            className: "fullimage cover bg3",
                                            role: "img"
                                        })
                                    })
                                }), Object(a.jsxs)("div", {
                                    className: "info",
                                    children: [Object(a.jsx)("span", {
                                        children: "$69.00"
                                    }), Object(a.jsx)("h4", {
                                        className: "title usmall",
                                        children: Object(a.jsx)(n.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                children: "Deep Learning A-Z\u2122: Hands-On Artificial Neural Networks"
                                            })
                                        })
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "clear"
                                })]
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "widget widget_tag_cloud",
                            children: [Object(a.jsx)("h3", {
                                className: "widget-title",
                                children: "Popular Tags"
                            }), Object(a.jsxs)("div", {
                                className: "tagcloud",
                                children: [Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Business ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(3)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Design ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(3)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Digital ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["SEO ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Braike ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Fashion ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Software ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Travel ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(1)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Smart ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(1)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Marketing ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(1)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Tips ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                }), Object(a.jsx)(n.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Website ", Object(a.jsx)("span", {
                                            className: "tag-link-count",
                                            children: "(2)"
                                        })]
                                    })
                                })]
                            })]
                        })]
                    })
                };
            s.default = function() {
                return Object(a.jsxs)(i.a.Fragment, {
                    children: [Object(a.jsx)(l.a, {
                        pageTitle: "Courses Right Sidebar",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Courses Right Sidebar"
                    }), Object(a.jsx)("div", {
                        className: "courses-area ptb-100",
                        children: Object(a.jsx)("div", {
                            className: "container",
                            children: Object(a.jsxs)("div", {
                                className: "row",
                                children: [Object(a.jsxs)("div", {
                                    className: "col-lg-8 col-md-12",
                                    children: [Object(a.jsxs)("div", {
                                        className: "edemy-grid-sorting row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-6 result-count",
                                            children: Object(a.jsxs)("p", {
                                                children: ["We found ", Object(a.jsx)("span", {
                                                    className: "count",
                                                    children: "12"
                                                }), " courses available for you"]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-6 ordering",
                                            children: Object(a.jsx)("div", {
                                                className: "select-box",
                                                children: Object(a.jsxs)("select", {
                                                    className: "form-control",
                                                    children: [Object(a.jsx)("option", {
                                                        children: "Sort By"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Popularity"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Latest"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Price: low to high"
                                                    }), Object(a.jsx)("option", {
                                                        children: "Price: high to low"
                                                    })]
                                                })
                                            })
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "row",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-courses-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(a.jsx)(n.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block image",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/courses/courses1.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(a.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price shadow",
                                                        children: "$39"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(a.jsxs)("div", {
                                                        className: "course-author d-flex align-items-center",
                                                        children: [Object(a.jsx)("img", {
                                                            src: "/images/user1.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(a.jsx)("span", {
                                                            children: "Alex Morgan"
                                                        })]
                                                    }), Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(n.a, {
                                                            href: "/single-courses-1",
                                                            children: Object(a.jsx)("a", {
                                                                children: "The Data Science Course 2020: Complete Data Science Bootcamp"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("p", {
                                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                    }), Object(a.jsxs)("ul", {
                                                        className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 15 Lessons"]
                                                        }), Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 145 Students"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-courses-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(a.jsx)(n.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block image",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/courses/courses2.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(a.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price shadow",
                                                        children: "$49"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(a.jsxs)("div", {
                                                        className: "course-author d-flex align-items-center",
                                                        children: [Object(a.jsx)("img", {
                                                            src: "/images/user2.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(a.jsx)("span", {
                                                            children: "Sarah Taylor"
                                                        })]
                                                    }), Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(n.a, {
                                                            href: "/single-courses-1",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Java Programming MasterclassName for Software Developers"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("p", {
                                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                    }), Object(a.jsxs)("ul", {
                                                        className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 20 Lessons"]
                                                        }), Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 100 Students"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-courses-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(a.jsx)(n.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block image",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/courses/courses3.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(a.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price shadow",
                                                        children: "$59"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(a.jsxs)("div", {
                                                        className: "course-author d-flex align-items-center",
                                                        children: [Object(a.jsx)("img", {
                                                            src: "/images/user3.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(a.jsx)("span", {
                                                            children: "David Warner"
                                                        })]
                                                    }), Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(n.a, {
                                                            href: "/single-courses-1",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Deep Learning A-Z\u2122: Hands-On Artificial Neural Networks"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("p", {
                                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                    }), Object(a.jsxs)("ul", {
                                                        className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 20 Lessons"]
                                                        }), Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 150 Students"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-courses-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(a.jsx)(n.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block image",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/courses/courses4.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(a.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price shadow",
                                                        children: "$39"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(a.jsxs)("div", {
                                                        className: "course-author d-flex align-items-center",
                                                        children: [Object(a.jsx)("img", {
                                                            src: "/images/user6.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(a.jsx)("span", {
                                                            children: "Alex Morgan"
                                                        })]
                                                    }), Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(n.a, {
                                                            href: "/single-courses-1",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Python for Finance: Investment Fundamentals & Data Analytics"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("p", {
                                                        children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                    }), Object(a.jsxs)("ul", {
                                                        className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 15 Lessons"]
                                                        }), Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 145 Students"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-courses-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(a.jsx)(n.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block image",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/courses/courses5.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(a.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price shadow",
                                                        children: "$49"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(a.jsxs)("div", {
                                                        className: "course-author d-flex align-items-center",
                                                        children: [Object(a.jsx)("img", {
                                                            src: "/images/user5.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(a.jsx)("span", {
                                                            children: "Sarah Taylor"
                                                        })]
                                                    }), Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(n.a, {
                                                            href: "/single-courses-1",
                                                            children: Object(a.jsx)("a", {
                                                                children: "Machine Learning A-Z\u2122: Hands-On Python & R In Data Science"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("p", {
                                                        children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                    }), Object(a.jsxs)("ul", {
                                                        className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 20 Lessons"]
                                                        }), Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 100 Students"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: Object(a.jsxs)("div", {
                                                className: "single-courses-box",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "courses-image",
                                                    children: [Object(a.jsx)(n.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            className: "d-block image",
                                                            children: Object(a.jsx)("img", {
                                                                src: "/images/courses/courses6.jpg",
                                                                alt: "image"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "fav",
                                                        children: Object(a.jsx)("i", {
                                                            className: "flaticon-heart"
                                                        })
                                                    }), Object(a.jsx)("div", {
                                                        className: "price shadow",
                                                        children: "$99"
                                                    })]
                                                }), Object(a.jsxs)("div", {
                                                    className: "courses-content",
                                                    children: [Object(a.jsxs)("div", {
                                                        className: "course-author d-flex align-items-center",
                                                        children: [Object(a.jsx)("img", {
                                                            src: "/images/user4.jpg",
                                                            className: "rounded-circle",
                                                            alt: "image"
                                                        }), Object(a.jsx)("span", {
                                                            children: "James Anderson"
                                                        })]
                                                    }), Object(a.jsx)("h3", {
                                                        children: Object(a.jsx)(n.a, {
                                                            href: "/single-courses-1",
                                                            children: Object(a.jsx)("a", {
                                                                children: "R Programming A-Z\u2122: R For Data Science With Real Exercises!"
                                                            })
                                                        })
                                                    }), Object(a.jsx)("p", {
                                                        children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                                    }), Object(a.jsxs)("ul", {
                                                        className: "courses-box-footer d-flex justify-content-between align-items-center",
                                                        children: [Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-agenda"
                                                            }), " 44 Lessons"]
                                                        }), Object(a.jsxs)("li", {
                                                            children: [Object(a.jsx)("i", {
                                                                className: "flaticon-people"
                                                            }), " 440 Students"]
                                                        })]
                                                    })]
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-12 col-md-12 col-sm-12",
                                            children: Object(a.jsxs)("div", {
                                                className: "pagination-area text-center",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "prev page-numbers",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bx-chevrons-left"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "page-numbers current",
                                                    "aria-current": "page",
                                                    children: "1"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "2"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "3"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "page-numbers",
                                                    children: "4"
                                                }), Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "next page-numbers",
                                                    children: Object(a.jsx)("i", {
                                                        className: "bx bx-chevrons-right"
                                                    })
                                                })]
                                            })
                                        })]
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-md-12",
                                    children: Object(a.jsx)(j, {})
                                })]
                            })
                        })
                    })]
                })
            }
        },
        V6aF: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/courses-6", function() {
                return c("UL1i")
            }])
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        cTJO: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                t = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var i = t(c("q1tI")),
                l = c("elyg"),
                r = c("nOHt"),
                n = c("vNVm"),
                j = {};

            function o(e, s, c, a) {
                if (e && (0, l.isLocalURL)(s)) {
                    e.prefetch(s, c, a).catch((function(e) {
                        0
                    }));
                    var t = a && "undefined" !== typeof a.locale ? a.locale : e && e.locale;
                    j[s + "%" + c + (t ? "%" + t : "")] = !0
                }
            }
            var d = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, r.useRouter)(),
                    t = c && c.pathname || "/",
                    d = i.default.useMemo((function() {
                        var s = (0, l.resolveHref)(t, e.href, !0),
                            c = a(s, 2),
                            i = c[0],
                            r = c[1];
                        return {
                            href: i,
                            as: e.as ? (0, l.resolveHref)(t, e.as) : r || i
                        }
                    }), [t, e.href, e.as]),
                    h = d.href,
                    b = d.as,
                    m = e.children,
                    x = e.replace,
                    u = e.shallow,
                    O = e.scroll,
                    g = e.locale;
                "string" === typeof m && (m = i.default.createElement("a", null, m));
                var f = i.Children.only(m),
                    p = f && "object" === typeof f && f.ref,
                    N = (0, n.useIntersection)({
                        rootMargin: "200px"
                    }),
                    v = a(N, 2),
                    w = v[0],
                    y = v[1],
                    L = i.default.useCallback((function(e) {
                        w(e), p && ("function" === typeof p ? p(e) : "object" === typeof p && (p.current = e))
                    }), [p, w]);
                (0, i.useEffect)((function() {
                    var e = y && s && (0, l.isLocalURL)(h),
                        a = "undefined" !== typeof g ? g : c && c.locale,
                        t = j[h + "%" + b + (a ? "%" + a : "")];
                    e && !t && o(c, h, b, {
                        locale: a
                    })
                }), [b, h, y, g, s, c]);
                var k = {
                    ref: L,
                    onClick: function(e) {
                        f.props && "function" === typeof f.props.onClick && f.props.onClick(e), e.defaultPrevented || function(e, s, c, a, t, i, r, n) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, l.isLocalURL)(c)) && (e.preventDefault(), null == r && (r = a.indexOf("#") < 0), s[t ? "replace" : "push"](c, a, {
                                shallow: i,
                                locale: n,
                                scroll: r
                            }).then((function(e) {
                                e && r && document.body.focus()
                            })))
                        }(e, c, h, b, x, u, O, g)
                    },
                    onMouseEnter: function(e) {
                        (0, l.isLocalURL)(h) && (f.props && "function" === typeof f.props.onMouseEnter && f.props.onMouseEnter(e), o(c, h, b, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === f.type && !("href" in f.props)) {
                    var S = "undefined" !== typeof g ? g : c && c.locale,
                        _ = (0, l.getDomainLocale)(b, S, c && c.locales, c && c.domainLocales);
                    k.href = _ || (0, l.addBasePath)((0, l.addLocale)(b, S, c && c.defaultLocale))
                }
                return i.default.cloneElement(f, k)
            };
            s.default = d
        },
        vNVm: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                t = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !r,
                    t = (0, i.useRef)(),
                    j = (0, i.useState)(!1),
                    o = a(j, 2),
                    d = o[0],
                    h = o[1],
                    b = (0, i.useCallback)((function(e) {
                        t.current && (t.current(), t.current = void 0), c || d || e && e.tagName && (t.current = function(e, s, c) {
                            var a = function(e) {
                                    var s = e.rootMargin || "",
                                        c = n.get(s);
                                    if (c) return c;
                                    var a = new Map,
                                        t = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = a.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return n.set(s, c = {
                                        id: s,
                                        observer: t,
                                        elements: a
                                    }), c
                                }(c),
                                t = a.id,
                                i = a.observer,
                                l = a.elements;
                            return l.set(e, s), i.observe(e),
                                function() {
                                    l.delete(e), i.unobserve(e), 0 === l.size && (i.disconnect(), n.delete(t))
                                }
                        }(e, (function(e) {
                            return e && h(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, d]);
                return (0, i.useEffect)((function() {
                    r || d || (0, l.default)((function() {
                        return h(!0)
                    }))
                }), [d]), [b, d]
            };
            var i = c("q1tI"),
                l = t(c("0G5g")),
                r = "undefined" !== typeof IntersectionObserver;
            var n = new Map
        }
    },
    [
        ["V6aF", 1, 0, 2]
    ]
]);