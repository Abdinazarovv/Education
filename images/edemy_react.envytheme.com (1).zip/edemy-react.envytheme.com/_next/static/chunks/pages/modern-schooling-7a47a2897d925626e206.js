_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [78], {
        "5wCi": function(j, c, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/modern-schooling", function() {
                return n("byn2")
            }])
        },
        byn2: function(j, c, n) {
            "use strict";
            n.r(c);
            var t = n("nKUr"),
                e = n("q1tI"),
                s = n.n(e),
                a = n("hXH4"),
                b = n("QccS"),
                i = n("bmk4"),
                o = n("+Fop"),
                r = n("Y5ZX"),
                w = n("rs0+"),
                x = n("JcBV"),
                O = n("AjPI"),
                _ = n("CLvZ"),
                u = n("1GiN"),
                d = n("FuXQ");
            c.default = function() {
                return Object(t.jsxs)(s.a.Fragment, {
                    children: [Object(t.jsx)(a.a, {}), Object(t.jsx)(b.a, {}), Object(t.jsx)(i.a, {}), Object(t.jsx)(o.a, {}), Object(t.jsx)(r.a, {}), Object(t.jsx)(w.a, {}), Object(t.jsx)(x.a, {}), Object(t.jsx)(O.a, {}), Object(t.jsx)(_.a, {}), Object(t.jsx)(u.a, {}), Object(t.jsx)(d.a, {})]
                })
            }
        }
    },
    [
        ["5wCi", 1, 0, 2, 4, 20]
    ]
]);