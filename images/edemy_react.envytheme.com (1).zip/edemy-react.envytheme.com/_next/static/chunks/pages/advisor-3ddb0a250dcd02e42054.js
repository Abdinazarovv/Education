_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [39], {
        "7pJ3": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                l = (c("q1tI"), c("YFqc")),
                t = c.n(l);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "premium-access-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "premium-access-content",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go at your own pace"
                            }), Object(a.jsx)("h2", {
                                children: "Give their limitless potential unlimited access"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(a.jsx)(t.a, {
                                href: "/membership-levels",
                                children: Object(a.jsxs)("a", {
                                    className: "default-btn",
                                    children: [Object(a.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Give Premium Access ", Object(a.jsx)("span", {})]
                                })
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape3",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape4",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape8",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape7.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        "8PCm": function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/advisor", function() {
                return c("E3Bg")
            }])
        },
        E3Bg: function(e, s, c) {
            "use strict";
            c.r(s);
            var a = c("nKUr"),
                l = c("q1tI"),
                t = c.n(l),
                i = c("Ix5F"),
                r = c("7pJ3"),
                n = c("YFqc"),
                j = c.n(n);
            s.default = function() {
                return Object(a.jsxs)(t.a.Fragment, {
                    children: [Object(a.jsx)(i.a, {
                        pageTitle: "Advisor",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Advisor"
                    }), Object(a.jsx)("div", {
                        className: "advisor-area pt-100 pb-70",
                        children: Object(a.jsx)("div", {
                            className: "container",
                            children: Object(a.jsxs)("div", {
                                className: "row",
                                children: [Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-advisor-item",
                                        children: [Object(a.jsxs)("div", {
                                            className: "advisor-image",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/advisor/advisor4.jpg",
                                                alt: "image"
                                            }), Object(a.jsxs)("ul", {
                                                className: "social-link",
                                                children: [Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-facebook"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-twitter"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-instagram"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-linkedin"
                                                        })
                                                    })
                                                })]
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "advisor-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "#",
                                                    children: Object(a.jsx)("a", {
                                                        children: "James Andy"
                                                    })
                                                })
                                            }), Object(a.jsx)("span", {
                                                children: "Project Management Expert"
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-advisor-item",
                                        children: [Object(a.jsxs)("div", {
                                            className: "advisor-image",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/advisor/advisor5.jpg",
                                                alt: "image"
                                            }), Object(a.jsxs)("ul", {
                                                className: "social-link",
                                                children: [Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-facebook"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-twitter"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-instagram"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-linkedin"
                                                        })
                                                    })
                                                })]
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "advisor-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "#",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Jassica Hische"
                                                    })
                                                })
                                            }), Object(a.jsx)("span", {
                                                children: "Illustrator Expert"
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-advisor-item",
                                        children: [Object(a.jsxs)("div", {
                                            className: "advisor-image",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/advisor/advisor6.jpg",
                                                alt: "image"
                                            }), Object(a.jsxs)("ul", {
                                                className: "social-link",
                                                children: [Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-facebook"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-twitter"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-instagram"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-linkedin"
                                                        })
                                                    })
                                                })]
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "advisor-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "#",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Alister Cock"
                                                    })
                                                })
                                            }), Object(a.jsx)("span", {
                                                children: "QA Project Expert"
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-advisor-item",
                                        children: [Object(a.jsxs)("div", {
                                            className: "advisor-image",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/advisor/advisor7.jpg",
                                                alt: "image"
                                            }), Object(a.jsxs)("ul", {
                                                className: "social-link",
                                                children: [Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-facebook"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-twitter"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-instagram"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-linkedin"
                                                        })
                                                    })
                                                })]
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "advisor-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "#",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Lina Ninja"
                                                    })
                                                })
                                            }), Object(a.jsx)("span", {
                                                children: "QA Project Expert"
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-advisor-item",
                                        children: [Object(a.jsxs)("div", {
                                            className: "advisor-image",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/advisor/advisor8.jpg",
                                                alt: "image"
                                            }), Object(a.jsxs)("ul", {
                                                className: "social-link",
                                                children: [Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-facebook"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-twitter"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-instagram"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-linkedin"
                                                        })
                                                    })
                                                })]
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "advisor-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "#",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Chris Evans"
                                                    })
                                                })
                                            }), Object(a.jsx)("span", {
                                                children: "Python Expert"
                                            })]
                                        })]
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "col-lg-4 col-sm-6 col-md-6",
                                    children: Object(a.jsxs)("div", {
                                        className: "single-advisor-item",
                                        children: [Object(a.jsxs)("div", {
                                            className: "advisor-image",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/advisor/advisor9.jpg",
                                                alt: "image"
                                            }), Object(a.jsxs)("ul", {
                                                className: "social-link",
                                                children: [Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-facebook"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-twitter"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-instagram"
                                                        })
                                                    })
                                                }), Object(a.jsx)("li", {
                                                    children: Object(a.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(a.jsx)("i", {
                                                            className: "bx bxl-linkedin"
                                                        })
                                                    })
                                                })]
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "advisor-content",
                                            children: [Object(a.jsx)("h3", {
                                                children: Object(a.jsx)(j.a, {
                                                    href: "#",
                                                    children: Object(a.jsx)("a", {
                                                        children: "Scarlett Johansson"
                                                    })
                                                })
                                            }), Object(a.jsx)("span", {
                                                children: "Photoshop Expert"
                                            })]
                                        })]
                                    })
                                })]
                            })
                        })
                    }), Object(a.jsx)("div", {
                        className: "pb-100",
                        children: Object(a.jsx)(r.a, {})
                    })]
                })
            }
        },
        Ix5F: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                l = (c("q1tI"), c("YFqc")),
                t = c.n(l);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    l = e.homePageText,
                    i = e.activePageText;
                return Object(a.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(a.jsxs)("ul", {
                                children: [Object(a.jsx)("li", {
                                    children: Object(a.jsx)(t.a, {
                                        href: c,
                                        children: Object(a.jsx)("a", {
                                            children: l
                                        })
                                    })
                                }), Object(a.jsx)("li", {
                                    className: "active",
                                    children: i
                                })]
                            }), Object(a.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        cTJO: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                l = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var t = l(c("q1tI")),
                i = c("elyg"),
                r = c("nOHt"),
                n = c("vNVm"),
                j = {};

            function d(e, s, c, a) {
                if (e && (0, i.isLocalURL)(s)) {
                    e.prefetch(s, c, a).catch((function(e) {
                        0
                    }));
                    var l = a && "undefined" !== typeof a.locale ? a.locale : e && e.locale;
                    j[s + "%" + c + (l ? "%" + l : "")] = !0
                }
            }
            var b = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, r.useRouter)(),
                    l = c && c.pathname || "/",
                    b = t.default.useMemo((function() {
                        var s = (0, i.resolveHref)(l, e.href, !0),
                            c = a(s, 2),
                            t = c[0],
                            r = c[1];
                        return {
                            href: t,
                            as: e.as ? (0, i.resolveHref)(l, e.as) : r || t
                        }
                    }), [l, e.href, e.as]),
                    o = b.href,
                    x = b.as,
                    h = e.children,
                    m = e.replace,
                    O = e.shallow,
                    f = e.scroll,
                    u = e.locale;
                "string" === typeof h && (h = t.default.createElement("a", null, h));
                var v = t.Children.only(h),
                    g = v && "object" === typeof v && v.ref,
                    N = (0, n.useIntersection)({
                        rootMargin: "200px"
                    }),
                    p = a(N, 2),
                    k = p[0],
                    _ = p[1],
                    E = t.default.useCallback((function(e) {
                        k(e), g && ("function" === typeof g ? g(e) : "object" === typeof g && (g.current = e))
                    }), [g, k]);
                (0, t.useEffect)((function() {
                    var e = _ && s && (0, i.isLocalURL)(o),
                        a = "undefined" !== typeof u ? u : c && c.locale,
                        l = j[o + "%" + x + (a ? "%" + a : "")];
                    e && !l && d(c, o, x, {
                        locale: a
                    })
                }), [x, o, _, u, s, c]);
                var w = {
                    ref: E,
                    onClick: function(e) {
                        v.props && "function" === typeof v.props.onClick && v.props.onClick(e), e.defaultPrevented || function(e, s, c, a, l, t, r, n) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, i.isLocalURL)(c)) && (e.preventDefault(), null == r && (r = a.indexOf("#") < 0), s[l ? "replace" : "push"](c, a, {
                                shallow: t,
                                locale: n,
                                scroll: r
                            }).then((function(e) {
                                e && r && document.body.focus()
                            })))
                        }(e, c, o, x, m, O, f, u)
                    },
                    onMouseEnter: function(e) {
                        (0, i.isLocalURL)(o) && (v.props && "function" === typeof v.props.onMouseEnter && v.props.onMouseEnter(e), d(c, o, x, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === v.type && !("href" in v.props)) {
                    var y = "undefined" !== typeof u ? u : c && c.locale,
                        P = (0, i.getDomainLocale)(x, y, c && c.locales, c && c.domainLocales);
                    w.href = P || (0, i.addBasePath)((0, i.addLocale)(x, y, c && c.defaultLocale))
                }
                return t.default.cloneElement(v, w)
            };
            s.default = b
        },
        vNVm: function(e, s, c) {
            "use strict";
            var a = c("zoAU"),
                l = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !r,
                    l = (0, t.useRef)(),
                    j = (0, t.useState)(!1),
                    d = a(j, 2),
                    b = d[0],
                    o = d[1],
                    x = (0, t.useCallback)((function(e) {
                        l.current && (l.current(), l.current = void 0), c || b || e && e.tagName && (l.current = function(e, s, c) {
                            var a = function(e) {
                                    var s = e.rootMargin || "",
                                        c = n.get(s);
                                    if (c) return c;
                                    var a = new Map,
                                        l = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = a.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return n.set(s, c = {
                                        id: s,
                                        observer: l,
                                        elements: a
                                    }), c
                                }(c),
                                l = a.id,
                                t = a.observer,
                                i = a.elements;
                            return i.set(e, s), t.observe(e),
                                function() {
                                    i.delete(e), t.unobserve(e), 0 === i.size && (t.disconnect(), n.delete(l))
                                }
                        }(e, (function(e) {
                            return e && o(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, b]);
                return (0, t.useEffect)((function() {
                    r || b || (0, i.default)((function() {
                        return o(!0)
                    }))
                }), [b]), [x, b]
            };
            var t = c("q1tI"),
                i = l(c("0G5g")),
                r = "undefined" !== typeof IntersectionObserver;
            var n = new Map
        }
    },
    [
        ["8PCm", 1, 0, 2]
    ]
]);