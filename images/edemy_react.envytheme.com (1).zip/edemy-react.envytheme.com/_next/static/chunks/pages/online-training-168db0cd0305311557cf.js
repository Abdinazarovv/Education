_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [81], {
        uvjt: function(j, t, e) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/online-training", function() {
                return e("wX/O")
            }])
        },
        "wX/O": function(j, t, e) {
            "use strict";
            e.r(t);
            var n = e("nKUr"),
                s = e("q1tI"),
                c = e.n(s),
                a = e("iaE3"),
                b = e("13w0"),
                x = e("A3s4"),
                O = e("PepQ"),
                i = e("d/qs"),
                r = e("1YqJ"),
                u = e("JcBV"),
                w = e("Lrxs"),
                _ = e("F1Ic"),
                o = e("1NgU"),
                d = e("ur7V"),
                p = e("sex0");
            t.default = function() {
                return Object(n.jsxs)(c.a.Fragment, {
                    children: [Object(n.jsx)(a.a, {}), Object(n.jsx)(b.a, {}), Object(n.jsx)(x.a, {}), Object(n.jsx)(O.a, {}), Object(n.jsx)(i.a, {}), Object(n.jsx)(r.a, {}), Object(n.jsx)(u.a, {}), Object(n.jsx)(w.a, {}), Object(n.jsx)(_.a, {}), Object(n.jsx)(o.a, {}), Object(n.jsx)(d.a, {}), Object(n.jsx)(p.a, {})]
                })
            }
        }
    },
    [
        ["uvjt", 1, 0, 2, 4, 15]
    ]
]);