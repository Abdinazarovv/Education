_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [91], {
        SQmi: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/single-courses-2", function() {
                return c("STS7")
            }])
        },
        STS7: function(e, s, c) {
            "use strict";
            c.r(s);
            var t = c("nKUr"),
                a = c("q1tI"),
                i = c.n(a),
                n = c("YFqc"),
                l = c.n(n),
                r = function(e) {
                    var s = e.pageTitle,
                        c = e.homePageUrl,
                        a = e.homePageText,
                        i = e.innerPageUrl,
                        n = e.innerPageText,
                        r = e.activePageText;
                    return Object(t.jsxs)("div", {
                        className: "page-title-area",
                        children: [Object(t.jsx)("div", {
                            className: "container",
                            children: Object(t.jsxs)("div", {
                                className: "page-title-content",
                                children: [Object(t.jsxs)("ul", {
                                    children: [Object(t.jsx)("li", {
                                        children: Object(t.jsx)(l.a, {
                                            href: c,
                                            children: Object(t.jsx)("a", {
                                                children: a
                                            })
                                        })
                                    }), Object(t.jsx)("li", {
                                        children: Object(t.jsx)(l.a, {
                                            href: i,
                                            children: Object(t.jsx)("a", {
                                                children: n
                                            })
                                        })
                                    }), Object(t.jsx)("li", {
                                        className: "active",
                                        children: r
                                    })]
                                }), Object(t.jsx)("h2", {
                                    children: s
                                })]
                            })
                        }), Object(t.jsx)("div", {
                            className: "shape9",
                            children: Object(t.jsx)("img", {
                                src: "/images/shape8.svg",
                                alt: "image"
                            })
                        })]
                    })
                },
                j = c("rIL+"),
                d = function() {
                    return Object(t.jsx)("div", {
                        className: "courses-sidebar-sticky",
                        children: Object(t.jsxs)("div", {
                            className: "courses-sidebar-information",
                            children: [Object(t.jsxs)("ul", {
                                className: "info",
                                children: [Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-teacher"
                                            }), " Instructor"]
                                        }), "James Anderson"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-time"
                                            }), " Duration"]
                                        }), "7 weeks"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-distance-learning"
                                            }), " Lessons"]
                                        }), "25"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-web"
                                            }), " Enrolled"]
                                        }), "255 students"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-html"
                                            }), " Language"]
                                        }), "English"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-caption"
                                            }), " Video Subtitle"]
                                        }), "English"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-lock"
                                            }), " Access"]
                                        }), "Lifetime"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-quiz"
                                            }), " Quizzes"]
                                        }), "Yes"]
                                    })
                                }), Object(t.jsx)("li", {
                                    children: Object(t.jsxs)("div", {
                                        className: "d-flex justify-content-between align-items-center",
                                        children: [Object(t.jsxs)("span", {
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-certification"
                                            }), " Certificate"]
                                        }), "Yes"]
                                    })
                                })]
                            }), Object(t.jsx)("div", {
                                className: "btn-box",
                                children: Object(t.jsx)(l.a, {
                                    href: "#",
                                    children: Object(t.jsxs)("a", {
                                        className: "default-btn",
                                        children: [Object(t.jsx)("i", {
                                            className: "flaticon-shopping-cart"
                                        }), " Add to Cart ", Object(t.jsx)("span", {})]
                                    })
                                })
                            }), Object(t.jsx)("div", {
                                className: "courses-share",
                                children: Object(t.jsxs)("div", {
                                    className: "share-info",
                                    children: [Object(t.jsxs)("span", {
                                        children: ["Share This Course ", Object(t.jsx)("i", {
                                            className: "flaticon-share"
                                        })]
                                    }), Object(t.jsxs)("ul", {
                                        className: "social-link",
                                        children: [Object(t.jsx)("li", {
                                            children: Object(t.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(t.jsx)("i", {
                                                    className: "bx bxl-facebook"
                                                })
                                            })
                                        }), Object(t.jsx)("li", {
                                            children: Object(t.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(t.jsx)("i", {
                                                    className: "bx bxl-twitter"
                                                })
                                            })
                                        }), Object(t.jsx)("li", {
                                            children: Object(t.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(t.jsx)("i", {
                                                    className: "bx bxl-instagram"
                                                })
                                            })
                                        }), Object(t.jsx)("li", {
                                            children: Object(t.jsx)("a", {
                                                href: "#",
                                                className: "d-block",
                                                target: "_blank",
                                                children: Object(t.jsx)("i", {
                                                    className: "bx bxl-linkedin"
                                                })
                                            })
                                        })]
                                    })]
                                })
                            })]
                        })
                    })
                };
            s.default = function() {
                return Object(t.jsxs)(i.a.Fragment, {
                    children: [Object(t.jsx)(r, {
                        pageTitle: "Python for Finance: Investment Fundamentals & Data Analytics",
                        homePageUrl: "/",
                        homePageText: "Home",
                        innerPageUrl: "/courses-1",
                        innerPageText: "Courses",
                        activePageText: "Python for Finance: Investment Fundamentals & Data Analytics"
                    }), Object(t.jsx)("div", {
                        className: "courses-details-area ptb-100",
                        children: Object(t.jsxs)("div", {
                            className: "container",
                            children: [Object(t.jsx)("div", {
                                className: "courses-details-header",
                                children: Object(t.jsxs)("div", {
                                    className: "row align-items-center",
                                    children: [Object(t.jsxs)("div", {
                                        className: "col-lg-8 col-md-12",
                                        children: [Object(t.jsx)("div", {
                                            className: "courses-title",
                                            children: Object(t.jsx)("p", {
                                                children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy."
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "courses-meta",
                                            children: Object(t.jsxs)("ul", {
                                                children: [Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "bx bx-folder-open"
                                                    }), Object(t.jsx)("span", {
                                                        children: "Category"
                                                    }), Object(t.jsx)(l.a, {
                                                        href: "#",
                                                        children: Object(t.jsx)("a", {
                                                            children: "Photography"
                                                        })
                                                    })]
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "bx bx-group"
                                                    }), Object(t.jsx)("span", {
                                                        children: "Students Enrolled"
                                                    }), Object(t.jsx)(l.a, {
                                                        href: "#",
                                                        children: Object(t.jsx)("a", {
                                                            children: "541,214"
                                                        })
                                                    })]
                                                }), Object(t.jsxs)("li", {
                                                    children: [Object(t.jsx)("i", {
                                                        className: "bx bx-calendar"
                                                    }), Object(t.jsx)("span", {
                                                        children: "Last Updated"
                                                    }), Object(t.jsx)(l.a, {
                                                        href: "#",
                                                        children: Object(t.jsx)("a", {
                                                            children: "01/14/2020"
                                                        })
                                                    })]
                                                })]
                                            })
                                        })]
                                    }), Object(t.jsx)("div", {
                                        className: "col-lg-4 col-md-12",
                                        children: Object(t.jsxs)("div", {
                                            className: "courses-price",
                                            children: [Object(t.jsxs)("div", {
                                                className: "courses-review",
                                                children: [Object(t.jsxs)("div", {
                                                    className: "review-stars",
                                                    children: [Object(t.jsx)("i", {
                                                        className: "bx bxs-star"
                                                    }), Object(t.jsx)("i", {
                                                        className: "bx bxs-star"
                                                    }), Object(t.jsx)("i", {
                                                        className: "bx bxs-star"
                                                    }), Object(t.jsx)("i", {
                                                        className: "bx bxs-star"
                                                    }), Object(t.jsx)("i", {
                                                        className: "bx bxs-star"
                                                    })]
                                                }), Object(t.jsx)("span", {
                                                    className: "reviews-total d-inline-block",
                                                    children: "(3 reviews)"
                                                })]
                                            }), Object(t.jsx)("div", {
                                                className: "price",
                                                children: "$150"
                                            }), Object(t.jsx)(l.a, {
                                                href: "#",
                                                children: Object(t.jsxs)("a", {
                                                    className: "default-btn",
                                                    children: [Object(t.jsx)("i", {
                                                        className: "flaticon-user"
                                                    }), " Buy Course ", Object(t.jsx)("span", {})]
                                                })
                                            })]
                                        })
                                    })]
                                })
                            }), Object(t.jsxs)("div", {
                                className: "row",
                                children: [Object(t.jsxs)("div", {
                                    className: "col-lg-8 col-md-12",
                                    children: [Object(t.jsx)("div", {
                                        className: "courses-details-image-style-two text-center",
                                        children: Object(t.jsx)("img", {
                                            src: "/images/courses/courses2.jpg",
                                            alt: "image"
                                        })
                                    }), Object(t.jsxs)("div", {
                                        className: "courses-details-desc-style-two",
                                        children: [Object(t.jsx)("h3", {
                                            children: "Description"
                                        }), Object(t.jsx)("p", {
                                            children: Object(t.jsx)("strong", {
                                                children: "Hi! Welcome to Photography Crash Course for Photographer, the only course you need to become a BI Analyst."
                                            })
                                        }), Object(t.jsx)("p", {
                                            children: "Here are some more details of what you get with The Business Intelligence Analyst Course:"
                                        }), Object(t.jsxs)("ul", {
                                            className: "description-features-list",
                                            children: [Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("strong", {
                                                    children: "Introduction to Data and Data Science"
                                                }), " \u2013 Make sense of terms like business intelligence, traditional and big data, traditional statistical methods, machine learning, predictive analytics, supervised learning, unsupervised learning, reinforcement learning, and many more;"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("strong", {
                                                    children: "Database theory"
                                                }), " \u2013 Before you start using SQL, it is highly beneficial to learn about the underlying database theory and acquire an understanding of why databases are created and how they can help us manage data;"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("strong", {
                                                    children: "SQL"
                                                }), " \u2013 when you can work with SQL, it means you don\u2019t have to rely on others sending you data and executing queries for you. You can do that on your own. This allows you to be independent and dig deeper into the data to obtain the answers to questions that might improve the way your company does its business;"]
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: "Courses Video"
                                        }), Object(t.jsxs)("div", {
                                            className: "courses-curriculum",
                                            children: [Object(t.jsx)("h3", {
                                                children: "Python Introduction"
                                            }), Object(t.jsx)("ul", {
                                                children: Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "Python Introduction"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "questions",
                                                                children: "5 questions"
                                                            }), Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "01 Hour"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status",
                                                                children: "Preview"
                                                            })]
                                                        })]
                                                    })
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: "Stepping into the World of Python"
                                            }), Object(t.jsxs)("ul", {
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "NumPy Introduction"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "15 Min"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "NumPy Getting Started"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "30 Min"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "NumPy Creating Arrays"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "45 Min"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "NumPy Array Indexing"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "questions",
                                                                children: "4 questions"
                                                            }), Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "1 Hour"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "NumPy Array Slicing"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "1.5 Hour"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                })]
                                            }), Object(t.jsx)("h3", {
                                                children: "Python MySQL"
                                            }), Object(t.jsxs)("ul", {
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "Python MySQL"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "01 Hour"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "Python MySQL Create Database"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "questions",
                                                                children: "3 questions"
                                                            }), Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "1.1 Hour"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("a", {
                                                        href: "#",
                                                        className: "d-flex justify-content-between align-items-center",
                                                        children: [Object(t.jsx)("span", {
                                                            className: "courses-name",
                                                            children: "Python MySQL Create Table"
                                                        }), Object(t.jsxs)("div", {
                                                            className: "courses-meta",
                                                            children: [Object(t.jsx)("span", {
                                                                className: "duration",
                                                                children: "1.5 Hour"
                                                            }), Object(t.jsx)("span", {
                                                                className: "status locked",
                                                                children: Object(t.jsx)("i", {
                                                                    className: "flaticon-password"
                                                                })
                                                            })]
                                                        })]
                                                    })
                                                })]
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: "What you'll learn"
                                        }), Object(t.jsx)("div", {
                                            className: "why-you-learn",
                                            children: Object(t.jsxs)("ul", {
                                                children: [Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Become an expert in Statistics"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Boost your resume with skills"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Gather, organize, data"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Use data for improved"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Present information KPIs"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Perform quantitative"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Analyze current data"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Discover how to find trends"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Understand the fundamentals"]
                                                    })
                                                }), Object(t.jsx)("li", {
                                                    children: Object(t.jsxs)("span", {
                                                        children: [Object(t.jsx)("i", {
                                                            className: "flaticon-tick"
                                                        }), "Use SQL to create, design"]
                                                    })
                                                })]
                                            })
                                        }), Object(t.jsx)("h3", {
                                            children: "Requirements"
                                        }), Object(t.jsxs)("ul", {
                                            className: "requirements-list",
                                            children: [Object(t.jsx)("li", {
                                                children: "Contrary to popular belief, Lorem Ipsum is not simply random text."
                                            }), Object(t.jsx)("li", {
                                                children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry."
                                            }), Object(t.jsx)("li", {
                                                children: "The standard Lorem Ipsum passage, used since the 1500s."
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: "Who this course is for:"
                                        }), Object(t.jsxs)("ul", {
                                            className: "audience-list",
                                            children: [Object(t.jsx)("li", {
                                                children: "Beginners to programming and data science"
                                            }), Object(t.jsx)("li", {
                                                children: "Students eager to learn about job opportunities in the field of data science"
                                            }), Object(t.jsx)("li", {
                                                children: "Candidates willing to boost their resume by learning how to combine the knowledge of Statistics, SQL, and Tableau in a real-world working environment"
                                            }), Object(t.jsx)("li", {
                                                children: "People interested in a Business Intelligence Analyst career"
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: "Meet Your Instructors"
                                        }), Object(t.jsxs)("div", {
                                            className: "courses-author",
                                            children: [Object(t.jsx)("div", {
                                                className: "author-profile-header"
                                            }), Object(t.jsxs)("div", {
                                                className: "author-profile",
                                                children: [Object(t.jsxs)("div", {
                                                    className: "author-profile-title",
                                                    children: [Object(t.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        className: "shadow-sm rounded-circle",
                                                        alt: "image"
                                                    }), Object(t.jsx)("div", {
                                                        className: "author-profile-title-details",
                                                        children: Object(t.jsxs)("div", {
                                                            className: "author-profile-details",
                                                            children: [Object(t.jsx)("h4", {
                                                                children: "James Anderson"
                                                            }), Object(t.jsx)("span", {
                                                                className: "d-block",
                                                                children: "Photographer, Author, Teacher"
                                                            })]
                                                        })
                                                    })]
                                                }), Object(t.jsx)("p", {
                                                    children: "James Anderson is a celebrated photographer, author, and teacher who brings passion to everything he does."
                                                }), Object(t.jsx)("p", {
                                                    children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s."
                                                })]
                                            })]
                                        }), Object(t.jsxs)("div", {
                                            className: "courses-reviews",
                                            children: [Object(t.jsx)("h3", {
                                                children: "Course Rating"
                                            }), Object(t.jsxs)("div", {
                                                className: "rating",
                                                children: [Object(t.jsx)("span", {
                                                    className: "bx bxs-star checked"
                                                }), Object(t.jsx)("span", {
                                                    className: "bx bxs-star checked"
                                                }), Object(t.jsx)("span", {
                                                    className: "bx bxs-star checked"
                                                }), Object(t.jsx)("span", {
                                                    className: "bx bxs-star checked"
                                                }), Object(t.jsx)("span", {
                                                    className: "bx bxs-star"
                                                })]
                                            }), Object(t.jsx)("div", {
                                                className: "rating-count",
                                                children: Object(t.jsx)("span", {
                                                    children: "4.1 average based on 4 reviews."
                                                })
                                            }), Object(t.jsxs)("div", {
                                                className: "row",
                                                children: [Object(t.jsx)("div", {
                                                    className: "side",
                                                    children: Object(t.jsx)("div", {
                                                        children: "5 star"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "middle",
                                                    children: Object(t.jsx)("div", {
                                                        className: "bar-container",
                                                        children: Object(t.jsx)("div", {
                                                            className: "bar-5"
                                                        })
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side right",
                                                    children: Object(t.jsx)("div", {
                                                        children: "02"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side",
                                                    children: Object(t.jsx)("div", {
                                                        children: "4 star"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "middle",
                                                    children: Object(t.jsx)("div", {
                                                        className: "bar-container",
                                                        children: Object(t.jsx)("div", {
                                                            className: "bar-4"
                                                        })
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side right",
                                                    children: Object(t.jsx)("div", {
                                                        children: "03"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side",
                                                    children: Object(t.jsx)("div", {
                                                        children: "3 star"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "middle",
                                                    children: Object(t.jsx)("div", {
                                                        className: "bar-container",
                                                        children: Object(t.jsx)("div", {
                                                            className: "bar-3"
                                                        })
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side right",
                                                    children: Object(t.jsx)("div", {
                                                        children: "04"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side",
                                                    children: Object(t.jsx)("div", {
                                                        children: "2 star"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "middle",
                                                    children: Object(t.jsx)("div", {
                                                        className: "bar-container",
                                                        children: Object(t.jsx)("div", {
                                                            className: "bar-2"
                                                        })
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side right",
                                                    children: Object(t.jsx)("div", {
                                                        children: "05"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side",
                                                    children: Object(t.jsx)("div", {
                                                        children: "1 star"
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "middle",
                                                    children: Object(t.jsx)("div", {
                                                        className: "bar-container",
                                                        children: Object(t.jsx)("div", {
                                                            className: "bar-1"
                                                        })
                                                    })
                                                }), Object(t.jsx)("div", {
                                                    className: "side right",
                                                    children: Object(t.jsx)("div", {
                                                        children: "00"
                                                    })
                                                })]
                                            })]
                                        }), Object(t.jsxs)("div", {
                                            className: "courses-review-comments",
                                            children: [Object(t.jsx)("h3", {
                                                children: "3 Reviews"
                                            }), Object(t.jsxs)("div", {
                                                className: "user-review",
                                                children: [Object(t.jsx)("img", {
                                                    src: "/images/user1.jpg",
                                                    alt: "image"
                                                }), Object(t.jsxs)("div", {
                                                    className: "review-rating",
                                                    children: [Object(t.jsxs)("div", {
                                                        className: "review-stars",
                                                        children: [Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        })]
                                                    }), Object(t.jsx)("span", {
                                                        className: "d-inline-block",
                                                        children: "James Anderson"
                                                    })]
                                                }), Object(t.jsx)("span", {
                                                    className: "d-block sub-comment",
                                                    children: "Excellent"
                                                }), Object(t.jsx)("p", {
                                                    children: "Very well built theme, couldn't be happier with it. Can't wait for future updates to see what else they add in."
                                                })]
                                            }), Object(t.jsxs)("div", {
                                                className: "user-review",
                                                children: [Object(t.jsx)("img", {
                                                    src: "/images/user2.jpg",
                                                    alt: "image"
                                                }), Object(t.jsxs)("div", {
                                                    className: "review-rating",
                                                    children: [Object(t.jsxs)("div", {
                                                        className: "review-stars",
                                                        children: [Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(t.jsx)("span", {
                                                        className: "d-inline-block",
                                                        children: "Sarah Taylor"
                                                    })]
                                                }), Object(t.jsx)("span", {
                                                    className: "d-block sub-comment",
                                                    children: "Video Quality!"
                                                }), Object(t.jsx)("p", {
                                                    children: "Was really easy to implement and they quickly answer my additional questions!"
                                                })]
                                            }), Object(t.jsxs)("div", {
                                                className: "user-review",
                                                children: [Object(t.jsx)("img", {
                                                    src: "/images/user3.jpg",
                                                    alt: "image"
                                                }), Object(t.jsxs)("div", {
                                                    className: "review-rating",
                                                    children: [Object(t.jsxs)("div", {
                                                        className: "review-stars",
                                                        children: [Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        })]
                                                    }), Object(t.jsx)("span", {
                                                        className: "d-inline-block",
                                                        children: "David Warner"
                                                    })]
                                                }), Object(t.jsx)("span", {
                                                    className: "d-block sub-comment",
                                                    children: "Perfect Coding!"
                                                }), Object(t.jsx)("p", {
                                                    children: "Stunning design, very dedicated crew who welcome new ideas suggested by customers, nice support."
                                                })]
                                            }), Object(t.jsxs)("div", {
                                                className: "user-review",
                                                children: [Object(t.jsx)("img", {
                                                    src: "/images/user4.jpg",
                                                    alt: "image"
                                                }), Object(t.jsxs)("div", {
                                                    className: "review-rating",
                                                    children: [Object(t.jsxs)("div", {
                                                        className: "review-stars",
                                                        children: [Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star checked"
                                                        }), Object(t.jsx)("i", {
                                                            className: "bx bxs-star"
                                                        })]
                                                    }), Object(t.jsx)("span", {
                                                        className: "d-inline-block",
                                                        children: "King Kong"
                                                    })]
                                                }), Object(t.jsx)("span", {
                                                    className: "d-block sub-comment",
                                                    children: "Perfect Video!"
                                                }), Object(t.jsx)("p", {
                                                    children: "Stunning design, very dedicated crew who welcome new ideas suggested by customers, nice support."
                                                })]
                                            })]
                                        })]
                                    })]
                                }), Object(t.jsx)("div", {
                                    className: "col-lg-4 col-md-12",
                                    children: Object(t.jsx)(d, {})
                                })]
                            })]
                        })
                    }), Object(t.jsx)(j.a, {})]
                })
            }
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        cTJO: function(e, s, c) {
            "use strict";
            var t = c("zoAU"),
                a = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var i = a(c("q1tI")),
                n = c("elyg"),
                l = c("nOHt"),
                r = c("vNVm"),
                j = {};

            function d(e, s, c, t) {
                if (e && (0, n.isLocalURL)(s)) {
                    e.prefetch(s, c, t).catch((function(e) {
                        0
                    }));
                    var a = t && "undefined" !== typeof t.locale ? t.locale : e && e.locale;
                    j[s + "%" + c + (a ? "%" + a : "")] = !0
                }
            }
            var o = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, l.useRouter)(),
                    a = c && c.pathname || "/",
                    o = i.default.useMemo((function() {
                        var s = (0, n.resolveHref)(a, e.href, !0),
                            c = t(s, 2),
                            i = c[0],
                            l = c[1];
                        return {
                            href: i,
                            as: e.as ? (0, n.resolveHref)(a, e.as) : l || i
                        }
                    }), [a, e.href, e.as]),
                    b = o.href,
                    x = o.as,
                    h = e.children,
                    m = e.replace,
                    O = e.shallow,
                    u = e.scroll,
                    N = e.locale;
                "string" === typeof h && (h = i.default.createElement("a", null, h));
                var f = i.Children.only(h),
                    p = f && "object" === typeof f && f.ref,
                    g = (0, r.useIntersection)({
                        rootMargin: "200px"
                    }),
                    v = t(g, 2),
                    y = v[0],
                    w = v[1],
                    k = i.default.useCallback((function(e) {
                        y(e), p && ("function" === typeof p ? p(e) : "object" === typeof p && (p.current = e))
                    }), [p, y]);
                (0, i.useEffect)((function() {
                    var e = w && s && (0, n.isLocalURL)(b),
                        t = "undefined" !== typeof N ? N : c && c.locale,
                        a = j[b + "%" + x + (t ? "%" + t : "")];
                    e && !a && d(c, b, x, {
                        locale: t
                    })
                }), [x, b, w, N, s, c]);
                var L = {
                    ref: k,
                    onClick: function(e) {
                        f.props && "function" === typeof f.props.onClick && f.props.onClick(e), e.defaultPrevented || function(e, s, c, t, a, i, l, r) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, n.isLocalURL)(c)) && (e.preventDefault(), null == l && (l = t.indexOf("#") < 0), s[a ? "replace" : "push"](c, t, {
                                shallow: i,
                                locale: r,
                                scroll: l
                            }).then((function(e) {
                                e && l && document.body.focus()
                            })))
                        }(e, c, b, x, m, O, u, N)
                    },
                    onMouseEnter: function(e) {
                        (0, n.isLocalURL)(b) && (f.props && "function" === typeof f.props.onMouseEnter && f.props.onMouseEnter(e), d(c, b, x, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === f.type && !("href" in f.props)) {
                    var P = "undefined" !== typeof N ? N : c && c.locale,
                        S = (0, n.getDomainLocale)(x, P, c && c.locales, c && c.domainLocales);
                    L.href = S || (0, n.addBasePath)((0, n.addLocale)(x, P, c && c.defaultLocale))
                }
                return i.default.cloneElement(f, L)
            };
            s.default = o
        },
        "rIL+": function(e, s, c) {
            "use strict";
            var t = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                i = c.n(a);
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "courses-area bg-f8f9f8 pt-100 pb-70",
                    children: Object(t.jsxs)("div", {
                        className: "container",
                        children: [Object(t.jsx)("div", {
                            className: "section-title",
                            children: Object(t.jsx)("h2", {
                                children: "More Courses You Might Like"
                            })
                        }), Object(t.jsxs)("div", {
                            className: "row",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(t.jsx)(i.a, {
                                            href: "/single-courses-1",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/courses/courses1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(t.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "price shadow",
                                            children: "$39"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(t.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(t.jsx)("img", {
                                                src: "/images/user1.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(t.jsx)("span", {
                                                children: "Alex Morgan"
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(i.a, {
                                                href: "/single-courses-1",
                                                children: Object(t.jsx)("a", {
                                                    children: "The Data Science Course 2020: Complete Data Science Bootcamp"
                                                })
                                            })
                                        }), Object(t.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(t.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 15 Lessons"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 145 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(t.jsx)(i.a, {
                                            href: "/single-courses-1",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/courses/courses2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(t.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "price shadow",
                                            children: "$49"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(t.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(t.jsx)("img", {
                                                src: "/images/user2.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(t.jsx)("span", {
                                                children: "Sarah Taylor"
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(i.a, {
                                                href: "/single-courses-1",
                                                children: Object(t.jsx)("a", {
                                                    children: "Java Programming MasterclassName for Software Developers"
                                                })
                                            })
                                        }), Object(t.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(t.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 100 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(t.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(t.jsx)(i.a, {
                                            href: "/single-courses-1",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/courses/courses3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(t.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "price shadow",
                                            children: "$59"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(t.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(t.jsx)("img", {
                                                src: "/images/user3.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(t.jsx)("span", {
                                                children: "David Warner"
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(i.a, {
                                                href: "/single-courses-1",
                                                children: Object(t.jsx)("a", {
                                                    children: "Deep Learning A-Z\u2122: Hands-On Artificial Neural Networks"
                                                })
                                            })
                                        }), Object(t.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(t.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 150 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        vNVm: function(e, s, c) {
            "use strict";
            var t = c("zoAU"),
                a = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !l,
                    a = (0, i.useRef)(),
                    j = (0, i.useState)(!1),
                    d = t(j, 2),
                    o = d[0],
                    b = d[1],
                    x = (0, i.useCallback)((function(e) {
                        a.current && (a.current(), a.current = void 0), c || o || e && e.tagName && (a.current = function(e, s, c) {
                            var t = function(e) {
                                    var s = e.rootMargin || "",
                                        c = r.get(s);
                                    if (c) return c;
                                    var t = new Map,
                                        a = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = t.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return r.set(s, c = {
                                        id: s,
                                        observer: a,
                                        elements: t
                                    }), c
                                }(c),
                                a = t.id,
                                i = t.observer,
                                n = t.elements;
                            return n.set(e, s), i.observe(e),
                                function() {
                                    n.delete(e), i.unobserve(e), 0 === n.size && (i.disconnect(), r.delete(a))
                                }
                        }(e, (function(e) {
                            return e && b(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, o]);
                return (0, i.useEffect)((function() {
                    l || o || (0, n.default)((function() {
                        return b(!0)
                    }))
                }), [o]), [x, o]
            };
            var i = c("q1tI"),
                n = a(c("0G5g")),
                l = "undefined" !== typeof IntersectionObserver;
            var r = new Map
        }
    },
    [
        ["SQmi", 1, 0, 2]
    ]
]);