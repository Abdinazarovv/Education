_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [60], {
        "P+Pa": function(j, t, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/distance-learning", function() {
                return n("lCVI")
            }])
        },
        lCVI: function(j, t, n) {
            "use strict";
            n.r(t);
            var a = n("nKUr"),
                c = n("q1tI"),
                e = n.n(c),
                s = n("AjzA"),
                b = n("TqIQ"),
                i = n("Twcx"),
                w = n("Bmwz"),
                x = n("+tXn"),
                O = n("MzSq"),
                r = n("ivM6"),
                _ = n("6Umg"),
                u = n("w+aE"),
                o = n("OTF4"),
                d = n("7iwr"),
                p = n("ur7V");
            t.default = function() {
                return Object(a.jsxs)(e.a.Fragment, {
                    children: [Object(a.jsx)(s.a, {}), Object(a.jsx)(b.a, {}), Object(a.jsx)(i.a, {}), Object(a.jsx)(w.a, {}), Object(a.jsx)(x.a, {}), Object(a.jsx)(O.a, {}), Object(a.jsx)(r.a, {}), Object(a.jsx)(_.a, {}), Object(a.jsx)(u.a, {}), Object(a.jsx)(o.a, {}), Object(a.jsx)(d.a, {}), Object(a.jsx)(p.a, {})]
                })
            }
        }
    },
    [
        ["P+Pa", 1, 0, 2, 4, 16]
    ]
]);