_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [85], {
        Ix5F: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                t = (c("q1tI"), c("YFqc")),
                a = c.n(t);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    t = e.homePageText,
                    l = e.activePageText;
                return Object(i.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(i.jsxs)("ul", {
                                children: [Object(i.jsx)("li", {
                                    children: Object(i.jsx)(a.a, {
                                        href: c,
                                        children: Object(i.jsx)("a", {
                                            children: t
                                        })
                                    })
                                }), Object(i.jsx)("li", {
                                    className: "active",
                                    children: l
                                })]
                            }), Object(i.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape9",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        "W+IF": function(e, s, c) {
            "use strict";
            c.r(s);
            var i = c("nKUr"),
                t = c("q1tI"),
                a = c.n(t),
                l = c("Ix5F"),
                r = c("YFqc"),
                n = c.n(r),
                j = function() {
                    return Object(i.jsxs)("div", {
                        className: "profile-courses pb-70",
                        children: [Object(i.jsx)("h3", {
                            className: "title",
                            children: "Courses"
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$39"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user1.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Alex Morgan"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "The Data Science Course 2020: Complete Data Science Bootcamp"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 15 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 145 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$49"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user2.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Sarah Taylor"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Java Programming MasterclassName for Software Developers"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 100 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$59"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user3.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "David Warner"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Deep Learning A-Z\u2122: Hands-On Artificial Neural Networks"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 150 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses4.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$39"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user6.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Alex Morgan"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Python for Finance: Investment Fundamentals & Data Analytics"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 15 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 145 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses5.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$49"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user5.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Sarah Taylor"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Machine Learning A-Z\u2122: Hands-On Python & R In Data Science"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 100 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses6.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$99"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user4.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "James Anderson"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "R Programming A-Z\u2122: R For Data Science With Real Exercises!"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 44 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 440 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses10.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$39"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user1.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Alex Morgan"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Deep Learning The Numpy Stack in Python"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 15 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 145 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses11.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$49"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user2.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Sarah Taylor"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Statistics for Data Science and Business Analysis"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 100 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses12.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$59"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user3.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "David Warner"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Microsoft Excel - Excel from Beginner to Advanced"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 150 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses13.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$39"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user6.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Alex Morgan"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Python Django Web Development: To-Do App"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 15 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 145 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses14.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$49"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user5.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Sarah Taylor"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Oracle SQL Developer : Essentials, Tips and Tricks"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 100 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(n.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/courses15.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price shadow",
                                            children: "$99"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user4.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "James Anderson"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Learning A-Z\u2122: Hands-On Python In Data Science"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, constetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(i.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 44 Lessons"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 440 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                },
                d = function() {
                    return Object(i.jsxs)("div", {
                        className: "profile-quizzes pb-70",
                        children: [Object(i.jsx)("h3", {
                            className: "title",
                            children: "Quizzes"
                        }), Object(i.jsx)("div", {
                            className: "table-responsive",
                            children: Object(i.jsxs)("table", {
                                className: "table table-striped",
                                children: [Object(i.jsx)("thead", {
                                    children: Object(i.jsxs)("tr", {
                                        children: [Object(i.jsx)("th", {
                                            children: "Course"
                                        }), Object(i.jsx)("th", {
                                            children: "Quiz"
                                        }), Object(i.jsx)("th", {
                                            children: "Date"
                                        }), Object(i.jsx)("th", {
                                            children: "Progress"
                                        }), Object(i.jsx)("th", {
                                            children: "Interval"
                                        })]
                                    })
                                }), Object(i.jsxs)("tbody", {
                                    children: [Object(i.jsxs)("tr", {
                                        children: [Object(i.jsx)("td", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "Introduction to Python for Beginners"
                                                })
                                            })
                                        }), Object(i.jsx)("td", {
                                            children: "Lesson 1 Term Test"
                                        }), Object(i.jsx)("td", {
                                            children: "May 20, 2020"
                                        }), Object(i.jsxs)("td", {
                                            children: ["25% ", Object(i.jsx)("span", {
                                                className: "progress",
                                                children: "In Progress"
                                            })]
                                        }), Object(i.jsx)("td", {
                                            children: "15:30"
                                        })]
                                    }), Object(i.jsxs)("tr", {
                                        children: [Object(i.jsx)("td", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "Python for Data Science and Machine Learning Bootcamp"
                                                })
                                            })
                                        }), Object(i.jsx)("td", {
                                            children: "Lesson 2 Term Test"
                                        }), Object(i.jsx)("td", {
                                            children: "May 21, 2020"
                                        }), Object(i.jsxs)("td", {
                                            children: ["0% ", Object(i.jsx)("span", {
                                                className: "progress pending",
                                                children: "Pending"
                                            })]
                                        }), Object(i.jsx)("td", {
                                            children: "20:20"
                                        })]
                                    }), Object(i.jsxs)("tr", {
                                        children: [Object(i.jsx)("td", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "The Modern Python 3 Bootcamp"
                                                })
                                            })
                                        }), Object(i.jsx)("td", {
                                            children: "Lesson 5 Term Test"
                                        }), Object(i.jsx)("td", {
                                            children: "May 22, 2020"
                                        }), Object(i.jsxs)("td", {
                                            children: ["100% ", Object(i.jsx)("span", {
                                                className: "progress completed",
                                                children: "Completed"
                                            })]
                                        }), Object(i.jsx)("td", {
                                            children: "10:10"
                                        })]
                                    }), Object(i.jsxs)("tr", {
                                        children: [Object(i.jsx)("td", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "REST APIs with Flask and Python"
                                                })
                                            })
                                        }), Object(i.jsx)("td", {
                                            children: "Lesson 1 Term Test"
                                        }), Object(i.jsx)("td", {
                                            children: "May 23, 2020"
                                        }), Object(i.jsxs)("td", {
                                            children: ["30% ", Object(i.jsx)("span", {
                                                className: "progress",
                                                children: "In Progress"
                                            })]
                                        }), Object(i.jsx)("td", {
                                            children: "15:30"
                                        })]
                                    }), Object(i.jsxs)("tr", {
                                        children: [Object(i.jsx)("td", {
                                            children: Object(i.jsx)(n.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "Reinforcement Learning in Python"
                                                })
                                            })
                                        }), Object(i.jsx)("td", {
                                            children: "Lesson 1 Term Test"
                                        }), Object(i.jsx)("td", {
                                            children: "May 24, 2020"
                                        }), Object(i.jsxs)("td", {
                                            children: ["35% ", Object(i.jsx)("span", {
                                                className: "progress failed",
                                                children: "Failed"
                                            })]
                                        }), Object(i.jsx)("td", {
                                            children: "15:30"
                                        })]
                                    })]
                                })]
                            })
                        })]
                    })
                };
            s.default = function() {
                return Object(i.jsxs)(a.a.Fragment, {
                    children: [Object(i.jsx)(l.a, {
                        pageTitle: "Profile",
                        homePageUrl: "/",
                        homePageText: "Home",
                        activePageText: "Profile"
                    }), Object(i.jsx)("div", {
                        className: "profile-area",
                        children: Object(i.jsxs)("div", {
                            className: "container",
                            children: [Object(i.jsx)("div", {
                                className: "profile-box ptb-100",
                                children: Object(i.jsxs)("div", {
                                    className: "row align-items-center",
                                    children: [Object(i.jsx)("div", {
                                        className: "col-lg-4 col-md-4",
                                        children: Object(i.jsx)("div", {
                                            className: "image",
                                            children: Object(i.jsx)("img", {
                                                src: "/images/advisor/advisor10.jpg",
                                                alt: "image"
                                            })
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "col-lg-8 col-md-8",
                                        children: Object(i.jsxs)("div", {
                                            className: "content",
                                            children: [Object(i.jsx)("h3", {
                                                children: "Sarah Taylor"
                                            }), Object(i.jsx)("span", {
                                                className: "sub-title",
                                                children: "Agile Project Expert"
                                            }), Object(i.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                            }), Object(i.jsxs)("ul", {
                                                className: "info",
                                                children: [Object(i.jsxs)("li", {
                                                    children: [Object(i.jsx)("span", {
                                                        children: "Phone Number:"
                                                    }), " ", Object(i.jsx)("a", {
                                                        href: "tel:+44254588689",
                                                        children: "(+44) -2545 - 88689"
                                                    })]
                                                }), Object(i.jsxs)("li", {
                                                    children: [Object(i.jsx)("span", {
                                                        children: "Email:"
                                                    }), " ", Object(i.jsx)("a", {
                                                        href: "mailto:hello@sarahtaylor.com",
                                                        children: "hello@sarahtaylor.com"
                                                    })]
                                                })]
                                            }), Object(i.jsxs)("ul", {
                                                className: "social-link",
                                                children: [Object(i.jsx)("li", {
                                                    children: Object(i.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(i.jsx)("i", {
                                                            className: "bx bxl-facebook"
                                                        })
                                                    })
                                                }), Object(i.jsx)("li", {
                                                    children: Object(i.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(i.jsx)("i", {
                                                            className: "bx bxl-twitter"
                                                        })
                                                    })
                                                }), Object(i.jsx)("li", {
                                                    children: Object(i.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(i.jsx)("i", {
                                                            className: "bx bxl-instagram"
                                                        })
                                                    })
                                                }), Object(i.jsx)("li", {
                                                    children: Object(i.jsx)("a", {
                                                        href: "#",
                                                        className: "d-block",
                                                        target: "_blank",
                                                        children: Object(i.jsx)("i", {
                                                            className: "bx bxl-linkedin"
                                                        })
                                                    })
                                                })]
                                            })]
                                        })
                                    })]
                                })
                            }), Object(i.jsx)(j, {}), Object(i.jsx)(d, {})]
                        })
                    })]
                })
            }
        },
        YFqc: function(e, s, c) {
            e.exports = c("cTJO")
        },
        cTJO: function(e, s, c) {
            "use strict";
            var i = c("zoAU"),
                t = c("7KCV");
            s.__esModule = !0, s.default = void 0;
            var a = t(c("q1tI")),
                l = c("elyg"),
                r = c("nOHt"),
                n = c("vNVm"),
                j = {};

            function d(e, s, c, i) {
                if (e && (0, l.isLocalURL)(s)) {
                    e.prefetch(s, c, i).catch((function(e) {
                        0
                    }));
                    var t = i && "undefined" !== typeof i.locale ? i.locale : e && e.locale;
                    j[s + "%" + c + (t ? "%" + t : "")] = !0
                }
            }
            var o = function(e) {
                var s = !1 !== e.prefetch,
                    c = (0, r.useRouter)(),
                    t = c && c.pathname || "/",
                    o = a.default.useMemo((function() {
                        var s = (0, l.resolveHref)(t, e.href, !0),
                            c = i(s, 2),
                            a = c[0],
                            r = c[1];
                        return {
                            href: a,
                            as: e.as ? (0, l.resolveHref)(t, e.as) : r || a
                        }
                    }), [t, e.href, e.as]),
                    b = o.href,
                    h = o.as,
                    m = e.children,
                    x = e.replace,
                    O = e.shallow,
                    u = e.scroll,
                    g = e.locale;
                "string" === typeof m && (m = a.default.createElement("a", null, m));
                var f = a.Children.only(m),
                    p = f && "object" === typeof f && f.ref,
                    N = (0, n.useIntersection)({
                        rootMargin: "200px"
                    }),
                    v = i(N, 2),
                    y = v[0],
                    L = v[1],
                    w = a.default.useCallback((function(e) {
                        y(e), p && ("function" === typeof p ? p(e) : "object" === typeof p && (p.current = e))
                    }), [p, y]);
                (0, a.useEffect)((function() {
                    var e = L && s && (0, l.isLocalURL)(b),
                        i = "undefined" !== typeof g ? g : c && c.locale,
                        t = j[b + "%" + h + (i ? "%" + i : "")];
                    e && !t && d(c, b, h, {
                        locale: i
                    })
                }), [h, b, L, g, s, c]);
                var k = {
                    ref: w,
                    onClick: function(e) {
                        f.props && "function" === typeof f.props.onClick && f.props.onClick(e), e.defaultPrevented || function(e, s, c, i, t, a, r, n) {
                            ("A" !== e.currentTarget.nodeName || ! function(e) {
                                var s = e.currentTarget.target;
                                return s && "_self" !== s || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                            }(e) && (0, l.isLocalURL)(c)) && (e.preventDefault(), null == r && (r = i.indexOf("#") < 0), s[t ? "replace" : "push"](c, i, {
                                shallow: a,
                                locale: n,
                                scroll: r
                            }).then((function(e) {
                                e && r && document.body.focus()
                            })))
                        }(e, c, b, h, x, O, u, g)
                    },
                    onMouseEnter: function(e) {
                        (0, l.isLocalURL)(b) && (f.props && "function" === typeof f.props.onMouseEnter && f.props.onMouseEnter(e), d(c, b, h, {
                            priority: !0
                        }))
                    }
                };
                if (e.passHref || "a" === f.type && !("href" in f.props)) {
                    var T = "undefined" !== typeof g ? g : c && c.locale,
                        P = (0, l.getDomainLocale)(h, T, c && c.locales, c && c.domainLocales);
                    k.href = P || (0, l.addBasePath)((0, l.addLocale)(h, T, c && c.defaultLocale))
                }
                return a.default.cloneElement(f, k)
            };
            s.default = o
        },
        u1GD: function(e, s, c) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/profile", function() {
                return c("W+IF")
            }])
        },
        vNVm: function(e, s, c) {
            "use strict";
            var i = c("zoAU"),
                t = c("AroE");
            s.__esModule = !0, s.useIntersection = function(e) {
                var s = e.rootMargin,
                    c = e.disabled || !r,
                    t = (0, a.useRef)(),
                    j = (0, a.useState)(!1),
                    d = i(j, 2),
                    o = d[0],
                    b = d[1],
                    h = (0, a.useCallback)((function(e) {
                        t.current && (t.current(), t.current = void 0), c || o || e && e.tagName && (t.current = function(e, s, c) {
                            var i = function(e) {
                                    var s = e.rootMargin || "",
                                        c = n.get(s);
                                    if (c) return c;
                                    var i = new Map,
                                        t = new IntersectionObserver((function(e) {
                                            e.forEach((function(e) {
                                                var s = i.get(e.target),
                                                    c = e.isIntersecting || e.intersectionRatio > 0;
                                                s && c && s(c)
                                            }))
                                        }), e);
                                    return n.set(s, c = {
                                        id: s,
                                        observer: t,
                                        elements: i
                                    }), c
                                }(c),
                                t = i.id,
                                a = i.observer,
                                l = i.elements;
                            return l.set(e, s), a.observe(e),
                                function() {
                                    l.delete(e), a.unobserve(e), 0 === l.size && (a.disconnect(), n.delete(t))
                                }
                        }(e, (function(e) {
                            return e && b(e)
                        }), {
                            rootMargin: s
                        }))
                    }), [c, s, o]);
                return (0, a.useEffect)((function() {
                    r || o || (0, l.default)((function() {
                        return b(!0)
                    }))
                }), [o]), [h, o]
            };
            var a = c("q1tI"),
                l = t(c("0G5g")),
                r = "undefined" !== typeof IntersectionObserver;
            var n = new Map
        }
    },
    [
        ["u1GD", 1, 0, 2]
    ]
]);