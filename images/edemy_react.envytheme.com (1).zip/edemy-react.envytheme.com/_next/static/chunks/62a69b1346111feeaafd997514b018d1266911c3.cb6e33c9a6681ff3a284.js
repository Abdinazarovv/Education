(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [19], {
        "3Q6v": function(e, s, c) {
            "use strict";
            var i = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "subscribe-area-two",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "subscribe-image",
                                    children: Object(i.jsx)("img", {
                                        src: "/images/subscribe-img2.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "subscribe-content",
                                    children: [Object(i.jsx)("span", {
                                        className: "sub-title",
                                        children: "Go At Your Own Pace"
                                    }), Object(i.jsx)("h2", {
                                        className: "playfair-display-font",
                                        children: "Subscribe To Our Newsletter"
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(i.jsxs)("form", {
                                        className: "newsletter-form",
                                        children: [Object(i.jsx)("input", {
                                            type: "text",
                                            className: "input-newsletter",
                                            placeholder: "Enter your email address",
                                            name: "EMAIL",
                                            required: !0
                                        }), Object(i.jsxs)("button", {
                                            type: "submit",
                                            className: "default-btn",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), "Subscribe Now", Object(i.jsx)("span", {})]
                                        })]
                                    })]
                                })
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape4",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape13",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape12.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        "5j2E": function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "experience-area ptb-100",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "experience-content",
                                    children: [Object(i.jsx)("div", {
                                        className: "shape",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/fruits.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsx)("span", {
                                        className: "sub-title",
                                        children: "Join our World Famous Yoga Teacher Training Course... Online!"
                                    }), Object(i.jsx)("h2", {
                                        className: "playfair-display-font",
                                        children: "This Isn't a Diet, It's a Lifestyle"
                                    }), Object(i.jsx)("p", {
                                        children: "eDemy training programs can bring you a super exciting experience of learning through online! You never face any negative experience while enjoying your classNamees virtually by sitting in your comfort zone. Our flexible learning initiatives will help you to learn better and quicker than the traditional ways of learning skills."
                                    }), Object(i.jsxs)("ul", {
                                        className: "features-list",
                                        children: [Object(i.jsxs)("li", {
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-check"
                                            }), " Vegetable Intake"]
                                        }), Object(i.jsxs)("li", {
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-check"
                                            }), " An Apple a Day"]
                                        }), Object(i.jsxs)("li", {
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-check"
                                            }), " Good Nutrition"]
                                        }), Object(i.jsxs)("li", {
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-check"
                                            }), " Our Principles"]
                                        }), Object(i.jsxs)("li", {
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-check"
                                            }), " Healthy Life"]
                                        }), Object(i.jsxs)("li", {
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-check"
                                            }), " Personalized Plan"]
                                        })]
                                    }), Object(i.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Get Started Now ", Object(i.jsx)("span", {})]
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "experience-img",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/experience-img2.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("span", {
                                        className: "title",
                                        children: [Object(i.jsx)("span", {
                                            children: "15"
                                        }), " Years of Experience"]
                                    })]
                                })
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "experience-shape1",
                        children: Object(i.jsx)("img", {
                            src: "/images/experience-shape1.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "experience-shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/experience-shape2.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        "9s6I": function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "lifestyle-area bg-f6f7fb pt-100 pb-70",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Inspring you to live a healthier lifestyle"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-lifestyle-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-diet"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Nutrition Strategies"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(i.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-lifestyle-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-vitamin-c"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Personal Program"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(i.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-lifestyle-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-heart-rate-monitor"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Find Your Balance"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(i.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now"
                                        })
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        Me7F: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "program-area ptb-100",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "program-section-title",
                                    children: [Object(i.jsx)("h2", {
                                        className: "playfair-display-font",
                                        children: "Choose Your Program Bellow to See How We Can Help"
                                    }), Object(i.jsx)("p", {
                                        children: "eDemy training programs can bring you a super exciting experience of learning through online! You never face any negative experience while enjoying your classNamees virtually by sitting in your comfort zone. Our flexible learning initiatives will help you to learn better and quicker than the traditional ways of learning skills."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Get Started Now ", Object(i.jsx)("span", {})]
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "program-list",
                                    children: [Object(i.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(i.jsxs)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: [Object(i.jsxs)("div", {
                                                className: "single-program-box",
                                                children: [Object(i.jsx)("div", {
                                                    className: "shape",
                                                    children: Object(i.jsx)("img", {
                                                        src: "/images/list-shape1.png",
                                                        alt: "image"
                                                    })
                                                }), Object(i.jsx)("div", {
                                                    className: "icon",
                                                    children: Object(i.jsx)("i", {
                                                        className: "flaticon-diet"
                                                    })
                                                }), Object(i.jsx)("h3", {
                                                    className: "playfair-display-font",
                                                    children: Object(i.jsx)(t.a, {
                                                        href: "/about-1",
                                                        children: Object(i.jsx)("a", {
                                                            children: "Certification Courses"
                                                        })
                                                    })
                                                }), Object(i.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet ut, adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                                }), Object(i.jsx)(t.a, {
                                                    href: "#",
                                                    children: Object(i.jsx)("a", {
                                                        className: "link-btn",
                                                        children: "Read More"
                                                    })
                                                })]
                                            }), Object(i.jsxs)("div", {
                                                className: "single-program-box",
                                                children: [Object(i.jsx)("div", {
                                                    className: "shape",
                                                    children: Object(i.jsx)("img", {
                                                        src: "/images/list-shape2.png",
                                                        alt: "image"
                                                    })
                                                }), Object(i.jsx)("div", {
                                                    className: "icon",
                                                    children: Object(i.jsx)("i", {
                                                        className: "flaticon-healthy-food"
                                                    })
                                                }), Object(i.jsx)("h3", {
                                                    className: "playfair-display-font",
                                                    children: Object(i.jsx)(t.a, {
                                                        href: "/about-1",
                                                        children: Object(i.jsx)("a", {
                                                            children: "Mens\u2019s Coaching"
                                                        })
                                                    })
                                                }), Object(i.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet ut, adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                                }), Object(i.jsx)(t.a, {
                                                    href: "#",
                                                    children: Object(i.jsx)("a", {
                                                        className: "link-btn",
                                                        children: "Read More"
                                                    })
                                                })]
                                            })]
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-6 col-md-6",
                                            children: Object(i.jsxs)("div", {
                                                className: "single-program-box",
                                                children: [Object(i.jsx)("div", {
                                                    className: "shape",
                                                    children: Object(i.jsx)("img", {
                                                        src: "/images/list-shape3.png",
                                                        alt: "image"
                                                    })
                                                }), Object(i.jsx)("div", {
                                                    className: "icon",
                                                    children: Object(i.jsx)("i", {
                                                        className: "flaticon-pineapple"
                                                    })
                                                }), Object(i.jsx)("h3", {
                                                    className: "playfair-display-font",
                                                    children: Object(i.jsx)(t.a, {
                                                        href: "/about-1",
                                                        children: Object(i.jsx)("a", {
                                                            children: "Women\u2019s Coaching"
                                                        })
                                                    })
                                                }), Object(i.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet ut, adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                                }), Object(i.jsx)(t.a, {
                                                    href: "#",
                                                    children: Object(i.jsx)("a", {
                                                        className: "link-btn",
                                                        children: "Read More"
                                                    })
                                                })]
                                            })
                                        })]
                                    }), Object(i.jsx)("div", {
                                        className: "program-circle-shape",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/circle-shape.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        MxYP: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "events-area bg-image bg-eee8df pt-100 pb-70",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Events"
                            }), Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Our Upcoming Events"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-events-box-item",
                                    children: [Object(i.jsxs)("div", {
                                        className: "image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/events/health-img1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("span", {
                                            className: "date",
                                            children: "Wed, 20 May, 2020"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "content",
                                        children: [Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "Global Conference on Business Management"
                                                })
                                            })
                                        }), Object(i.jsxs)("span", {
                                            className: "location",
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-map"
                                            }), " Vancover, Canada"]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-events-box-item",
                                    children: [Object(i.jsxs)("div", {
                                        className: "image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/events/health-img2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("span", {
                                            className: "date",
                                            children: "Tue, 19 May, 2020"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "content",
                                        children: [Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "International Conference on Teacher Education"
                                                })
                                            })
                                        }), Object(i.jsxs)("span", {
                                            className: "location",
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-map"
                                            }), " Sydney, Australia"]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-events-box-item",
                                    children: [Object(i.jsxs)("div", {
                                        className: "image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/events/health-img3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("span", {
                                            className: "date",
                                            children: "Mon, 18 May, 2020"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "content",
                                        children: [Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "International Conference on Special Needs Education"
                                                })
                                            })
                                        }), Object(i.jsxs)("span", {
                                            className: "location",
                                            children: [Object(i.jsx)("i", {
                                                className: "bx bx-map"
                                            }), " Istanbul, Turkey"]
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        UB79: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "health-coaching-banner-area",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "health-coaching-banner-image",
                                    children: Object(i.jsx)("img", {
                                        src: "/images/woman.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "health-coaching-banner-content",
                                    children: [Object(i.jsxs)("h1", {
                                        className: "playfair-display-font",
                                        children: ["Welcome, ", Object(i.jsx)("br", {}), " I am Amada, ", Object(i.jsx)("br", {}), " Your Nutritionist"]
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(i.jsx)("div", {
                                        className: "btn-box",
                                        children: Object(i.jsxs)("div", {
                                            className: "d-flex align-items-center",
                                            children: [Object(i.jsx)(t.a, {
                                                href: "/profile-authentication",
                                                children: Object(i.jsxs)("a", {
                                                    className: "default-btn",
                                                    children: [Object(i.jsx)("i", {
                                                        className: "flaticon-user"
                                                    }), " Join For Free ", Object(i.jsx)("span", {})]
                                                })
                                            }), Object(i.jsx)("img", {
                                                src: "/images/signature.png",
                                                className: "signature",
                                                alt: "image"
                                            })]
                                        })
                                    })]
                                })
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "health-coaching-shape1",
                        children: Object(i.jsx)("img", {
                            src: "/images/health-coaching-shape1.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "health-coaching-shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/health-coaching-shape2.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "health-coaching-shape3",
                        children: Object(i.jsx)("img", {
                            src: "/images/health-coaching-shape3.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "health-coaching-shape4",
                        children: Object(i.jsx)("img", {
                            src: "/images/health-coaching-shape4.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "health-coaching-shape5",
                        children: Object(i.jsx)("img", {
                            src: "/images/health-coaching-shape5.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "health-coaching-shape6",
                        children: Object(i.jsx)("img", {
                            src: "/images/health-coaching-shape6.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "health-coaching-shape7",
                        children: Object(i.jsx)("img", {
                            src: "/images/health-coaching-shape7.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "divider"
                    })]
                })
            }
        },
        jgeC: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "health-services-area bg-fcf7f3 pt-100 pb-70",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Do not wait for Tomorrow!"
                            }), Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "You\u2019ve tried dieting a million times. Now try something different."
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-health-services-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-yoga-2"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Daily Excersize"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, conectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse."
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-health-services-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-yoga"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "courses-1.html",
                                            children: Object(i.jsx)("a", {
                                                children: "Find Your Balance"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, conectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse."
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-health-services-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-lotus"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Personal Program"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, conectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse."
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-health-services-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-tomato"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Natural Process"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, conectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse."
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-health-services-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-yoga-1"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Immune System"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, conectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse."
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-health-services-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "icon",
                                        children: Object(i.jsx)("i", {
                                            className: "flaticon-strawberry"
                                        })
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Gives You Energy"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, conectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse."
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        lxTO: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "blog-area ptb-100",
                    children: [Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Our New"
                            }), Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Check Out Our Latest Blog"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-post-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "post-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/health-blog-img1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "category",
                                                children: "Yoga"
                                            })
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "Surprising SUP Yoga Poses You\u2019ll Want to Try This Summer"
                                                })
                                            })
                                        }), Object(i.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsx)("li", {
                                                children: Object(i.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Alex Morgan"
                                                    })]
                                                })
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 30, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-post-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "post-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/health-blog-img2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "category",
                                                children: "YTT"
                                            })
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "7 Things I Learned From Doing One of Those Social Media Yoga"
                                                })
                                            })
                                        }), Object(i.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsx)("li", {
                                                children: Object(i.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/user2.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Sarah Taylor"
                                                    })]
                                                })
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 29, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-post-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "post-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/health-blog-img3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "category",
                                                children: "Yoga"
                                            })
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "10 Ways to Get Real About Your Body\u2019s Limitations & Avoid"
                                                })
                                            })
                                        }), Object(i.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsx)("li", {
                                                children: Object(i.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/user3.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "David Warner"
                                                    })]
                                                })
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 28, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-12 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "blog-post-info",
                                    children: Object(i.jsxs)("p", {
                                        children: ["Get into details now?\u200b ", Object(i.jsx)(t.a, {
                                            href: "/blog-1",
                                            children: Object(i.jsx)("a", {
                                                children: "View all posts"
                                            })
                                        })]
                                    })
                                })
                            })]
                        })]
                    }), Object(i.jsx)("div", {
                        className: "blog-shape1",
                        children: Object(i.jsx)("img", {
                            src: "/images/blog-shape1.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "blog-shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/blog-shape2.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        mO2b: function(e, s, c) {
            "use strict";
            var i = c("rePB"),
                a = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                n = c.n(l),
                r = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    s && (i = i.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, i)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(i.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(r)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                m = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    items: 1,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"]
                };
            s.a = function() {
                var e = n.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    i = s[1];
                return n.a.useEffect((function() {
                    i(!0)
                }), []), Object(a.jsx)("div", {
                    className: "health-coaching-feedback-area",
                    children: Object(a.jsx)("div", {
                        className: "container-fluid",
                        children: Object(a.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "health-coaching-feedback-image",
                                    children: Object(a.jsx)("img", {
                                        src: "/images/woman.jpg",
                                        alt: "image"
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "health-coaching-inner",
                                    children: [Object(a.jsx)("h2", {
                                        className: "playfair-display-font",
                                        children: "More Than 200,000 People Agree That We are Different"
                                    }), c ? Object(a.jsxs)(o, d(d({
                                        className: "feedback-slides owl-carousel owl-theme"
                                    }, m), {}, {
                                        children: [Object(a.jsxs)("div", {
                                            className: "feedback-quote",
                                            children: [Object(a.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                            }), Object(a.jsx)("div", {
                                                className: "client-info",
                                                children: Object(a.jsxs)("div", {
                                                    className: "d-flex justify-content-center align-items-center",
                                                    children: [Object(a.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        alt: "image"
                                                    }), Object(a.jsxs)("div", {
                                                        className: "title",
                                                        children: [Object(a.jsx)("h3", {
                                                            children: "John Smith"
                                                        }), Object(a.jsx)("span", {
                                                            children: "Python Developer"
                                                        })]
                                                    })]
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object1",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object1.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object2",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object2.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object3",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object3.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object4",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object4.png",
                                                    alt: "image"
                                                })
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "feedback-quote",
                                            children: [Object(a.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                            }), Object(a.jsx)("div", {
                                                className: "client-info",
                                                children: Object(a.jsxs)("div", {
                                                    className: "d-flex justify-content-center align-items-center",
                                                    children: [Object(a.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        alt: "image"
                                                    }), Object(a.jsxs)("div", {
                                                        className: "title",
                                                        children: [Object(a.jsx)("h3", {
                                                            children: "John Smith"
                                                        }), Object(a.jsx)("span", {
                                                            children: "Python Developer"
                                                        })]
                                                    })]
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object1",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object1.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object2",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object2.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object3",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object3.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object4",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object4.png",
                                                    alt: "image"
                                                })
                                            })]
                                        }), Object(a.jsxs)("div", {
                                            className: "feedback-quote",
                                            children: [Object(a.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                            }), Object(a.jsx)("div", {
                                                className: "client-info",
                                                children: Object(a.jsxs)("div", {
                                                    className: "d-flex justify-content-center align-items-center",
                                                    children: [Object(a.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        alt: "image"
                                                    }), Object(a.jsxs)("div", {
                                                        className: "title",
                                                        children: [Object(a.jsx)("h3", {
                                                            children: "John Smith"
                                                        }), Object(a.jsx)("span", {
                                                            children: "Python Developer"
                                                        })]
                                                    })]
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object1",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object1.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object2",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object2.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object3",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object3.png",
                                                    alt: "image"
                                                })
                                            }), Object(a.jsx)("div", {
                                                className: "object4",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/object4.png",
                                                    alt: "image"
                                                })
                                            })]
                                        })]
                                    })) : ""]
                                })
                            })]
                        })
                    })
                })
            }
        },
        rePB: function(e, s, c) {
            "use strict";

            function i(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return i
            }))
        },
        zXCw: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "courses-area bg-image ptb-100",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Learn At Your Own Pace"
                            }), Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Top Selling Courses"
                            }), Object(i.jsx)("p", {
                                children: "Explore all of our courses and pick your suitable ones to enroll and start learning with us! We ensure that you will never regret it!"
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/health-img1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price bg-45a393 shadow",
                                            children: "$39"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user1.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Alex Morgan"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Diet And Nutrition Coach Certification"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/health-img2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price bg-45a393 shadow",
                                            children: "$49"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user2.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "Sarah Taylor"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Internationally Accredited Diploma Certificate"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/health-img3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(i.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "price bg-45a393 shadow",
                                            children: "$59"
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(i.jsx)("img", {
                                                src: "/images/user3.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(i.jsx)("span", {
                                                children: "David Warner"
                                            })]
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Nutrition Certification Diet & Meal Panning"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-12 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "courses-info",
                                    children: Object(i.jsxs)("p", {
                                        children: ["Enjoy the top notch learning methods and achieve next level skills! You are the creator of your own career & we will guide you through that. ", Object(i.jsx)(t.a, {
                                            href: "/profile-authentication",
                                            children: Object(i.jsx)("a", {
                                                children: "Register Free Now!"
                                            })
                                        }), "."]
                                    })
                                })
                            })]
                        })]
                    })
                })
            }
        }
    }
]);