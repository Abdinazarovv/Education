(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [22], {
        "Dqg+": function(e, s, c) {
            "use strict";
            var t = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                a = c.n(i);
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "courses-area ptb-100",
                    children: Object(t.jsxs)("div", {
                        className: "container",
                        children: [Object(t.jsxs)("div", {
                            className: "section-title",
                            children: [Object(t.jsx)("span", {
                                className: "sub-title",
                                children: "Go At Your Own Pace"
                            }), Object(t.jsx)("h2", {
                                children: "Top Selling Courses"
                            }), Object(t.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(t.jsxs)("div", {
                            className: "row",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(t.jsx)(a.a, {
                                            href: "/single-courses-1",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/courses/courses1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(t.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "price shadow",
                                            children: "$39"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(t.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(t.jsx)("img", {
                                                src: "/images/user1.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(t.jsx)("span", {
                                                children: "Alex Morgan"
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(a.a, {
                                                href: "/single-courses-1",
                                                children: Object(t.jsx)("a", {
                                                    children: "Online Course For Korean Level 1"
                                                })
                                            })
                                        }), Object(t.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(t.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 15 Lessons"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 145 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(t.jsx)(a.a, {
                                            href: "/single-courses-1",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/courses/courses2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(t.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "price shadow",
                                            children: "$49"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(t.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(t.jsx)("img", {
                                                src: "/images/user2.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(t.jsx)("span", {
                                                children: "Sarah Taylor"
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(a.a, {
                                                href: "/single-courses-1",
                                                children: Object(t.jsx)("a", {
                                                    children: "Online Course For Marathi Level 2"
                                                })
                                            })
                                        }), Object(t.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(t.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 100 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(t.jsxs)("div", {
                                    className: "single-courses-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "courses-image",
                                        children: [Object(t.jsx)(a.a, {
                                            href: "/single-courses-1",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block image",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/courses/courses3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("a", {
                                            href: "#",
                                            className: "fav",
                                            children: Object(t.jsx)("i", {
                                                className: "flaticon-heart"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "price shadow",
                                            children: "$59"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(t.jsxs)("div", {
                                            className: "course-author d-flex align-items-center",
                                            children: [Object(t.jsx)("img", {
                                                src: "/images/user3.jpg",
                                                className: "rounded-circle",
                                                alt: "image"
                                            }), Object(t.jsx)("span", {
                                                children: "David Warner"
                                            })]
                                        }), Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(a.a, {
                                                href: "/single-courses-1",
                                                children: Object(t.jsx)("a", {
                                                    children: "Online Course For French Level 3"
                                                })
                                            })
                                        }), Object(t.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                        }), Object(t.jsxs)("ul", {
                                            className: "courses-box-footer d-flex justify-content-between align-items-center",
                                            children: [Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-agenda"
                                                }), " 20 Lessons"]
                                            }), Object(t.jsxs)("li", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-people"
                                                }), " 150 Students"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-12 col-md-12",
                                children: Object(t.jsx)("div", {
                                    className: "courses-info",
                                    children: Object(t.jsxs)("p", {
                                        children: ["Get the most dedicated consultation for your life-changing course. Earn a certification for your effort and passion ", Object(t.jsx)(a.a, {
                                            href: "/profile-authentication",
                                            children: Object(t.jsx)("a", {
                                                children: "Join Free Now"
                                            })
                                        }), "."]
                                    })
                                })
                            })]
                        })]
                    })
                })
            }
        },
        JcBV: function(e, s, c) {
            "use strict";
            var t = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "funfacts-area bg-fffaf3",
                    children: Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "row",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(t.jsx)("h3", {
                                        children: "1926"
                                    }), Object(t.jsx)("p", {
                                        children: "Finished Sessions"
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(t.jsx)("h3", {
                                        children: "3279"
                                    }), Object(t.jsx)("p", {
                                        children: "Enrolled Learners"
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(t.jsx)("h3", {
                                        children: "250"
                                    }), Object(t.jsx)("p", {
                                        children: "Online Instructors"
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(t.jsx)("h3", {
                                        children: "100%"
                                    }), Object(t.jsx)("p", {
                                        children: "Satisfaction Rate"
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        L4uS: function(e, s, c) {
            "use strict";
            var t = c("rePB"),
                i = c("nKUr"),
                a = c("ODXe"),
                r = c("q1tI"),
                n = c.n(r),
                l = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    s && (t = t.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, t)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(t.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(l)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                m = {
                    loop: !0,
                    nav: !0,
                    margin: 60,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 3,
                            margin: 20
                        },
                        600: {
                            items: 3
                        },
                        768: {
                            items: 4,
                            margin: 30
                        },
                        1e3: {
                            items: 6
                        }
                    }
                };
            s.a = function() {
                var e = n.a.useState(!1),
                    s = Object(a.a)(e, 2),
                    c = s[0],
                    t = s[1];
                return n.a.useEffect((function() {
                    t(!0)
                }), []), Object(i.jsx)("div", {
                    className: "partner-area bg-fe4a55 ptb-70",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: c ? Object(i.jsxs)(o, d(d({
                            className: "partner-slides owl-carousel owl-theme"
                        }, m), {}, {
                            children: [Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner7.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner8.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner9.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner10.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner11.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner12.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner8.png",
                                    alt: "image"
                                })
                            })]
                        })) : ""
                    })
                })
            }
        },
        Oebb: function(e, s, c) {
            "use strict";
            var t = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                a = c.n(i);
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "about-area ptb-100",
                    children: Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(t.jsx)("div", {
                                    className: "about-image text-center",
                                    children: Object(t.jsx)("img", {
                                        src: "/images/about-img9.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(t.jsxs)("div", {
                                    className: "about-content",
                                    children: [Object(t.jsx)("span", {
                                        className: "sub-title",
                                        children: "Why choose us"
                                    }), Object(t.jsx)("h2", {
                                        children: "Language Courses to Help You Explore The World"
                                    }), Object(t.jsx)("p", {
                                        children: "We understand better that online-based learning can make a significant change to reach students from all over the world! Giving options to learn better always can offer the best outcomes!"
                                    }), Object(t.jsxs)("ul", {
                                        className: "features-list",
                                        children: [Object(t.jsx)("li", {
                                            children: Object(t.jsxs)("span", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-experience"
                                                }), " Skiled Teachers"]
                                            })
                                        }), Object(t.jsx)("li", {
                                            children: Object(t.jsxs)("span", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-time-left"
                                                }), " Afordable Courses"]
                                            })
                                        }), Object(t.jsx)("li", {
                                            children: Object(t.jsxs)("span", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-tutorials"
                                                }), " Efficient & Flexible"]
                                            })
                                        }), Object(t.jsx)("li", {
                                            children: Object(t.jsxs)("span", {
                                                children: [Object(t.jsx)("i", {
                                                    className: "flaticon-self-growth"
                                                }), " Lifetime Access"]
                                            })
                                        })]
                                    }), Object(t.jsx)(a.a, {
                                        href: "/profile-authentication",
                                        children: Object(t.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Join For Free ", Object(t.jsx)("span", {})]
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        RWYh: function(e, s, c) {
            "use strict";
            var t = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                a = c.n(i);
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "courses-area pt-100 pb-70 bg-f5f7fa",
                    children: Object(t.jsxs)("div", {
                        className: "container",
                        children: [Object(t.jsxs)("div", {
                            className: "section-title",
                            children: [Object(t.jsx)("span", {
                                className: "sub-title",
                                children: "Welcome to eDemy"
                            }), Object(t.jsx)("h2", {
                                children: "Our Language Courses"
                            }), Object(t.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(t.jsxs)("div", {
                            className: "row",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-language-courses-box",
                                    children: [Object(t.jsx)("img", {
                                        src: "/images/language-courses/language-courses1.png",
                                        alt: "image"
                                    }), Object(t.jsx)("h3", {
                                        children: "Chinese"
                                    }), Object(t.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(t.jsx)(a.a, {
                                        href: "/courses-1",
                                        children: Object(t.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-right"
                                            }), " View More ", Object(t.jsx)("span", {})]
                                        })
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-language-courses-box",
                                    children: [Object(t.jsx)("img", {
                                        src: "/images/language-courses/language-courses2.png",
                                        alt: "image"
                                    }), Object(t.jsx)("h3", {
                                        children: "Spanish"
                                    }), Object(t.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(t.jsx)(a.a, {
                                        href: "/courses-1",
                                        children: Object(t.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-right"
                                            }), " View More ", Object(t.jsx)("span", {})]
                                        })
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                children: Object(t.jsxs)("div", {
                                    className: "single-language-courses-box",
                                    children: [Object(t.jsx)("img", {
                                        src: "/images/language-courses/language-courses3.png",
                                        alt: "image"
                                    }), Object(t.jsx)("h3", {
                                        children: "Japanese"
                                    }), Object(t.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(t.jsx)(a.a, {
                                        href: "/courses-1",
                                        children: Object(t.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-right"
                                            }), " View More ", Object(t.jsx)("span", {})]
                                        })
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        "S+AA": function(e, s, c) {
            "use strict";
            var t = c("rePB"),
                i = c("nKUr"),
                a = c("ODXe"),
                r = c("q1tI"),
                n = c.n(r),
                l = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    s && (t = t.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, t)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(t.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(l)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                m = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    animateOut: "fadeOut",
                    items: 1,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"]
                };
            s.a = function() {
                var e = n.a.useState(!1),
                    s = Object(a.a)(e, 2),
                    c = s[0],
                    t = s[1];
                return n.a.useEffect((function() {
                    t(!0)
                }), []), Object(i.jsx)("div", {
                    className: "feedback-with-bg-image ptb-100 jarallax",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: c ? Object(i.jsxs)(o, d(d({
                            className: "feedback-slides feedback-slides-style-two owl-carousel owl-theme"
                        }, m), {}, {
                            children: [Object(i.jsxs)("div", {
                                className: "single-feedback-item-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "John Smith"
                                        }), Object(i.jsx)("span", {
                                            children: "Python Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-item-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user2.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "David Warner"
                                        }), Object(i.jsx)("span", {
                                            children: "Java Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-item-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user3.jpg",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Sarah Taylor"
                                        }), Object(i.jsx)("span", {
                                            children: "PHP Developer"
                                        })]
                                    })]
                                })]
                            })]
                        })) : ""
                    })
                })
            }
        },
        bQbf: function(e, s, c) {
            "use strict";
            var t = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                a = c.n(i);
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "events-area pt-100 pb-70",
                    children: Object(t.jsxs)("div", {
                        className: "container",
                        children: [Object(t.jsxs)("div", {
                            className: "section-title",
                            children: [Object(t.jsx)("span", {
                                className: "sub-title",
                                children: "Events"
                            }), Object(t.jsx)("h2", {
                                children: "Our Upcoming Events"
                            }), Object(t.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(t.jsxs)("div", {
                            className: "row",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "image",
                                        children: [Object(t.jsx)(a.a, {
                                            href: "#",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/events/events1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("span", {
                                            className: "date",
                                            children: "Wed, 20 May, 2020"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "content",
                                        children: [Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(a.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    children: "Global Conference on Business Management"
                                                })
                                            })
                                        }), Object(t.jsxs)("span", {
                                            className: "location",
                                            children: [Object(t.jsx)("i", {
                                                className: "bx bx-map"
                                            }), " Vancover, Canada"]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(t.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "image",
                                        children: [Object(t.jsx)(a.a, {
                                            href: "#",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/events/events2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("span", {
                                            className: "date",
                                            children: "Tue, 19 May, 2020"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "content",
                                        children: [Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(a.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    children: "International Conference on Teacher Education"
                                                })
                                            })
                                        }), Object(t.jsxs)("span", {
                                            className: "location",
                                            children: [Object(t.jsx)("i", {
                                                className: "bx bx-map"
                                            }), " Sydney, Australia"]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6 offset-lg-0 offset-md-3 offset-sm-3",
                                children: Object(t.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(t.jsxs)("div", {
                                        className: "image",
                                        children: [Object(t.jsx)(a.a, {
                                            href: "#",
                                            children: Object(t.jsx)("a", {
                                                className: "d-block",
                                                children: Object(t.jsx)("img", {
                                                    src: "/images/events/events3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(t.jsx)("span", {
                                            className: "date",
                                            children: "Mon, 18 May, 2020"
                                        })]
                                    }), Object(t.jsxs)("div", {
                                        className: "content",
                                        children: [Object(t.jsx)("h3", {
                                            children: Object(t.jsx)(a.a, {
                                                href: "#",
                                                children: Object(t.jsx)("a", {
                                                    children: "International Conference on Special Needs Education"
                                                })
                                            })
                                        }), Object(t.jsxs)("span", {
                                            className: "location",
                                            children: [Object(t.jsx)("i", {
                                                className: "bx bx-map"
                                            }), " Istanbul, Turkey"]
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        hj2d: function(e, s, c) {
            "use strict";
            var t = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "information-area ptb-100",
                    children: Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(t.jsxs)("div", {
                                    className: "information-content",
                                    children: [Object(t.jsx)("span", {
                                        className: "sub-title",
                                        children: "Information"
                                    }), Object(t.jsx)("h2", {
                                        children: "How To Apply?"
                                    }), Object(t.jsxs)("ul", {
                                        className: "apply-details",
                                        children: [Object(t.jsxs)("li", {
                                            children: [Object(t.jsx)("div", {
                                                className: "icon",
                                                children: Object(t.jsx)("i", {
                                                    className: "flaticon-checkmark"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: "Select Suitable Course"
                                            }), Object(t.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore."
                                            })]
                                        }), Object(t.jsxs)("li", {
                                            children: [Object(t.jsx)("div", {
                                                className: "icon",
                                                children: Object(t.jsx)("i", {
                                                    className: "flaticon-webinar"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: "Student Information"
                                            }), Object(t.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore."
                                            })]
                                        }), Object(t.jsxs)("li", {
                                            children: [Object(t.jsx)("div", {
                                                className: "icon",
                                                children: Object(t.jsx)("i", {
                                                    className: "flaticon-credit-card-1"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: "Payment Information"
                                            }), Object(t.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore."
                                            })]
                                        }), Object(t.jsxs)("li", {
                                            children: [Object(t.jsx)("div", {
                                                className: "icon",
                                                children: Object(t.jsx)("i", {
                                                    className: "flaticon-verify"
                                                })
                                            }), Object(t.jsx)("h3", {
                                                children: "Register Now"
                                            }), Object(t.jsx)("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore."
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(t.jsx)("div", {
                                    className: "information-image text-center",
                                    children: Object(t.jsx)("img", {
                                        src: "/images/information-img.png",
                                        alt: "image"
                                    })
                                })
                            })]
                        })
                    })
                })
            }
        },
        ngeS: function(e, s, c) {
            "use strict";
            var t = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                a = c.n(i);
            s.a = function() {
                return Object(t.jsxs)("div", {
                    className: "main-banner-wrapper",
                    children: [Object(t.jsx)("div", {
                        className: "container-fluid",
                        children: Object(t.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-5 col-md-12",
                                children: Object(t.jsxs)("div", {
                                    className: "main-banner-wrapper-content",
                                    children: [Object(t.jsx)("h1", {
                                        children: "Achieve the Best Results with Academy"
                                    }), Object(t.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(t.jsx)(a.a, {
                                        href: "/profile-authentication",
                                        children: Object(t.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(t.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Join For Free ", Object(t.jsx)("span", {})]
                                        })
                                    })]
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-7 col-md-12",
                                children: Object(t.jsx)("div", {
                                    className: "main-banner-wrapper-image text-center",
                                    children: Object(t.jsx)("img", {
                                        src: "/images/banner-img3.png",
                                        alt: "image"
                                    })
                                })
                            })]
                        })
                    }), Object(t.jsx)("div", {
                        className: "banner-shape14",
                        children: Object(t.jsx)("img", {
                            src: "/images/banner-shape15.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "banner-shape15",
                        children: Object(t.jsx)("img", {
                            src: "/images/banner-shape16.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "banner-shape16",
                        children: Object(t.jsx)("img", {
                            src: "/images/banner-shape17.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "banner-shape17",
                        children: Object(t.jsx)("img", {
                            src: "/images/banner-shape18.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "banner-shape18",
                        children: Object(t.jsx)("img", {
                            src: "/images/banner-shape19.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        rDzp: function(e, s, c) {
            "use strict";
            var t = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(t.jsx)("div", {
                    className: "free-trial-area ptb-100 bg-fffaf3",
                    children: Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(t.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(t.jsx)("div", {
                                    className: "free-trial-image text-center",
                                    children: Object(t.jsx)("img", {
                                        src: "/images/free-trial-img.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(t.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(t.jsxs)("div", {
                                    className: "free-trial-form",
                                    children: [Object(t.jsx)("span", {
                                        className: "sub-title",
                                        children: "Free Trial"
                                    }), Object(t.jsx)("h2", {
                                        children: "Sign Up For A Free Trial"
                                    }), Object(t.jsxs)("form", {
                                        children: [Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "text",
                                                className: "form-control",
                                                placeholder: "Your Name *"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "email",
                                                className: "form-control",
                                                placeholder: "Your Email *"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "text",
                                                className: "form-control",
                                                placeholder: "Your Phone *"
                                            })
                                        }), Object(t.jsx)("div", {
                                            className: "form-group",
                                            children: Object(t.jsx)("input", {
                                                type: "text",
                                                className: "form-control",
                                                placeholder: "Your Subject *"
                                            })
                                        }), Object(t.jsx)("button", {
                                            type: "submit",
                                            children: "Register Now"
                                        })]
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        rePB: function(e, s, c) {
            "use strict";

            function t(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return t
            }))
        },
        ur7V: function(e, s, c) {
            "use strict";
            var t = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(t.jsxs)("div", {
                    className: "subscribe-area bg-f9f9f9 ptb-100",
                    children: [Object(t.jsx)("div", {
                        className: "container",
                        children: Object(t.jsxs)("div", {
                            className: "subscribe-content",
                            children: [Object(t.jsx)("span", {
                                className: "sub-title",
                                children: "Go At Your Own Pace"
                            }), Object(t.jsx)("h2", {
                                children: "Subscribe To Our Newsletter"
                            }), Object(t.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(t.jsxs)("form", {
                                className: "newsletter-form",
                                children: [Object(t.jsx)("input", {
                                    type: "text",
                                    className: "input-newsletter",
                                    placeholder: "Enter your email address",
                                    name: "EMAIL",
                                    required: !0
                                }), Object(t.jsxs)("button", {
                                    type: "submit",
                                    className: "default-btn",
                                    children: [Object(t.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Subscribe Now ", Object(t.jsx)("span", {})]
                                })]
                            })]
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape4",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape13",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape12.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape14",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape13.png",
                            alt: "image"
                        })
                    }), Object(t.jsx)("div", {
                        className: "shape15",
                        "data-speed": "0.06",
                        "data-revert": "true",
                        children: Object(t.jsx)("img", {
                            src: "/images/shape14.png",
                            alt: "image"
                        })
                    })]
                })
            }
        }
    }
]);