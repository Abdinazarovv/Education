(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [17], {
        "3XVu": function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = c("ODXe"),
                t = c("q1tI"),
                l = c.n(t),
                r = c("YFqc"),
                n = c.n(r),
                j = c("Vvt1"),
                d = c.n(j)()((function() {
                    return Promise.all([c.e(0), c.e(6), c.e(8)]).then(c.t.bind(null, "60Bi", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["60Bi"]
                        },
                        modules: ["react-modal-video"]
                    }
                });
            s.a = function() {
                var e = l.a.useState(!1),
                    s = Object(a.a)(e, 2),
                    c = s[0],
                    t = s[1],
                    r = l.a.useState(!0),
                    j = Object(a.a)(r, 2),
                    o = j[0],
                    m = j[1];
                l.a.useEffect((function() {
                    t(!0)
                }), []);
                return Object(i.jsxs)(l.a.Fragment, {
                    children: [Object(i.jsx)("div", {
                        className: "experience-area ptb-100 extra-padding",
                        children: Object(i.jsx)("div", {
                            className: "container",
                            children: Object(i.jsxs)("div", {
                                className: "row align-items-center",
                                children: [Object(i.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(i.jsxs)("div", {
                                        className: "experience-content",
                                        children: [Object(i.jsx)("span", {
                                            className: "sub-title",
                                            children: "Join our World Famous Yoga Teacher Training Course... Online!"
                                        }), Object(i.jsx)("h2", {
                                            className: "playfair-display-font",
                                            children: "200hr, 300hr & 500hr Certified Online Yoga courses"
                                        }), Object(i.jsx)("p", {
                                            children: "eCademy training programs can bring you a super exciting experience of learning through online! You never face any negative experience while enjoying your classNamees virtually by sitting in your comfort zone. Our flexible learning initiatives will help you to learn better and quicker than the traditional ways of learning skills."
                                        }), Object(i.jsxs)("ul", {
                                            className: "features-list",
                                            children: [Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Receive a Yoga Alliance Certificate"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " 100hrs of Live Streaming Zoom classNamees"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Watch Video Modules in Your Free Time"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Flex Schedule with Extended Time from Yoga Alliance"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Practice Traditional Hatha and vinyasa Yoga"]
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Bonus Aerial & Acro Yoga Workshops"]
                                            })]
                                        }), Object(i.jsx)(n.a, {
                                            href: "/profile-authentication",
                                            children: Object(i.jsxs)("a", {
                                                className: "default-btn",
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-user"
                                                }), " Get Started Now ", Object(i.jsx)("span", {})]
                                            })
                                        })]
                                    })
                                }), Object(i.jsx)("div", {
                                    className: "col-lg-6 col-md-12",
                                    children: Object(i.jsxs)("div", {
                                        className: "experience-image",
                                        children: [Object(i.jsx)("img", {
                                            src: "/images/experience-img1.jpg",
                                            alt: "image"
                                        }), Object(i.jsx)(n.a, {
                                            href: "#play-video",
                                            children: Object(i.jsx)("a", {
                                                onClick: function(e) {
                                                    e.preventDefault(), m(!o)
                                                },
                                                className: "video-btn popup-youtube",
                                                children: Object(i.jsx)("i", {
                                                    className: "flaticon-play"
                                                })
                                            })
                                        }), Object(i.jsxs)("span", {
                                            className: "title",
                                            children: [Object(i.jsx)("span", {
                                                children: "15"
                                            }), " Years of Experience"]
                                        })]
                                    })
                                })]
                            })
                        })
                    }), c ? Object(i.jsx)(d, {
                        channel: "youtube",
                        isOpen: !o,
                        videoId: "bk7McNUjWgw",
                        onClose: function() {
                            return m(!o)
                        }
                    }) : ""]
                })
            }
        },
        AAaN: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "pricing-area bg-f9f9f9 pt-100 pb-70",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Pricing"
                            }), Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Our Flexible Pricing Plan"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-pricing-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "pricing-header",
                                        children: [Object(i.jsx)("img", {
                                            src: "/images/yoga-pricing-img1.png",
                                            alt: "image"
                                        }), Object(i.jsx)("h3", {
                                            children: "200 Hour TTC"
                                        })]
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-features",
                                        children: Object(i.jsxs)("ul", {
                                            children: [Object(i.jsx)("li", {
                                                children: "Examine traditional yoga asanas"
                                            }), Object(i.jsx)("li", {
                                                children: "Learn meditation and philosophy"
                                            }), Object(i.jsx)("li", {
                                                children: "Connect energetics and anatomy"
                                            }), Object(i.jsx)("li", {
                                                children: "Practice teaching for confidence"
                                            }), Object(i.jsx)("li", {
                                                children: "Become a Yoga Alliance RYT200"
                                            })]
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "price",
                                        children: ["$499.99", Object(i.jsx)("span", {
                                            children: "Yoga Alliance Certified"
                                        })]
                                    }), Object(i.jsx)(t.a, {
                                        href: "#",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn",
                                            children: ["Book Now", Object(i.jsx)("span", {})]
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-shape1",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/pricing-shape1.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-shape2",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/pricing-shape2.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-pricing-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "pricing-header",
                                        children: [Object(i.jsx)("img", {
                                            src: "/images/yoga-pricing-img2.png",
                                            alt: "image"
                                        }), Object(i.jsx)("h3", {
                                            children: "200 Hour TTC"
                                        })]
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-features",
                                        children: Object(i.jsxs)("ul", {
                                            children: [Object(i.jsx)("li", {
                                                children: "Fine tune yoga alignment and form"
                                            }), Object(i.jsx)("li", {
                                                children: "Explore the fine art of sequencing"
                                            }), Object(i.jsx)("li", {
                                                children: "Delve deeper into ancient scripture"
                                            }), Object(i.jsx)("li", {
                                                children: "Study therapeutic based anatomy"
                                            }), Object(i.jsx)("li", {
                                                children: "Become a Yoga Alliance RYT300"
                                            })]
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "price",
                                        children: ["$599.99", Object(i.jsx)("span", {
                                            children: "Yoga Alliance Certified"
                                        })]
                                    }), Object(i.jsx)(t.a, {
                                        href: "#",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn",
                                            children: ["Book Now", Object(i.jsx)("span", {})]
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-shape1",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/pricing-shape1.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-shape2",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/pricing-shape2.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-pricing-box",
                                    children: [Object(i.jsxs)("div", {
                                        className: "pricing-header",
                                        children: [Object(i.jsx)("img", {
                                            src: "/images/yoga-pricing-img3.png",
                                            alt: "image"
                                        }), Object(i.jsx)("h3", {
                                            children: "500 Hour TTC"
                                        })]
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-features",
                                        children: Object(i.jsxs)("ul", {
                                            children: [Object(i.jsx)("li", {
                                                children: "Get the highest level certification"
                                            }), Object(i.jsx)("li", {
                                                children: "Become a respected yoga master"
                                            }), Object(i.jsx)("li", {
                                                children: "Work at luxury resorts and retreats"
                                            }), Object(i.jsx)("li", {
                                                children: "Lead your own teacher trainings"
                                            }), Object(i.jsx)("li", {
                                                children: "Become a Yoga Alliance RYT500"
                                            })]
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "price",
                                        children: ["$699.99", Object(i.jsx)("span", {
                                            children: "Yoga Alliance Certified"
                                        })]
                                    }), Object(i.jsx)(t.a, {
                                        href: "#",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn",
                                            children: ["Book Now", Object(i.jsx)("span", {})]
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-shape1",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/pricing-shape1.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "pricing-shape2",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/pricing-shape2.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        AFc6: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "blog-area pt-100 pb-70",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Our New"
                            }), Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Check Out Our Latest Blog"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-post-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "post-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/yoga-blog-img1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "category",
                                                children: "Yoga"
                                            })
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "Surprising SUP Yoga Poses You\u2019ll Want to Try This Summer"
                                                })
                                            })
                                        }), Object(i.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsx)("li", {
                                                children: Object(i.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/user1.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Alex Morgan"
                                                    })]
                                                })
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 30, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-post-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "post-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/yoga-blog-img2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "category",
                                                children: "YTT"
                                            })
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "7 Things I Learned From Doing One of Those Social Media Yoga"
                                                })
                                            })
                                        }), Object(i.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsx)("li", {
                                                children: Object(i.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/user2.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Sarah Taylor"
                                                    })]
                                                })
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 29, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-post-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "post-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/yoga-blog-img3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)("a", {
                                            href: "#",
                                            className: "category",
                                            children: "Yoga"
                                        }), Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "#",
                                                children: Object(i.jsx)("a", {
                                                    children: "10 Ways to Get Real About Your Body\u2019s Limitations & Avoid"
                                                })
                                            })
                                        }), Object(i.jsxs)("ul", {
                                            className: "post-content-footer d-flex justify-content-between align-items-center",
                                            children: [Object(i.jsx)("li", {
                                                children: Object(i.jsxs)("div", {
                                                    className: "post-author d-flex align-items-center",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/user3.jpg",
                                                        className: "rounded-circle",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "David Warner"
                                                    })]
                                                })
                                            }), Object(i.jsxs)("li", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "flaticon-calendar"
                                                }), " April 28, 2020"]
                                            })]
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        Eec0: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "courses-area pb-70",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Go at your own pace"
                            }), Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Become a Certified Yoga Teacher"
                            }), Object(i.jsx)("p", {
                                children: "Explore all of our courses and pick your suitable ones to enroll and start learning with us! We ensure that you will never regret it!"
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-yoga-courses-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "courses-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/yoga-img1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "200 Hour YTT Course"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                        }), Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsxs)("a", {
                                                className: "default-btn",
                                                children: ["View Details", Object(i.jsx)("span", {})]
                                            })
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-yoga-courses-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "courses-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/yoga-img2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "300 Hour YTT Course"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                        }), Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsxs)("a", {
                                                className: "default-btn",
                                                children: ["View Details", Object(i.jsx)("span", {})]
                                            })
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 offset-lg-0 offset-md-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-yoga-courses-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "courses-image",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/single-courses-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/courses/yoga-img3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "courses-content",
                                        children: [Object(i.jsx)("h3", {
                                            className: "playfair-display-font",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-courses-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "500 Hour YTT Course"
                                                })
                                            })
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                        }), Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsxs)("a", {
                                                className: "default-btn",
                                                children: ["View Details", Object(i.jsx)("span", {})]
                                            })
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        Md9E: function(e, s, c) {
            "use strict";
            var i = c("rePB"),
                a = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                r = c.n(l),
                n = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    s && (i = i.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, i)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(i.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(n)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                m = {
                    loop: !0,
                    nav: !0,
                    margin: 60,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        600: {
                            items: 3
                        },
                        1e3: {
                            items: 6
                        }
                    }
                };
            s.a = function() {
                var e = r.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    i = s[1];
                return r.a.useEffect((function() {
                    i(!0)
                }), []), Object(a.jsx)("div", {
                    className: "partner-area bg-6ba292 ptb-70",
                    children: Object(a.jsx)("div", {
                        className: "container",
                        children: c ? Object(a.jsxs)(o, d(d({
                            className: "partner-slides owl-carousel owl-theme"
                        }, m), {}, {
                            children: [Object(a.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(a.jsx)("img", {
                                    src: "/images/partner/partner7.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(a.jsx)("img", {
                                    src: "/images/partner/partner8.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(a.jsx)("img", {
                                    src: "/images/partner/partner9.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(a.jsx)("img", {
                                    src: "/images/partner/partner10.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(a.jsx)("img", {
                                    src: "/images/partner/partner11.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(a.jsx)("img", {
                                    src: "/images/partner/partner12.png",
                                    alt: "image"
                                })
                            }), Object(a.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(a.jsx)("img", {
                                    src: "/images/partner/partner8.png",
                                    alt: "image"
                                })
                            })]
                        })) : ""
                    })
                })
            }
        },
        PEey: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "yoga-main-banner",
                    children: [Object(i.jsx)("div", {
                        className: "container-fluid",
                        children: Object(i.jsxs)("div", {
                            className: "yoga-banner-content",
                            children: [Object(i.jsx)("img", {
                                src: "/images/yoga-banner.png",
                                alt: "image",
                                className: "main-image"
                            }), Object(i.jsxs)("div", {
                                className: "content",
                                children: [Object(i.jsx)("img", {
                                    src: "/images/top-img.png",
                                    className: "top-image",
                                    alt: "image"
                                }), Object(i.jsx)("h1", {
                                    className: "playfair-display-font",
                                    children: "Accredited Online Yoga Teacher Training"
                                }), Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                }), Object(i.jsx)(t.a, {
                                    href: "/profile-authentication",
                                    children: Object(i.jsxs)("a", {
                                        className: "default-btn",
                                        children: [Object(i.jsx)("i", {
                                            className: "flaticon-user"
                                        }), " Join For Free ", Object(i.jsx)("span", {})]
                                    })
                                }), Object(i.jsx)("br", {}), Object(i.jsx)("img", {
                                    src: "/images/bottom-img.png",
                                    className: "bottom-image",
                                    alt: "image"
                                })]
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "banner-shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/banner-shape2.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "banner-shape3",
                        children: Object(i.jsx)("img", {
                            src: "/images/banner-shape3.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        SIq9: function(e, s, c) {
            "use strict";
            var i = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "funfacts-area bg-fffaf3",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(i.jsx)("h3", {
                                        children: "1,926"
                                    }), Object(i.jsx)("p", {
                                        children: "Finished Sessions"
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(i.jsx)("h3", {
                                        children: "3,279"
                                    }), Object(i.jsx)("p", {
                                        children: "Enrolled Learners"
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(i.jsx)("h3", {
                                        children: "250"
                                    }), Object(i.jsx)("p", {
                                        children: "Online Instructors"
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(i.jsx)("h3", {
                                        children: "100%"
                                    }), Object(i.jsx)("p", {
                                        children: "Satisfaction Rate"
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        VU5F: function(e, s, c) {
            "use strict";
            var i = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "subscribe-area bg-f5f7fa ptb-100",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "subscribe-image",
                                    children: Object(i.jsx)("img", {
                                        src: "/images/subscribe-img1.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "subscribe-content",
                                    children: [Object(i.jsx)("span", {
                                        className: "sub-title",
                                        children: "Go At Your Own Pace"
                                    }), Object(i.jsx)("h2", {
                                        className: "playfair-display-font",
                                        children: "Subscribe To Our Newsletter"
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(i.jsxs)("form", {
                                        className: "newsletter-form",
                                        children: [Object(i.jsx)("input", {
                                            type: "text",
                                            className: "input-newsletter",
                                            placeholder: "Enter your email address",
                                            name: "EMAIL",
                                            required: !0
                                        }), Object(i.jsxs)("button", {
                                            type: "submit",
                                            className: "default-btn",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Subscribe Now ", Object(i.jsx)("span", {})]
                                        })]
                                    })]
                                })
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape4",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape13",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape12.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        WYza: function(e, s, c) {
            "use strict";
            var i = c("rePB"),
                a = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                r = c.n(l),
                n = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    s && (i = i.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, i)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(i.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(n)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                m = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 1
                        },
                        768: {
                            items: 2
                        },
                        1200: {
                            items: 2
                        }
                    }
                };
            s.a = function() {
                var e = r.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    i = s[1];
                return r.a.useEffect((function() {
                    i(!0)
                }), []), Object(a.jsxs)("div", {
                    className: "feedback-area bg-6ba292 ptb-100",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: c ? Object(a.jsxs)(o, d(d({
                            className: "feedback-slides-two owl-carousel owl-theme"
                        }, m), {}, {
                            children: [Object(a.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(a.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(a.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "title",
                                        children: [Object(a.jsx)("h3", {
                                            children: "John Smith"
                                        }), Object(a.jsx)("span", {
                                            children: "Python Developer"
                                        })]
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(a.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(a.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user2.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "title",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Sarah Taylor"
                                        }), Object(a.jsx)("span", {
                                            children: "PHP Developer"
                                        })]
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(a.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(a.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "title",
                                        children: [Object(a.jsx)("h3", {
                                            children: "David Warner"
                                        }), Object(a.jsx)("span", {
                                            children: "QA Developer"
                                        })]
                                    })]
                                })]
                            })]
                        })) : ""
                    }), Object(a.jsx)("div", {
                        className: "divider2"
                    }), Object(a.jsx)("div", {
                        className: "divider3"
                    }), Object(a.jsx)("div", {
                        className: "tree-shape",
                        children: Object(a.jsx)("img", {
                            src: "/images/tree-shape.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        drEa: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "training-area bg-f5f7fa pt-100 pb-70",
                    children: [Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("h2", {
                                className: "playfair-display-font",
                                children: "Why Online Yoga Training"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-training-box",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/training-img1.png",
                                        alt: "image"
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Flexibility"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(i.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-training-box",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/training-img2.png",
                                        alt: "image"
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Comfort"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(i.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-training-box",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/training-img3.png",
                                        alt: "image"
                                    }), Object(i.jsx)("h3", {
                                        className: "playfair-display-font",
                                        children: Object(i.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(i.jsx)("a", {
                                                children: "Resources"
                                            })
                                        })
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(i.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now"
                                        })
                                    })]
                                })
                            })]
                        })]
                    }), Object(i.jsx)("div", {
                        className: "tree-shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/tree-shape2.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "tree-shape3",
                        children: Object(i.jsx)("img", {
                            src: "/images/tree-shape3.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        j8NB: function(e, s, c) {
            "use strict";
            var i = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "download-syllabus-area ptb-100",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "download-syllabus-image",
                                    children: Object(i.jsx)("img", {
                                        src: "/images/download.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "download-syllabus-form",
                                    children: [Object(i.jsx)("h2", {
                                        className: "playfair-display-font",
                                        children: "Download Courses Syllabus"
                                    }), Object(i.jsx)("p", {
                                        children: "Your email address will not be published. Required fields are marked *"
                                    }), Object(i.jsxs)("form", {
                                        children: [Object(i.jsx)("div", {
                                            className: "form-group",
                                            children: Object(i.jsx)("input", {
                                                type: "text",
                                                className: "form-control",
                                                placeholder: "Your Name *"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "form-group",
                                            children: Object(i.jsx)("input", {
                                                type: "email",
                                                className: "form-control",
                                                placeholder: "Your Email *"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "form-group",
                                            children: Object(i.jsx)("input", {
                                                type: "text",
                                                className: "form-control",
                                                placeholder: "Your Phone *"
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "form-group",
                                            children: Object(i.jsxs)("select", {
                                                className: "form-control",
                                                children: [Object(i.jsx)("option", {
                                                    children: "200 Hour YTT Course *"
                                                }), Object(i.jsx)("option", {
                                                    children: "300 Hour YTT Course *"
                                                }), Object(i.jsx)("option", {
                                                    children: "400 Hour YTT Course *"
                                                })]
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "form-group",
                                            children: Object(i.jsxs)("select", {
                                                className: "form-control",
                                                children: [Object(i.jsx)("option", {
                                                    children: "How Did You Hear About Us? *"
                                                }), Object(i.jsx)("option", {
                                                    children: "How Did You Hear About Us? *"
                                                }), Object(i.jsx)("option", {
                                                    children: "How Did You Hear About Us? *"
                                                })]
                                            })
                                        }), Object(i.jsxs)("button", {
                                            className: "default-btn",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-tick"
                                            }), "Submit Now ", Object(i.jsx)("span", {})]
                                        })]
                                    }), Object(i.jsx)("div", {
                                        className: "syllabus-shape1",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/syllabus-shape1.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "syllabus-shape2",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/syllabus-shape2.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "syllabus-shape3",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/syllabus-shape3.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        rePB: function(e, s, c) {
            "use strict";

            function i(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return i
            }))
        },
        xghe: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "about-area ptb-100",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "about-image text-center",
                                    children: Object(i.jsx)("img", {
                                        src: "/images/about-img11.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "about-content",
                                    children: [Object(i.jsx)("span", {
                                        className: "sub-title",
                                        children: "About Us"
                                    }), Object(i.jsx)("h2", {
                                        className: "playfair-display-font",
                                        children: "Feel Like You Are Attending Your Class Physically!"
                                    }), Object(i.jsx)("p", {
                                        children: "eCademy training programs can bring you a super exciting experience of learning through online! You never face any negative experience while enjoying your classNamees virtually by sitting in your comfort zone. Our flexible learning initiatives will help you to learn better and quicker than the traditional ways of learning skills."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn mt-2",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Join For Free ", Object(i.jsx)("span", {})]
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        }
    }
]);