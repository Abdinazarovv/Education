(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [20], {
        "+Fop": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "courses-area ptb-100",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go at your own pace"
                            }), Object(a.jsx)("h2", {
                                children: "The World\u2019s Largest Selection Of Courses"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item without-box-shadow",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small1.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$39"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Agile Crash Course: Agile Project Management"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 15 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 145 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item without-box-shadow",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small2.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$99"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Vue JS 2 - The Complete Guide (incl. Vue Router & Vuex)"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 14 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 100 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item without-box-shadow",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small3.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$49"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            children: "The Python Bible\u2122 | Everything You Need to Program in Python"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 11 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 104 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item without-box-shadow",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small4.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$79"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            children: "Mathematical Foundation For Machine Learning and AI"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 14 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 100 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item without-box-shadow",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small6.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$59"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            children: "The Ultimate Drawing Course - Beginner to Advanced"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 09 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 150 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "single-courses-item without-box-shadow",
                                    children: Object(a.jsxs)("div", {
                                        className: "row align-items-center",
                                        children: [Object(a.jsx)("div", {
                                            className: "col-lg-4 col-md-4",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-image",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/courses-small/courses-small7.jpg",
                                                    alt: "image"
                                                }), Object(a.jsx)(t.a, {
                                                    href: "/single-courses-1",
                                                    children: Object(a.jsx)("a", {
                                                        className: "link-btn"
                                                    })
                                                })]
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "col-lg-8 col-md-8",
                                            children: Object(a.jsxs)("div", {
                                                className: "courses-content",
                                                children: [Object(a.jsx)("a", {
                                                    href: "#",
                                                    className: "fav",
                                                    children: Object(a.jsx)("i", {
                                                        className: "flaticon-heart"
                                                    })
                                                }), Object(a.jsx)("span", {
                                                    className: "price",
                                                    children: "$89"
                                                }), Object(a.jsx)("h3", {
                                                    children: Object(a.jsx)(t.a, {
                                                        href: "/single-courses-1",
                                                        children: Object(a.jsx)("a", {
                                                            children: "PyTorch: Deep Learning and Artificial Intelligence"
                                                        })
                                                    })
                                                }), Object(a.jsxs)("ul", {
                                                    className: "courses-content-footer d-flex justify-content-between align-items-center",
                                                    children: [Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-agenda"
                                                        }), " 20 Lessons"]
                                                    }), Object(a.jsxs)("li", {
                                                        children: [Object(a.jsx)("i", {
                                                            className: "flaticon-people"
                                                        }), " 200 Students"]
                                                    })]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-12 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "courses-info",
                                    children: [Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(a.jsx)("i", {
                                                className: "flaticon-user"
                                            }), "View All Courses", Object(a.jsx)("span", {})]
                                        })
                                    }), Object(a.jsxs)("p", {
                                        children: ["Get into details now?\u200b ", Object(a.jsx)(t.a, {
                                            href: "/courses-1",
                                            children: Object(a.jsx)("a", {
                                                children: "PM Master\u2019s Program"
                                            })
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        "1GiN": function(e, s, c) {
            "use strict";
            var a = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "subscribe-area ptb-100",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "subscribe-content",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Go At Your Own Pace"
                            }), Object(a.jsx)("h2", {
                                children: "Subscribe To Our Newsletter"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            }), Object(a.jsxs)("form", {
                                className: "newsletter-form",
                                children: [Object(a.jsx)("input", {
                                    type: "text",
                                    className: "input-newsletter",
                                    placeholder: "Enter your email address",
                                    name: "EMAIL",
                                    required: !0
                                }), Object(a.jsxs)("button", {
                                    type: "submit",
                                    className: "default-btn",
                                    children: [Object(a.jsx)("i", {
                                        className: "flaticon-user"
                                    }), " Subscribe Now ", Object(a.jsx)("span", {})]
                                })]
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape4",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape13",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape12.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape14",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape13.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape15",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape14.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        AjPI: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "overview-area ptb-100",
                    children: [Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "overview-box",
                            children: [Object(a.jsxs)("div", {
                                className: "overview-content",
                                children: [Object(a.jsx)("span", {
                                    className: "sub-title",
                                    children: "Distance Learning"
                                }), Object(a.jsx)("h2", {
                                    children: "Feel Like You Are Attending Your classNamees Physically!"
                                }), Object(a.jsx)("p", {
                                    children: "eCademy training programs can bring you a super exciting experience of learning through online! You never face any negative experience while enjoying your classNamees virtually by sitting in your comfort zone. Our flexible learning initiatives will help you to learn better and quicker than the traditional ways of learning skills."
                                }), Object(a.jsx)(t.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        className: "default-btn",
                                        children: [Object(a.jsx)("i", {
                                            className: "flaticon-user"
                                        }), " Get Started Now ", Object(a.jsx)("span", {})]
                                    })
                                })]
                            }), Object(a.jsx)("div", {
                                className: "overview-image",
                                children: Object(a.jsx)("img", {
                                    src: "/images/overview-img1.png",
                                    alt: "image"
                                })
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "overview-box",
                            children: [Object(a.jsx)("div", {
                                className: "overview-image",
                                children: Object(a.jsx)("img", {
                                    src: "/images/overview-img2.png",
                                    alt: "image"
                                })
                            }), Object(a.jsxs)("div", {
                                className: "overview-content",
                                children: [Object(a.jsx)("span", {
                                    className: "sub-title",
                                    children: "eCademy Mobile App"
                                }), Object(a.jsx)("h2", {
                                    children: "Access From Your Mobile, Learn Any Time Any Where"
                                }), Object(a.jsx)("p", {
                                    children: "eCademy training programs can bring you a super exciting experience of learning through online! You never face any negative experience while enjoying your classNamees virtually by sitting in your comfort zone. Our flexible learning initiatives will help you to learn better and quicker than the traditional ways of learning skills."
                                }), Object(a.jsxs)("div", {
                                    className: "btn-box",
                                    children: [Object(a.jsx)(t.a, {
                                        href: "#",
                                        children: Object(a.jsxs)("a", {
                                            className: "playstore-btn",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/playstore.png",
                                                alt: "image"
                                            }), "GET IT ON", Object(a.jsx)("span", {
                                                children: "Google Play"
                                            })]
                                        })
                                    }), Object(a.jsx)(t.a, {
                                        href: "#",
                                        children: Object(a.jsxs)("a", {
                                            className: "applestore-btn",
                                            children: [Object(a.jsx)("img", {
                                                src: "/images/applestore.png",
                                                alt: "image"
                                            }), "GET IT ON", Object(a.jsx)("span", {
                                                children: "Apple Store"
                                            })]
                                        })
                                    })]
                                })]
                            })]
                        })]
                    }), Object(a.jsx)("div", {
                        className: "shape2",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape2.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape3",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape4",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        CLvZ: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "events-area bg-fffaf3 pt-100 pb-70",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Events"
                            }), Object(a.jsx)("h2", {
                                children: "Our Upcoming Events"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(a.jsxs)("div", {
                                        className: "image",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/events/events1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            className: "date",
                                            children: "Wed, 20 May, 2020"
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "Global Conference on Business Management"
                                                })
                                            })
                                        }), Object(a.jsxs)("span", {
                                            className: "location",
                                            children: [Object(a.jsx)("i", {
                                                className: "bx bx-map"
                                            }), " Vancover, Canada"]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(a.jsxs)("div", {
                                        className: "image",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/events/events2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            className: "date",
                                            children: "Tue, 19 May, 2020"
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "International Conference on Teacher Education"
                                                })
                                            })
                                        }), Object(a.jsxs)("span", {
                                            className: "location",
                                            children: [Object(a.jsx)("i", {
                                                className: "bx bx-map"
                                            }), "Sydney, Australia"]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(a.jsxs)("div", {
                                        className: "image",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/events/events3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            className: "date",
                                            children: "Mon, 18 May, 2020"
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "International Conference on Special Needs Education"
                                                })
                                            })
                                        }), Object(a.jsxs)("span", {
                                            className: "location",
                                            children: [Object(a.jsx)("i", {
                                                className: "bx bx-map"
                                            }), "Istanbul, Turkey"]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(a.jsxs)("div", {
                                        className: "image",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/events/events4.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            className: "date",
                                            children: "Sun, 17 May, 2020"
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)("a", {
                                                href: "#",
                                                children: "Global Conference on Business Management"
                                            })
                                        }), Object(a.jsxs)("span", {
                                            className: "location",
                                            children: [Object(a.jsx)("i", {
                                                className: "bx bx-map"
                                            }), "Athens, Greece"]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(a.jsxs)("div", {
                                        className: "image",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/events/events5.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            className: "date",
                                            children: "Sat, 16 May, 2020"
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "International Conference on Educational Administration"
                                                })
                                            })
                                        }), Object(a.jsxs)("span", {
                                            className: "location",
                                            children: [Object(a.jsx)("i", {
                                                className: "bx bx-map"
                                            }), "Rome, Italy"]
                                        })]
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-events-box",
                                    children: [Object(a.jsxs)("div", {
                                        className: "image",
                                        children: [Object(a.jsx)(t.a, {
                                            href: "#",
                                            children: Object(a.jsx)("a", {
                                                className: "d-block",
                                                children: Object(a.jsx)("img", {
                                                    src: "/images/events/events6.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(a.jsx)("span", {
                                            className: "date",
                                            children: "Fri, 15 May, 2020"
                                        })]
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: Object(a.jsx)(t.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    children: "International Conference on Education and Pedagogy"
                                                })
                                            })
                                        }), Object(a.jsxs)("span", {
                                            className: "location",
                                            children: [Object(a.jsx)("i", {
                                                className: "bx bx-map"
                                            }), "Athens, Greece"]
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        FuXQ: function(e, s, c) {
            "use strict";
            var a = c("rePB"),
                i = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                n = c.n(l),
                r = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(a.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(r)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                m = {
                    loop: !0,
                    nav: !0,
                    margin: 60,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 3,
                            margin: 20
                        },
                        600: {
                            items: 3
                        },
                        768: {
                            items: 4,
                            margin: 30
                        },
                        1e3: {
                            items: 6
                        }
                    }
                };
            s.a = function() {
                var e = n.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    a = s[1];
                return n.a.useEffect((function() {
                    a(!0)
                }), []), Object(i.jsx)("div", {
                    className: "partner-area bg-fe4a55 ptb-70",
                    children: Object(i.jsx)("div", {
                        className: "container",
                        children: c ? Object(i.jsxs)(o, d(d({
                            className: "partner-slides owl-carousel owl-theme"
                        }, m), {}, {
                            children: [Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner7.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner8.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner9.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner10.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner11.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner12.png",
                                    alt: "image"
                                })
                            }), Object(i.jsx)("div", {
                                className: "single-partner-item",
                                children: Object(i.jsx)("img", {
                                    src: "/images/partner/partner8.png",
                                    alt: "image"
                                })
                            })]
                        })) : ""
                    })
                })
            }
        },
        JcBV: function(e, s, c) {
            "use strict";
            var a = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "funfacts-area bg-fffaf3",
                    children: Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "1926"
                                    }), Object(a.jsx)("p", {
                                        children: "Finished Sessions"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "3279"
                                    }), Object(a.jsx)("p", {
                                        children: "Enrolled Learners"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "250"
                                    }), Object(a.jsx)("p", {
                                        children: "Online Instructors"
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-funfacts-item",
                                    children: [Object(a.jsx)("h3", {
                                        children: "100%"
                                    }), Object(a.jsx)("p", {
                                        children: "Satisfaction Rate"
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        QccS: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "boxes-area boxes-style-two bg-f5f7fa",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-box-item",
                                    children: [Object(a.jsx)("div", {
                                        className: "image",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/boxes-img1.png",
                                            alt: "image"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        children: "Web Development"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consecteur adipiscing elit, sed do eiusmod tempor."
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now!"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-box-item",
                                    children: [Object(a.jsx)("div", {
                                        className: "image",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/boxes-img2.png",
                                            alt: "image"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        children: "UX/UI Design"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consecteur adipiscing elit, sed do eiusmod tempor."
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now!"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                children: Object(a.jsxs)("div", {
                                    className: "single-box-item",
                                    children: [Object(a.jsx)("div", {
                                        className: "image",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/boxes-img3.png",
                                            alt: "image"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        children: "App Development"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consecteur adipiscing elit, sed do eiusmod tempor."
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn",
                                            children: "Start Now!"
                                        })
                                    })]
                                })
                            })]
                        }), Object(a.jsx)("div", {
                            className: "boxes-info",
                            children: Object(a.jsxs)("p", {
                                children: ["If you want more? ", Object(a.jsx)(t.a, {
                                    href: "/courses-1",
                                    children: Object(a.jsx)("a", {
                                        children: "View More Courses"
                                    })
                                })]
                            })
                        })]
                    })
                })
            }
        },
        Y5ZX: function(e, s, c) {
            "use strict";
            var a = c("rePB"),
                i = c("nKUr"),
                t = c("ODXe"),
                l = c("q1tI"),
                n = c.n(l),
                r = c("Vvt1");

            function j(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    s && (a = a.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, a)
                }
                return c
            }

            function d(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? j(Object(c), !0).forEach((function(s) {
                        Object(a.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : j(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var o = c.n(r)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                m = {
                    loop: !0,
                    nav: !1,
                    dots: !0,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='bx bx-chevron-left'></i>", "<i class='bx bx-chevron-right'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 1
                        },
                        768: {
                            items: 2
                        },
                        1200: {
                            items: 2
                        }
                    }
                };
            s.a = function() {
                var e = n.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    a = s[1];
                return n.a.useEffect((function() {
                    a(!0)
                }), []), Object(i.jsxs)("div", {
                    className: "feedback-area bg-fffaf3 ptb-100",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: c ? Object(i.jsxs)(o, d(d({
                            className: "feedback-slides-two owl-carousel owl-theme"
                        }, m), {}, {
                            children: [Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "John Smith"
                                        }), Object(i.jsx)("span", {
                                            children: "Python Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user2.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Sarah Taylor"
                                        }), Object(i.jsx)("span", {
                                            children: "PHP Developer"
                                        })]
                                    })]
                                })]
                            }), Object(i.jsxs)("div", {
                                className: "single-feedback-box",
                                children: [Object(i.jsx)("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore."
                                }), Object(i.jsxs)("div", {
                                    className: "client-info d-flex align-items-center",
                                    children: [Object(i.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        className: "rounded-circle",
                                        alt: "image"
                                    }), Object(i.jsxs)("div", {
                                        className: "title",
                                        children: [Object(i.jsx)("h3", {
                                            children: "David Warner"
                                        }), Object(i.jsx)("span", {
                                            children: "QA Developer"
                                        })]
                                    })]
                                })]
                            })]
                        })) : ""
                    }), Object(i.jsx)("div", {
                        className: "divider2"
                    }), Object(i.jsx)("div", {
                        className: "divider3"
                    }), Object(i.jsx)("div", {
                        className: "shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape2.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape3",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape3.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape4",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape4.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "shape9",
                        children: Object(i.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        bmk4: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "about-area bg-f5f7fa ptb-100",
                    children: Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "about-image text-center",
                                    children: Object(a.jsx)("img", {
                                        src: "/images/about-img10.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "about-content",
                                    children: [Object(a.jsx)("span", {
                                        className: "sub-title",
                                        children: "About Us"
                                    }), Object(a.jsx)("h2", {
                                        children: "Develop Your Skills, Learn Something New, and Grow Your Skills From Anywhere in the World!"
                                    }), Object(a.jsx)("p", {
                                        children: "We understand better that online-based learning can make a significant change to reach students from all over the world! Giving options to learn better always can offer the best outcomes!"
                                    }), Object(a.jsxs)("ul", {
                                        className: "features-list",
                                        children: [Object(a.jsx)("li", {
                                            children: Object(a.jsxs)("span", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-experience"
                                                }), " Skiled Teachers"]
                                            })
                                        }), Object(a.jsx)("li", {
                                            children: Object(a.jsxs)("span", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-time-left"
                                                }), " Afordable Courses"]
                                            })
                                        }), Object(a.jsx)("li", {
                                            children: Object(a.jsxs)("span", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-tutorials"
                                                }), " Efficient & Flexible"]
                                            })
                                        }), Object(a.jsx)("li", {
                                            children: Object(a.jsxs)("span", {
                                                children: [Object(a.jsx)("i", {
                                                    className: "flaticon-self-growth"
                                                }), " Lifetime Access"]
                                            })
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(a.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(a.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Join For Free ", Object(a.jsx)("span", {})]
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                })
            }
        },
        hXH4: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "hero-banner-area",
                    children: [Object(a.jsx)("div", {
                        className: "container-fluid",
                        children: Object(a.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsxs)("div", {
                                    className: "hero-banner-content",
                                    children: [Object(a.jsx)("h1", {
                                        children: "Build Development Skills With eCademy Any Time, Anywhere"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(a.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(a.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(a.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Join For Free ", Object(a.jsx)("span", {})]
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "hero-banner-image",
                                    children: Object(a.jsx)("img", {
                                        src: "/images/main-banner3.png",
                                        alt: "image"
                                    })
                                })
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "banner-shape19",
                        children: Object(a.jsx)("img", {
                            src: "/images/banner-shape20.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "divider"
                    })]
                })
            }
        },
        rePB: function(e, s, c) {
            "use strict";

            function a(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return a
            }))
        },
        "rs0+": function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                i = (c("q1tI"), c("YFqc")),
                t = c.n(i);
            s.a = function() {
                return Object(a.jsx)("div", {
                    className: "categories-area ptb-100",
                    children: Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Categories"
                            }), Object(a.jsx)("h2", {
                                children: "Top Categories"
                            }), Object(a.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "row",
                            children: [Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie1.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Development"
                                        }), Object(a.jsx)("span", {
                                            children: "10 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie2.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Business"
                                        }), Object(a.jsx)("span", {
                                            children: "20 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie3.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "IT & Software"
                                        }), Object(a.jsx)("span", {
                                            children: "15 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie4.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Design"
                                        }), Object(a.jsx)("span", {
                                            children: "11 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie5.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Lifestyle"
                                        }), Object(a.jsx)("span", {
                                            children: "10 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie6.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Photo & Flim"
                                        }), Object(a.jsx)("span", {
                                            children: "12 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie7.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Animation"
                                        }), Object(a.jsx)("span", {
                                            children: "05 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(a.jsxs)("div", {
                                    className: "single-categories-box",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/categories/categorie8.jpg",
                                        alt: "image"
                                    }), Object(a.jsxs)("div", {
                                        className: "content",
                                        children: [Object(a.jsx)("h3", {
                                            children: "Writing"
                                        }), Object(a.jsx)("span", {
                                            children: "20 Courses"
                                        })]
                                    }), Object(a.jsx)(t.a, {
                                        href: "/courses-1",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                })
                            }), Object(a.jsx)("div", {
                                className: "col-lg-12 col-sm-12 col-md-12",
                                children: Object(a.jsx)("div", {
                                    className: "categories-btn-box",
                                    children: Object(a.jsx)(t.a, {
                                        href: "/categories",
                                        children: Object(a.jsxs)("a", {
                                            className: "default-btn",
                                            children: [Object(a.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " View All Categories ", Object(a.jsx)("span", {})]
                                        })
                                    })
                                })
                            })]
                        })]
                    })
                })
            }
        }
    }
]);