(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [14], {
        "+4qw": function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsx)("div", {
                    className: "blog-area pt-100 pb-70",
                    children: Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Our News"
                            }), Object(i.jsx)("h2", {
                                className: "font-weight-black",
                                children: "Check Out Our Latest Blog"
                            }), Object(i.jsx)("p", {
                                children: "We always give extra care to our student's skills improvements and feel excited to share our latest research and learnings!"
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-item",
                                    children: [Object(i.jsxs)("div", {
                                        className: "post-image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "/single-blog-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/blog/kindergarten-img1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "link-btn"
                                            })
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "category",
                                                children: "Preschool"
                                            })
                                        }), Object(i.jsx)("h3", {
                                            className: "font-weight-black",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-blog-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Why Play Is Important in Preschool and Early"
                                                })
                                            })
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-item",
                                    children: [Object(i.jsxs)("div", {
                                        className: "post-image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "/single-blog-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/blog/kindergarten-img2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "link-btn"
                                            })
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)("a", {
                                            href: "#",
                                            className: "category",
                                            children: "Books"
                                        }), Object(i.jsx)("h3", {
                                            className: "font-weight-black",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-blog-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Best Three Billy Goats Gruff Books for Preschool"
                                                })
                                            })
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3",
                                children: Object(i.jsxs)("div", {
                                    className: "single-blog-item",
                                    children: [Object(i.jsxs)("div", {
                                        className: "post-image",
                                        children: [Object(i.jsx)(t.a, {
                                            href: "/single-blog-1",
                                            children: Object(i.jsx)("a", {
                                                className: "d-block",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/blog/kindergarten-img3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)(t.a, {
                                            href: "#",
                                            children: Object(i.jsx)("a", {
                                                className: "link-btn"
                                            })
                                        })]
                                    }), Object(i.jsxs)("div", {
                                        className: "post-content",
                                        children: [Object(i.jsx)("a", {
                                            href: "#",
                                            className: "category",
                                            children: "Theme"
                                        }), Object(i.jsx)("h3", {
                                            className: "font-weight-black",
                                            children: Object(i.jsx)(t.a, {
                                                href: "/single-blog-1",
                                                children: Object(i.jsx)("a", {
                                                    children: "Flashlight Literacy Activity for Your Camping Theme"
                                                })
                                            })
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        "0FZq": function(e, s, c) {
            "use strict";
            var i = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "subscribe-area bg-eee8df ptb-70",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "subscribe-image",
                                    children: Object(i.jsx)("img", {
                                        src: "/images/subscribe-img3.png",
                                        alt: "image"
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "subscribe-content text-left",
                                    children: [Object(i.jsx)("h2", {
                                        className: "font-weight-black",
                                        children: "Subscribe To Our Newsletter"
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(i.jsxs)("form", {
                                        className: "newsletter-form",
                                        children: [Object(i.jsx)("input", {
                                            type: "text",
                                            className: "input-newsletter",
                                            placeholder: "Enter your email address",
                                            name: "EMAIL",
                                            required: !0
                                        }), Object(i.jsxs)("button", {
                                            type: "submit",
                                            className: "default-btn",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Subscribe Now ", Object(i.jsx)("span", {})]
                                        })]
                                    })]
                                })
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape19",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape19.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape20",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape20.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        "6z4z": function(e, s, c) {
            "use strict";
            var i = c("nKUr");
            c("q1tI");
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "selected-ages-area pt-100 pb-70",
                    children: [Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Go At Your Own Pace"
                            }), Object(i.jsx)("h2", {
                                className: "font-weight-black",
                                children: "Ages We Meet Kids Where They Are"
                            }), Object(i.jsx)("p", {
                                children: "Explore all of our courses and pick your suitable ones to enroll and start learning with us! We ensure that you will never regret it!"
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-selected-ages-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "image",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/selected-ages/selected-age1.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "content",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Infants"
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                        }), Object(i.jsx)("span", {
                                            className: "ages-number",
                                            children: "3 - 12 Months"
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-selected-ages-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "image",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/selected-ages/selected-age2.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "content",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Toddler"
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                        }), Object(i.jsx)("span", {
                                            className: "ages-number",
                                            children: "1 - 3 Years"
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-selected-ages-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "image",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/selected-ages/selected-age3.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "content",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Preschool"
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                        }), Object(i.jsx)("span", {
                                            className: "ages-number",
                                            children: "3 - 5 Years"
                                        })]
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-3 col-sm-6 col-md-6",
                                children: Object(i.jsxs)("div", {
                                    className: "single-selected-ages-box",
                                    children: [Object(i.jsx)("div", {
                                        className: "image",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/selected-ages/selected-age4.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsxs)("div", {
                                        className: "content",
                                        children: [Object(i.jsx)("h3", {
                                            children: "Flex-Care"
                                        }), Object(i.jsx)("p", {
                                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                        }), Object(i.jsx)("span", {
                                            className: "ages-number",
                                            children: "5 - 12 Years"
                                        })]
                                    })]
                                })
                            })]
                        })]
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape15",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape15.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape16",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape16.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        EIh1: function(e, s, c) {
            "use strict";
            var i = c("rePB"),
                a = c("nKUr"),
                t = c("ODXe"),
                n = c("q1tI"),
                l = c.n(n),
                r = c("Vvt1");

            function d(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    s && (i = i.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, i)
                }
                return c
            }

            function j(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? d(Object(c), !0).forEach((function(s) {
                        Object(i.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : d(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var m = c.n(r)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                o = {
                    loop: !0,
                    nav: !0,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 0,
                    navText: ["<i class='flaticon-chevron'></i>", "<i class='flaticon-right-arrow'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 2
                        },
                        768: {
                            items: 2
                        },
                        992: {
                            items: 3
                        },
                        1200: {
                            items: 4
                        },
                        1550: {
                            items: 5
                        }
                    }
                };
            s.a = function() {
                var e = l.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    i = s[1];
                return l.a.useEffect((function() {
                    i(!0)
                }), []), Object(a.jsxs)("div", {
                    className: "feedback-area bg-6dbbbd pt-100 pb-70",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Testimonials"
                            }), Object(a.jsx)("h2", {
                                className: "font-weight-black",
                                children: "Our Guardian Feedback"
                            }), Object(a.jsx)("p", {
                                children: "We always give extra care to our student's skills improvements and feel excited to share our latest research and learnings!"
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "container-fluid",
                        children: c ? Object(a.jsxs)(m, j(j({
                            className: "feedback-slides-three owl-carousel owl-theme"
                        }, o), {}, {
                            children: [Object(a.jsxs)("div", {
                                className: "single-kindergarten-feedback-item",
                                children: [Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/feedback-shape.png",
                                        alt: "image"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit aadamet45, consectetur adipiscing elit elit3, sed do eiusmod tempor incididunt ut labore et dolore magna. Eiusmod incididunt."
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "client-info",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user1.jpg",
                                        alt: "image"
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "John Smith"
                                    }), Object(a.jsx)("span", {
                                        children: "Guardian"
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-feedback-item",
                                children: [Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/feedback-shape.png",
                                        alt: "image"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit aadamet45, consectetur adipiscing elit elit3, sed do eiusmod tempor incididunt ut labore et dolore magna. Eiusmod incididunt."
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "client-info",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user2.jpg",
                                        alt: "image"
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "Sarah Taylor"
                                    }), Object(a.jsx)("span", {
                                        children: "Guardian"
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-feedback-item",
                                children: [Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/feedback-shape.png",
                                        alt: "image"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit aadamet45, consectetur adipiscing elit elit3, sed do eiusmod tempor incididunt ut labore et dolore magna. Eiusmod incididunt."
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "client-info",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user3.jpg",
                                        alt: "image"
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "David Smith"
                                    }), Object(a.jsx)("span", {
                                        children: "Guardian"
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-feedback-item",
                                children: [Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/feedback-shape.png",
                                        alt: "image"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit aadamet45, consectetur adipiscing elit elit3, sed do eiusmod tempor incididunt ut labore et dolore magna. Eiusmod incididunt."
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "client-info",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user4.jpg",
                                        alt: "image"
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "James Andy"
                                    }), Object(a.jsx)("span", {
                                        children: "Guardian"
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-feedback-item",
                                children: [Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/feedback-shape.png",
                                        alt: "image"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit aadamet45, consectetur adipiscing elit elit3, sed do eiusmod tempor incididunt ut labore et dolore magna. Eiusmod incididunt."
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "client-info",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user5.jpg",
                                        alt: "image"
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "Max Lucy"
                                    }), Object(a.jsx)("span", {
                                        children: "Guardian"
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-feedback-item",
                                children: [Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/feedback-shape.png",
                                        alt: "image"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit aadamet45, consectetur adipiscing elit elit3, sed do eiusmod tempor incididunt ut labore et dolore magna. Eiusmod incididunt."
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "client-info",
                                    children: [Object(a.jsx)("img", {
                                        src: "/images/user6.jpg",
                                        alt: "image"
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "Harry Zayn"
                                    }), Object(a.jsx)("span", {
                                        children: "Guardian"
                                    })]
                                })]
                            })]
                        })) : ""
                    }), Object(a.jsx)("div", {
                        className: "kindergarten-shape13",
                        children: Object(a.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape13.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "kindergarten-shape14",
                        children: Object(a.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape14.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        MI1G: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "about-area ptb-100",
                    children: [Object(i.jsx)("div", {
                        className: "container",
                        children: Object(i.jsxs)("div", {
                            className: "row align-items-center",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "kindergarten-about-image",
                                    children: [Object(i.jsxs)("div", {
                                        className: "main-image",
                                        children: [Object(i.jsx)("img", {
                                            src: "/images/kindergarten-about-img1.png",
                                            alt: "image"
                                        }), Object(i.jsx)("img", {
                                            src: "/images/kindergarten-about-img2.png",
                                            alt: "image"
                                        })]
                                    }), Object(i.jsx)("div", {
                                        className: "shape",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/kite1.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "about-content",
                                    children: [Object(i.jsx)("span", {
                                        className: "sub-title",
                                        children: "About Us"
                                    }), Object(i.jsx)("h2", {
                                        className: "font-weight-black",
                                        children: "We are Kindergarten & Childhood is our Passion"
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis."
                                    }), Object(i.jsxs)("ul", {
                                        className: "about-list",
                                        children: [Object(i.jsx)("li", {
                                            children: Object(i.jsxs)("span", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Transportation"]
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsxs)("span", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Outdoor Games"]
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsxs)("span", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Nutritious Food"]
                                            })
                                        }), Object(i.jsx)("li", {
                                            children: Object(i.jsxs)("span", {
                                                children: [Object(i.jsx)("i", {
                                                    className: "bx bx-check"
                                                }), " Best Care"]
                                            })
                                        })]
                                    }), Object(i.jsx)(t.a, {
                                        href: "/about-5",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn-style-two",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " More About Us"]
                                        })
                                    })]
                                })
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape7",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape7.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape8",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape8.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        bD6z: function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "events-area bg-shape bg-eee8df",
                    children: [Object(i.jsxs)("div", {
                        className: "container",
                        children: [Object(i.jsxs)("div", {
                            className: "section-title",
                            children: [Object(i.jsx)("span", {
                                className: "sub-title",
                                children: "Events"
                            }), Object(i.jsx)("h2", {
                                className: "font-weight-black",
                                children: "Our Upcoming Events"
                            }), Object(i.jsx)("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            })]
                        }), Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12 col-sm-6",
                                children: Object(i.jsx)("div", {
                                    className: "events-box",
                                    children: Object(i.jsxs)("div", {
                                        className: "row m-0",
                                        children: [Object(i.jsx)("div", {
                                            className: "col-lg-4 col-md-5 p-0",
                                            children: Object(i.jsx)("div", {
                                                className: "image bg1",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/events/kindergarten-img1.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-8 col-md-7 p-0",
                                            children: Object(i.jsxs)("div", {
                                                className: "content",
                                                children: [Object(i.jsxs)("div", {
                                                    className: "date",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/rectangle1.png",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Wed, 03 June, 2020"
                                                    })]
                                                }), Object(i.jsx)("h3", {
                                                    className: "font-weight-black",
                                                    children: Object(i.jsx)(t.a, {
                                                        href: "#",
                                                        children: Object(i.jsx)("a", {
                                                            children: "Music Conference"
                                                        })
                                                    })
                                                }), Object(i.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do."
                                                }), Object(i.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(i.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Vancover, Canada"]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12 col-sm-6",
                                children: Object(i.jsx)("div", {
                                    className: "events-box",
                                    children: Object(i.jsxs)("div", {
                                        className: "row m-0",
                                        children: [Object(i.jsx)("div", {
                                            className: "col-lg-4 col-md-5 p-0",
                                            children: Object(i.jsx)("div", {
                                                className: "image bg2",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/events/kindergarten-img2.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-8 col-md-7 p-0",
                                            children: Object(i.jsxs)("div", {
                                                className: "content",
                                                children: [Object(i.jsxs)("div", {
                                                    className: "date",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/rectangle2.png",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Thu, 04 June, 2020"
                                                    })]
                                                }), Object(i.jsx)("h3", {
                                                    className: "font-weight-black",
                                                    children: Object(i.jsx)(t.a, {
                                                        href: "#",
                                                        children: Object(i.jsx)("a", {
                                                            children: "Paper Plates Art"
                                                        })
                                                    })
                                                }), Object(i.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do."
                                                }), Object(i.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(i.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Sydney, Australia"]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12 col-sm-6",
                                children: Object(i.jsx)("div", {
                                    className: "events-box",
                                    children: Object(i.jsxs)("div", {
                                        className: "row m-0",
                                        children: [Object(i.jsx)("div", {
                                            className: "col-lg-4 col-md-5 p-0",
                                            children: Object(i.jsx)("div", {
                                                className: "image bg3",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/events/kindergarten-img3.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-8 col-md-7 p-0",
                                            children: Object(i.jsxs)("div", {
                                                className: "content",
                                                children: [Object(i.jsxs)("div", {
                                                    className: "date",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/rectangle3.png",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Fri, 05 June, 2020"
                                                    })]
                                                }), Object(i.jsx)("h3", {
                                                    className: "font-weight-black",
                                                    children: Object(i.jsx)(t.a, {
                                                        href: "#",
                                                        children: Object(i.jsx)("a", {
                                                            children: "Imagination classNamees"
                                                        })
                                                    })
                                                }), Object(i.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do."
                                                }), Object(i.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(i.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), "Istanbul, Turkey"]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12 col-sm-6",
                                children: Object(i.jsx)("div", {
                                    className: "events-box",
                                    children: Object(i.jsxs)("div", {
                                        className: "row m-0",
                                        children: [Object(i.jsx)("div", {
                                            className: "col-lg-4 col-md-5 p-0",
                                            children: Object(i.jsx)("div", {
                                                className: "image bg4",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/events/kindergarten-img4.jpg",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-8 col-md-7 p-0",
                                            children: Object(i.jsxs)("div", {
                                                className: "content",
                                                children: [Object(i.jsxs)("div", {
                                                    className: "date",
                                                    children: [Object(i.jsx)("img", {
                                                        src: "/images/rectangle4.png",
                                                        alt: "image"
                                                    }), Object(i.jsx)("span", {
                                                        children: "Sat, 06 June, 2020"
                                                    })]
                                                }), Object(i.jsx)("h3", {
                                                    className: "font-weight-black",
                                                    children: Object(i.jsx)(t.a, {
                                                        href: "#",
                                                        children: Object(i.jsx)("a", {
                                                            children: "Number Matching"
                                                        })
                                                    })
                                                }), Object(i.jsx)("p", {
                                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do."
                                                }), Object(i.jsxs)("span", {
                                                    className: "location",
                                                    children: [Object(i.jsx)("i", {
                                                        className: "bx bx-map"
                                                    }), " New York, USA"]
                                                })]
                                            })
                                        })]
                                    })
                                })
                            })]
                        })]
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape17",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape17.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape18",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape18.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        ffDd: function(e, s, c) {
            "use strict";
            var i = c("rePB"),
                a = c("nKUr"),
                t = c("ODXe"),
                n = c("q1tI"),
                l = c.n(n),
                r = c("Vvt1");

            function d(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    s && (i = i.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, i)
                }
                return c
            }

            function j(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? d(Object(c), !0).forEach((function(s) {
                        Object(i.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : d(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var m = c.n(r)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                o = {
                    loop: !0,
                    nav: !0,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='flaticon-chevron'></i>", "<i class='flaticon-right-arrow'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 2
                        },
                        768: {
                            items: 2
                        },
                        992: {
                            items: 3
                        }
                    }
                };
            s.a = function() {
                var e = l.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    i = s[1];
                return l.a.useEffect((function() {
                    i(!0)
                }), []), Object(a.jsxs)("div", {
                    className: "kindergarten-services-area bg-f7ebeb pt-100",
                    children: [Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Our Services"
                            }), Object(a.jsx)("h2", {
                                className: "font-weight-black",
                                children: "Best Services for Kids"
                            }), Object(a.jsx)("p", {
                                children: "Explore all of our courses and pick your suitable ones to enroll and start learning with us! We ensure that you will never regret it!"
                            })]
                        }), c ? Object(a.jsxs)(m, j(j({
                            className: "services-slides owl-carousel owl-theme"
                        }, o), {}, {
                            children: [Object(a.jsxs)("div", {
                                className: "single-kindergarten-services-box",
                                children: [Object(a.jsx)("img", {
                                    src: "/images/box-shape1.png",
                                    alt: "image"
                                }), Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("div", {
                                        className: "icon",
                                        children: Object(a.jsx)("i", {
                                            className: "flaticon-guitar"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "Music Training"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, ipsum adipiscing elit elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua quis ipsum."
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-services-box",
                                children: [Object(a.jsx)("img", {
                                    src: "/images/box-shape2.png",
                                    alt: "image"
                                }), Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("div", {
                                        className: "icon",
                                        children: Object(a.jsx)("i", {
                                            className: "flaticon-experience"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "Sports Training"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, ipsum adipiscing elit elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua quis ipsum."
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-services-box",
                                children: [Object(a.jsx)("img", {
                                    src: "/images/box-shape3.png",
                                    alt: "image"
                                }), Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("div", {
                                        className: "icon",
                                        children: Object(a.jsx)("i", {
                                            className: "flaticon-artist"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "Art Training"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, ipsum adipiscing elit elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua quis ipsum."
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-services-box",
                                children: [Object(a.jsx)("img", {
                                    src: "/images/box-shape2.png",
                                    alt: "image"
                                }), Object(a.jsxs)("div", {
                                    className: "content",
                                    children: [Object(a.jsx)("div", {
                                        className: "icon",
                                        children: Object(a.jsx)("i", {
                                            className: "flaticon-translation"
                                        })
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: "Language Training"
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, ipsum adipiscing elit elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua quis ipsum."
                                    })]
                                })]
                            })]
                        })) : "", Object(a.jsx)("div", {
                            className: "kids-kite-image",
                            children: Object(a.jsx)("img", {
                                src: "/images/kids-with-kite.png",
                                alt: "image"
                            })
                        })]
                    }), Object(a.jsx)("div", {
                        className: "kindergarten-shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape9.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "kindergarten-shape10",
                        children: Object(a.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape10.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        rePB: function(e, s, c) {
            "use strict";

            function i(e, s, c) {
                return s in e ? Object.defineProperty(e, s, {
                    value: c,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[s] = c, e
            }
            c.d(s, "a", (function() {
                return i
            }))
        },
        v6UB: function(e, s, c) {
            "use strict";
            var i = c("rePB"),
                a = c("nKUr"),
                t = c("ODXe"),
                n = c("q1tI"),
                l = c.n(n),
                r = c("YFqc"),
                d = c.n(r),
                j = c("Vvt1");

            function m(e, s) {
                var c = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    s && (i = i.filter((function(s) {
                        return Object.getOwnPropertyDescriptor(e, s).enumerable
                    }))), c.push.apply(c, i)
                }
                return c
            }

            function o(e) {
                for (var s = 1; s < arguments.length; s++) {
                    var c = null != arguments[s] ? arguments[s] : {};
                    s % 2 ? m(Object(c), !0).forEach((function(s) {
                        Object(i.a)(e, s, c[s])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(c)) : m(Object(c)).forEach((function(s) {
                        Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(c, s))
                    }))
                }
                return e
            }
            var b = c.n(j)()((function() {
                    return c.e(3).then(c.t.bind(null, "Rst5", 7))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return ["Rst5"]
                        },
                        modules: ["react-owl-carousel3"]
                    }
                }),
                g = {
                    loop: !1,
                    nav: !0,
                    dots: !1,
                    autoplayHoverPause: !0,
                    autoplay: !0,
                    margin: 30,
                    navText: ["<i class='flaticon-chevron'></i>", "<i class='flaticon-right-arrow'></i>"],
                    responsive: {
                        0: {
                            items: 1
                        },
                        576: {
                            items: 1
                        },
                        768: {
                            items: 2
                        },
                        992: {
                            items: 3
                        }
                    }
                };
            s.a = function() {
                var e = l.a.useState(!1),
                    s = Object(t.a)(e, 2),
                    c = s[0],
                    i = s[1];
                return l.a.useEffect((function() {
                    i(!0)
                }), []), Object(a.jsxs)("div", {
                    className: "courses-area pt-100 pb-70",
                    children: [Object(a.jsxs)("div", {
                        className: "container",
                        children: [Object(a.jsxs)("div", {
                            className: "section-title",
                            children: [Object(a.jsx)("span", {
                                className: "sub-title",
                                children: "Learn At Your Own Pace"
                            }), Object(a.jsx)("h2", {
                                className: "font-weight-black",
                                children: "Top Selling Courses"
                            }), Object(a.jsx)("p", {
                                children: "Explore all of our courses and pick your suitable ones to enroll and start learning with us! We ensure that you will never regret it!"
                            })]
                        }), c ? Object(a.jsxs)(b, o(o({
                            className: "courses-slides-two owl-carousel owl-theme"
                        }, g), {}, {
                            children: [Object(a.jsxs)("div", {
                                className: "single-kindergarten-courses-box",
                                children: [Object(a.jsxs)("div", {
                                    className: "courses-image",
                                    children: [Object(a.jsx)("div", {
                                        className: "image",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/courses/kindergarten-img1.jpg",
                                            alt: "image"
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "price",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/price-bg.png",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "$39"
                                        })]
                                    }), Object(a.jsx)(d.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "courses-content",
                                    children: [Object(a.jsxs)("div", {
                                        className: "course-author d-flex align-items-center",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/user1.jpg",
                                            className: "rounded-circle",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "Alex Morgan"
                                        })]
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: Object(a.jsx)(d.a, {
                                            href: "/single-courses-1",
                                            children: Object(a.jsx)("a", {
                                                children: "Equivalent fractions and comparing fractions"
                                            })
                                        })
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-courses-box",
                                children: [Object(a.jsxs)("div", {
                                    className: "courses-image",
                                    children: [Object(a.jsx)("div", {
                                        className: "image",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/courses/kindergarten-img2.jpg",
                                            alt: "image"
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "price",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/price-bg.png",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "$49"
                                        })]
                                    }), Object(a.jsx)(d.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "courses-content",
                                    children: [Object(a.jsxs)("div", {
                                        className: "course-author d-flex align-items-center",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/user2.jpg",
                                            className: "rounded-circle",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "Sarah Taylor"
                                        })]
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: Object(a.jsx)(d.a, {
                                            href: "/single-courses-1",
                                            children: Object(a.jsx)("a", {
                                                children: "Arithmetic patterns and problem solving"
                                            })
                                        })
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-courses-box",
                                children: [Object(a.jsxs)("div", {
                                    className: "courses-image",
                                    children: [Object(a.jsx)("div", {
                                        className: "image",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/courses/kindergarten-img3.jpg",
                                            alt: "image"
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "price",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/price-bg.png",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "$59"
                                        })]
                                    }), Object(a.jsx)(d.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "courses-content",
                                    children: [Object(a.jsxs)("div", {
                                        className: "course-author d-flex align-items-center",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/user3.jpg",
                                            className: "rounded-circle",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "David Warner"
                                        })]
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: Object(a.jsx)(d.a, {
                                            href: "/single-courses-1",
                                            children: Object(a.jsx)("a", {
                                                children: "The unit circle definition of sine, and cosine"
                                            })
                                        })
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    })]
                                })]
                            }), Object(a.jsxs)("div", {
                                className: "single-kindergarten-courses-box",
                                children: [Object(a.jsxs)("div", {
                                    className: "courses-image",
                                    children: [Object(a.jsx)("div", {
                                        className: "image",
                                        children: Object(a.jsx)("img", {
                                            src: "/images/courses/kindergarten-img4.jpg",
                                            alt: "image"
                                        })
                                    }), Object(a.jsxs)("div", {
                                        className: "price",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/price-bg.png",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "$69"
                                        })]
                                    }), Object(a.jsx)(d.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            className: "link-btn"
                                        })
                                    })]
                                }), Object(a.jsxs)("div", {
                                    className: "courses-content",
                                    children: [Object(a.jsxs)("div", {
                                        className: "course-author d-flex align-items-center",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/user4.jpg",
                                            className: "rounded-circle",
                                            alt: "image"
                                        }), Object(a.jsx)("span", {
                                            children: "James Andy"
                                        })]
                                    }), Object(a.jsx)("h3", {
                                        className: "font-weight-black",
                                        children: Object(a.jsx)(d.a, {
                                            href: "/single-courses-1",
                                            children: Object(a.jsx)("a", {
                                                children: "Thinking about multivariable functions"
                                            })
                                        })
                                    }), Object(a.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    })]
                                })]
                            })]
                        })) : ""]
                    }), Object(a.jsx)("div", {
                        className: "kindergarten-shape11",
                        children: Object(a.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape11.png",
                            alt: "image"
                        })
                    }), Object(a.jsx)("div", {
                        className: "kindergarten-shape12",
                        children: Object(a.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape12.png",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        "x+qZ": function(e, s, c) {
            "use strict";
            var i = c("nKUr"),
                a = (c("q1tI"), c("YFqc")),
                t = c.n(a);
            s.a = function() {
                return Object(i.jsxs)("div", {
                    className: "kindergarten-main-banner",
                    children: [Object(i.jsx)("div", {
                        className: "container-fluid",
                        children: Object(i.jsxs)("div", {
                            className: "row",
                            children: [Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsxs)("div", {
                                    className: "kindergarten-banner-content",
                                    children: [Object(i.jsx)("div", {
                                        className: "image",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/bird1.png",
                                            alt: "image"
                                        })
                                    }), Object(i.jsxs)("h1", {
                                        children: ["A lifetime of ", Object(i.jsx)("span", {
                                            children: "Confidence"
                                        }), " starts here"]
                                    }), Object(i.jsx)("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }), Object(i.jsx)(t.a, {
                                        href: "/profile-authentication",
                                        children: Object(i.jsxs)("a", {
                                            className: "default-btn-style-two",
                                            children: [Object(i.jsx)("i", {
                                                className: "flaticon-user"
                                            }), " Join For Free"]
                                        })
                                    }), Object(i.jsx)("div", {
                                        className: "circle-shape",
                                        children: Object(i.jsx)("img", {
                                            src: "/images/circle.png",
                                            alt: "image"
                                        })
                                    })]
                                })
                            }), Object(i.jsx)("div", {
                                className: "col-lg-6 col-md-12",
                                children: Object(i.jsx)("div", {
                                    className: "kindergarten-banner-image",
                                    children: Object(i.jsxs)("div", {
                                        className: "row",
                                        children: [Object(i.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(i.jsx)("div", {
                                                className: "image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/kids1.png",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(i.jsx)("div", {
                                                className: "image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/kids2.png",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(i.jsx)("div", {
                                                className: "image",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/kids3.png",
                                                    alt: "image"
                                                })
                                            })
                                        }), Object(i.jsx)("div", {
                                            className: "col-lg-6 col-md-6 col-sm-6",
                                            children: Object(i.jsx)("div", {
                                                className: "image text-left",
                                                children: Object(i.jsx)("img", {
                                                    src: "/images/kids4.png",
                                                    className: "mt-4",
                                                    alt: "image"
                                                })
                                            })
                                        })]
                                    })
                                })
                            })]
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape1",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape1.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape2",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape2.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape3",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape3.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape4",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape4.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape5",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape5.png",
                            alt: "image"
                        })
                    }), Object(i.jsx)("div", {
                        className: "kindergarten-shape6",
                        children: Object(i.jsx)("img", {
                            src: "/images/kindergarten-shape/k-shape6.png",
                            alt: "image"
                        })
                    })]
                })
            }
        }
    }
]);