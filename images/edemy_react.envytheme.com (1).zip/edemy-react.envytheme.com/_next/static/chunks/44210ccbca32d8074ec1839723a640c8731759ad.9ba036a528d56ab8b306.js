(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
    [12], {
        CucJ: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                t = (c("q1tI"), c("YFqc")),
                l = c.n(t);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "comments-area",
                    children: [Object(a.jsx)("h3", {
                        className: "comments-title",
                        children: "2 Comments:"
                    }), Object(a.jsxs)("ol", {
                        className: "comment-list",
                        children: [Object(a.jsxs)("li", {
                            className: "comment",
                            children: [Object(a.jsxs)("div", {
                                className: "comment-body",
                                children: [Object(a.jsxs)("div", {
                                    className: "comment-meta",
                                    children: [Object(a.jsxs)("div", {
                                        className: "comment-author vcard",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/user1.jpg",
                                            className: "avatar",
                                            alt: "image"
                                        }), Object(a.jsx)("b", {
                                            className: "fn",
                                            children: "John Jones"
                                        }), Object(a.jsx)("span", {
                                            className: "says",
                                            children: "says:"
                                        })]
                                    }), Object(a.jsx)("div", {
                                        className: "comment-metadata",
                                        children: Object(a.jsx)("span", {
                                            children: "April 24, 2019 at 10:59 am"
                                        })
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "comment-content",
                                    children: Object(a.jsx)("p", {
                                        children: "Lorem Ipsum has been the industry\u2019s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen."
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "reply",
                                    children: Object(a.jsx)(l.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            className: "comment-reply-link",
                                            children: "Reply"
                                        })
                                    })
                                })]
                            }), Object(a.jsx)("ol", {
                                className: "children",
                                children: Object(a.jsxs)("li", {
                                    className: "comment",
                                    children: [Object(a.jsxs)("div", {
                                        className: "comment-body",
                                        children: [Object(a.jsxs)("div", {
                                            className: "comment-meta",
                                            children: [Object(a.jsxs)("div", {
                                                className: "comment-author vcard",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/user2.jpg",
                                                    className: "avatar",
                                                    alt: "image"
                                                }), Object(a.jsx)("b", {
                                                    className: "fn",
                                                    children: "Steven Smith"
                                                }), Object(a.jsx)("span", {
                                                    className: "says",
                                                    children: "says:"
                                                })]
                                            }), Object(a.jsx)("div", {
                                                className: "comment-metadata",
                                                children: Object(a.jsx)("span", {
                                                    children: "April 24, 2019 at 10:59 am"
                                                })
                                            })]
                                        }), Object(a.jsx)("div", {
                                            className: "comment-content",
                                            children: Object(a.jsx)("p", {
                                                children: "Lorem Ipsum has been the industry\u2019s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen."
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "reply",
                                            children: Object(a.jsx)(l.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    className: "comment-reply-link",
                                                    children: "Reply"
                                                })
                                            })
                                        })]
                                    }), Object(a.jsx)("ol", {
                                        className: "children",
                                        children: Object(a.jsx)("li", {
                                            className: "comment",
                                            children: Object(a.jsxs)("div", {
                                                className: "comment-body",
                                                children: [Object(a.jsxs)("div", {
                                                    className: "comment-meta",
                                                    children: [Object(a.jsxs)("div", {
                                                        className: "comment-author vcard",
                                                        children: [Object(a.jsx)("img", {
                                                            src: "/images/user3.jpg",
                                                            className: "avatar",
                                                            alt: "image"
                                                        }), Object(a.jsx)("b", {
                                                            className: "fn",
                                                            children: "Sarah Taylor"
                                                        }), Object(a.jsx)("span", {
                                                            className: "says",
                                                            children: "says:"
                                                        })]
                                                    }), Object(a.jsx)("div", {
                                                        className: "comment-metadata",
                                                        children: Object(a.jsx)("span", {
                                                            children: "April 24, 2019 at 10:59 am"
                                                        })
                                                    })]
                                                }), Object(a.jsx)("div", {
                                                    className: "comment-content",
                                                    children: Object(a.jsx)("p", {
                                                        children: "Lorem Ipsum has been the industry\u2019s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen."
                                                    })
                                                }), Object(a.jsx)("div", {
                                                    className: "reply",
                                                    children: Object(a.jsx)(l.a, {
                                                        href: "#",
                                                        children: Object(a.jsx)("a", {
                                                            className: "comment-reply-link",
                                                            children: "Reply"
                                                        })
                                                    })
                                                })]
                                            })
                                        })
                                    })]
                                })
                            })]
                        }), Object(a.jsxs)("li", {
                            className: "comment",
                            children: [Object(a.jsxs)("div", {
                                className: "comment-body",
                                children: [Object(a.jsxs)("div", {
                                    className: "comment-meta",
                                    children: [Object(a.jsxs)("div", {
                                        className: "comment-author vcard",
                                        children: [Object(a.jsx)("img", {
                                            src: "/images/user4.jpg",
                                            className: "avatar",
                                            alt: "image"
                                        }), Object(a.jsx)("b", {
                                            className: "fn",
                                            children: "John Doe"
                                        }), Object(a.jsx)("span", {
                                            className: "says",
                                            children: "says:"
                                        })]
                                    }), Object(a.jsx)("div", {
                                        className: "comment-metadata",
                                        children: Object(a.jsx)("span", {
                                            children: "April 24, 2019 at 10:59 am"
                                        })
                                    })]
                                }), Object(a.jsx)("div", {
                                    className: "comment-content",
                                    children: Object(a.jsx)("p", {
                                        children: "Lorem Ipsum has been the industry\u2019s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen."
                                    })
                                }), Object(a.jsx)("div", {
                                    className: "reply",
                                    children: Object(a.jsx)(l.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            className: "comment-reply-link",
                                            children: "Reply"
                                        })
                                    })
                                })]
                            }), Object(a.jsx)("ol", {
                                className: "children",
                                children: Object(a.jsx)("li", {
                                    className: "comment",
                                    children: Object(a.jsxs)("div", {
                                        className: "comment-body",
                                        children: [Object(a.jsxs)("div", {
                                            className: "comment-meta",
                                            children: [Object(a.jsxs)("div", {
                                                className: "comment-author vcard",
                                                children: [Object(a.jsx)("img", {
                                                    src: "/images/user1.jpg",
                                                    className: "avatar",
                                                    alt: "image"
                                                }), Object(a.jsx)("b", {
                                                    className: "fn",
                                                    children: "James Anderson"
                                                }), Object(a.jsx)("span", {
                                                    className: "says",
                                                    children: "says:"
                                                })]
                                            }), Object(a.jsx)("div", {
                                                className: "comment-metadata",
                                                children: Object(a.jsx)("span", {
                                                    children: "April 24, 2019 at 10:59 am"
                                                })
                                            })]
                                        }), Object(a.jsx)("div", {
                                            className: "comment-content",
                                            children: Object(a.jsx)("p", {
                                                children: "Lorem Ipsum has been the industry\u2019s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen."
                                            })
                                        }), Object(a.jsx)("div", {
                                            className: "reply",
                                            children: Object(a.jsx)(l.a, {
                                                href: "#",
                                                children: Object(a.jsx)("a", {
                                                    className: "comment-reply-link",
                                                    children: "Reply"
                                                })
                                            })
                                        })]
                                    })
                                })
                            })]
                        })]
                    }), Object(a.jsxs)("div", {
                        className: "comment-respond",
                        children: [Object(a.jsx)("h3", {
                            className: "comment-reply-title",
                            children: "Leave a Reply"
                        }), Object(a.jsxs)("form", {
                            className: "comment-form",
                            children: [Object(a.jsxs)("p", {
                                className: "comment-notes",
                                children: [Object(a.jsx)("span", {
                                    id: "email-notes",
                                    children: "Your email address will not be published."
                                }), "Required fields are marked", Object(a.jsx)("span", {
                                    className: "required",
                                    children: "*"
                                })]
                            }), Object(a.jsxs)("p", {
                                className: "comment-form-author",
                                children: [Object(a.jsxs)("label", {
                                    children: ["Name ", Object(a.jsx)("span", {
                                        className: "required",
                                        children: "*"
                                    })]
                                }), Object(a.jsx)("input", {
                                    type: "text",
                                    id: "author",
                                    placeholder: "Your Name*",
                                    name: "author",
                                    required: "required"
                                })]
                            }), Object(a.jsxs)("p", {
                                className: "comment-form-email",
                                children: [Object(a.jsxs)("label", {
                                    children: ["Email ", Object(a.jsx)("span", {
                                        className: "required",
                                        children: "*"
                                    })]
                                }), Object(a.jsx)("input", {
                                    type: "email",
                                    id: "email",
                                    placeholder: "Your Email*",
                                    name: "email",
                                    required: "required"
                                })]
                            }), Object(a.jsxs)("p", {
                                className: "comment-form-url",
                                children: [Object(a.jsx)("label", {
                                    children: "Website"
                                }), Object(a.jsx)("input", {
                                    type: "url",
                                    id: "url",
                                    placeholder: "Website",
                                    name: "url"
                                })]
                            }), Object(a.jsxs)("p", {
                                className: "comment-form-comment",
                                children: [Object(a.jsx)("label", {
                                    children: "Comment"
                                }), Object(a.jsx)("textarea", {
                                    name: "comment",
                                    id: "comment",
                                    cols: "45",
                                    placeholder: "Your Comment...",
                                    rows: "5",
                                    maxLength: "65525",
                                    required: "required"
                                })]
                            }), Object(a.jsxs)("p", {
                                className: "comment-form-cookies-consent",
                                children: [Object(a.jsx)("input", {
                                    type: "checkbox",
                                    value: "yes",
                                    name: "wp-comment-cookies-consent",
                                    id: "wp-comment-cookies-consent"
                                }), Object(a.jsx)("label", {
                                    children: "Save my name, email, and website in this browser for the next time I comment."
                                })]
                            }), Object(a.jsx)("p", {
                                className: "form-submit",
                                children: Object(a.jsx)("input", {
                                    type: "submit",
                                    name: "submit",
                                    id: "submit",
                                    className: "submit",
                                    value: "Post A Comment"
                                })
                            })]
                        })]
                    })]
                })
            }
        },
        Ix5F: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                t = (c("q1tI"), c("YFqc")),
                l = c.n(t);
            s.a = function(e) {
                var s = e.pageTitle,
                    c = e.homePageUrl,
                    t = e.homePageText,
                    n = e.activePageText;
                return Object(a.jsxs)("div", {
                    className: "page-title-area",
                    children: [Object(a.jsx)("div", {
                        className: "container",
                        children: Object(a.jsxs)("div", {
                            className: "page-title-content",
                            children: [Object(a.jsxs)("ul", {
                                children: [Object(a.jsx)("li", {
                                    children: Object(a.jsx)(l.a, {
                                        href: c,
                                        children: Object(a.jsx)("a", {
                                            children: t
                                        })
                                    })
                                }), Object(a.jsx)("li", {
                                    className: "active",
                                    children: n
                                })]
                            }), Object(a.jsx)("h2", {
                                children: s
                            })]
                        })
                    }), Object(a.jsx)("div", {
                        className: "shape9",
                        children: Object(a.jsx)("img", {
                            src: "/images/shape8.svg",
                            alt: "image"
                        })
                    })]
                })
            }
        },
        y1kX: function(e, s, c) {
            "use strict";
            var a = c("nKUr"),
                t = (c("q1tI"), c("YFqc")),
                l = c.n(t);
            s.a = function() {
                return Object(a.jsxs)("div", {
                    className: "widget-area",
                    children: [Object(a.jsxs)("div", {
                        className: "widget widget_search",
                        children: [Object(a.jsx)("h3", {
                            className: "widget-title",
                            children: "Search"
                        }), Object(a.jsxs)("form", {
                            className: "search-form",
                            children: [Object(a.jsx)("label", {
                                children: Object(a.jsx)("input", {
                                    type: "search",
                                    className: "search-field",
                                    placeholder: "Search..."
                                })
                            }), Object(a.jsx)("button", {
                                type: "submit",
                                children: Object(a.jsx)("i", {
                                    className: "bx bx-search-alt"
                                })
                            })]
                        })]
                    }), Object(a.jsxs)("div", {
                        className: "widget widget_edemy_posts_thumb",
                        children: [Object(a.jsx)("h3", {
                            className: "widget-title",
                            children: "Popular Posts"
                        }), Object(a.jsxs)("div", {
                            className: "item",
                            children: [Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsx)("a", {
                                    className: "thumb",
                                    children: Object(a.jsx)("span", {
                                        className: "fullimage cover bg1",
                                        role: "img"
                                    })
                                })
                            }), Object(a.jsxs)("div", {
                                className: "info",
                                children: [Object(a.jsx)("span", {
                                    children: "June 10, 2020"
                                }), Object(a.jsx)("h4", {
                                    className: "title usmall",
                                    children: Object(a.jsx)(l.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            children: "Ultimate Bali Guide + Where to stay in Bali 2020"
                                        })
                                    })
                                })]
                            }), Object(a.jsx)("div", {
                                className: "clear"
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "item",
                            children: [Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsx)("a", {
                                    className: "thumb",
                                    children: Object(a.jsx)("span", {
                                        className: "fullimage cover bg2",
                                        role: "img"
                                    })
                                })
                            }), Object(a.jsxs)("div", {
                                className: "info",
                                children: [Object(a.jsx)("span", {
                                    children: "June 21, 2020"
                                }), Object(a.jsx)("h4", {
                                    className: "title usmall",
                                    children: Object(a.jsx)(l.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            children: "Live the Island life: 20 unique Islands to visit in 2020"
                                        })
                                    })
                                })]
                            }), Object(a.jsx)("div", {
                                className: "clear"
                            })]
                        }), Object(a.jsxs)("div", {
                            className: "item",
                            children: [Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsx)("a", {
                                    className: "thumb",
                                    children: Object(a.jsx)("span", {
                                        className: "fullimage cover bg3",
                                        role: "img"
                                    })
                                })
                            }), Object(a.jsxs)("div", {
                                className: "info",
                                children: [Object(a.jsx)("span", {
                                    children: "June 30, 2020"
                                }), Object(a.jsx)("h4", {
                                    className: "title usmall",
                                    children: Object(a.jsx)(l.a, {
                                        href: "#",
                                        children: Object(a.jsx)("a", {
                                            children: "Best Places to Visit in Europe this Autumn & Winter"
                                        })
                                    })
                                })]
                            }), Object(a.jsx)("div", {
                                className: "clear"
                            })]
                        })]
                    }), Object(a.jsxs)("div", {
                        className: "widget widget_categories",
                        children: [Object(a.jsx)("h3", {
                            className: "widget-title",
                            children: "Categories"
                        }), Object(a.jsxs)("ul", {
                            children: [Object(a.jsx)("li", {
                                children: Object(a.jsx)(l.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Design ", Object(a.jsx)("span", {
                                            className: "post-count",
                                            children: "(03)"
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("li", {
                                children: Object(a.jsx)(l.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Lifestyle ", Object(a.jsx)("span", {
                                            className: "post-count",
                                            children: "(05)"
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("li", {
                                children: Object(a.jsx)(l.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Script ", Object(a.jsx)("span", {
                                            className: "post-count",
                                            children: "(10)"
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("li", {
                                children: Object(a.jsx)(l.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Device ", Object(a.jsx)("span", {
                                            className: "post-count",
                                            children: "(08)"
                                        })]
                                    })
                                })
                            }), Object(a.jsx)("li", {
                                children: Object(a.jsx)(l.a, {
                                    href: "#",
                                    children: Object(a.jsxs)("a", {
                                        children: ["Tips ", Object(a.jsx)("span", {
                                            className: "post-count",
                                            children: "(01)"
                                        })]
                                    })
                                })
                            })]
                        })]
                    }), Object(a.jsxs)("div", {
                        className: "widget widget_tag_cloud",
                        children: [Object(a.jsx)("h3", {
                            className: "widget-title",
                            children: "Popular Tags"
                        }), Object(a.jsxs)("div", {
                            className: "tagcloud",
                            children: [Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Business ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (3)"
                                    })]
                                })
                            }), Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Design ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (3)"
                                    })]
                                })
                            }), Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Braike ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (2)"
                                    })]
                                })
                            }), Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Fashion ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (2)"
                                    })]
                                })
                            }), Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Travel ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (1)"
                                    })]
                                })
                            }), Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Smart ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (1)"
                                    })]
                                })
                            }), Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Marketing ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (1)"
                                    })]
                                })
                            }), Object(a.jsx)(l.a, {
                                href: "#",
                                children: Object(a.jsxs)("a", {
                                    children: ["Tips ", Object(a.jsx)("span", {
                                        className: "tag-link-count",
                                        children: " (2)"
                                    })]
                                })
                            })]
                        })]
                    })]
                })
            }
        }
    }
]);